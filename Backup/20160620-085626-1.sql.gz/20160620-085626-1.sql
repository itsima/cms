-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 113.10.247.134
-- Port     : 3306
-- Database : s611984db0
-- 
-- Part : #1
-- Date : 2016-06-20 08:56:26
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `dux_admin_group`
-- -----------------------------
DROP TABLE IF EXISTS `dux_admin_group`;
CREATE TABLE `dux_admin_group` (
  `group_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `base_purview` text,
  `menu_purview` text,
  `status` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`group_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='后台管理组';

-- -----------------------------
-- Records of `dux_admin_group`
-- -----------------------------
INSERT INTO `dux_admin_group` VALUES ('1', '管理员', 'a:2:{i:0;s:15:\"Admin_AppManage\";i:1;s:21:\"Admin_AppManage_index\";}', 'a:4:{i:0;s:19:\"首页_管理首页\";i:1;s:19:\"内容_栏目管理\";i:2;s:19:\"内容_文章管理\";i:3;s:22:\"系统_用户组管理\";}', '1');

-- -----------------------------
-- Table structure for `dux_admin_log`
-- -----------------------------
DROP TABLE IF EXISTS `dux_admin_log`;
CREATE TABLE `dux_admin_log` (
  `log_id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  `ip` varchar(250) DEFAULT NULL,
  `app` varchar(250) DEFAULT '1',
  `content` text,
  PRIMARY KEY (`log_id`),
  KEY `user_id` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8 COMMENT='后台操作记录';

-- -----------------------------
-- Records of `dux_admin_log`
-- -----------------------------
INSERT INTO `dux_admin_log` VALUES ('1', '1', '1420814226', '127.0.0.1', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('2', '1', '1420814781', '127.0.0.1', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('3', '1', '1420814834', '127.0.0.1', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('4', '1', '1420895392', '127.0.0.1', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('5', '1', '1421067913', '127.0.0.1', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('6', '1', '1421203314', '110.240.199.110', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('7', '1', '1421227136', '110.240.199.110', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('8', '1', '1421246983', '106.117.123.141', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('9', '1', '1421487801', '106.117.122.235', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('10', '1', '1421567833', '106.117.126.28', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('11', '1', '1422671778', '222.222.36.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('12', '1', '1422675049', '222.222.36.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('13', '1', '1422683611', '222.222.36.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('14', '1', '1422690979', '222.222.36.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('15', '1', '1422710404', '106.117.126.160', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('16', '1', '1422766658', '222.222.36.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('17', '1', '1422766934', '222.222.36.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('18', '1', '1422768996', '222.222.36.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('19', '1', '1422769104', '222.222.36.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('20', '1', '1422782261', '222.222.36.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('21', '1', '1422787404', '222.222.36.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('22', '1', '1422843138', '222.222.36.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('23', '1', '1422845202', '110.240.199.87', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('24', '1', '1422851570', '222.222.36.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('25', '1', '1422878103', '106.117.68.201', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('26', '1', '1422932323', '222.222.36.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('27', '1', '1422933876', '110.240.205.215', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('28', '1', '1422933996', '222.222.36.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('29', '1', '1422976863', '106.117.125.99', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('30', '1', '1423107662', '222.222.36.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('31', '1', '1423134356', '106.117.121.244', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('32', '1', '1423188828', '110.228.199.31', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('33', '1', '1423188900', '110.228.199.31', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('34', '1', '1423201772', '110.228.199.31', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('35', '1', '1423201808', '222.222.36.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('36', '1', '1423216523', '222.222.36.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('37', '1', '1423221938', '106.117.119.117', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('38', '1', '1423284444', '222.222.36.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('39', '1', '1423304852', '222.222.36.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('40', '1', '1423305043', '222.222.36.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('41', '1', '1441076781', '110.240.223.151', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('42', '1', '1452849641', '120.1.6.110', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('43', '1', '1452849738', '125.94.54.171', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('44', '1', '1452906424', '125.94.54.171', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('45', '1', '1452915836', '125.94.52.149', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('46', '1', '1453087644', '125.94.53.173', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('47', '1', '1453091353', '125.94.53.173', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('48', '1', '1453172162', '125.94.53.173', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('49', '1', '1453256677', '125.94.53.173', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('50', '1', '1453448971', '125.94.54.0', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('51', '1', '1453701360', '125.94.55.112', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('52', '1', '1453704593', '125.94.55.112', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('53', '1', '1453774893', '125.94.55.112', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('54', '1', '1453789049', '125.94.55.196', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('55', '1', '1459909963', '113.99.26.230', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('56', '1', '1462347262', '113.99.27.208', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('57', '1', '1464060154', '113.68.33.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('58', '1', '1464061080', '113.68.33.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('59', '1', '1464061325', '113.68.33.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('60', '1', '1464061334', '113.68.33.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('61', '1', '1464158386', '113.68.33.26', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('62', '1', '1464224834', '113.68.33.68', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('63', '1', '1465872555', '113.68.33.62', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('64', '1', '1465954012', '113.68.32.79', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('65', '1', '1465970488', '113.68.32.79', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('66', '1', '1465974068', '218.30.118.78', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('67', '1', '1465974069', '218.30.118.78', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('68', '1', '1466046203', '113.68.32.79', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('69', '1', '1466050791', '113.68.32.79', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('70', '1', '1466066690', '113.68.32.79', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('71', '1', '1466125245', '113.68.33.158', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('72', '1', '1466141260', '113.68.32.12', 'Admin', '登录系统');
INSERT INTO `dux_admin_log` VALUES ('73', '1', '1466384076', '113.99.26.74', 'Admin', '登录系统');

-- -----------------------------
-- Table structure for `dux_admin_user`
-- -----------------------------
DROP TABLE IF EXISTS `dux_admin_user`;
CREATE TABLE `dux_admin_user` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT COMMENT '用户IP',
  `group_id` int(10) NOT NULL DEFAULT '1' COMMENT '用户组ID',
  `username` varchar(20) NOT NULL COMMENT '登录名',
  `password` varchar(32) NOT NULL COMMENT '密码',
  `nicename` varchar(20) DEFAULT NULL COMMENT '昵称',
  `email` varchar(50) DEFAULT NULL,
  `status` tinyint(1) unsigned DEFAULT '1' COMMENT '状态',
  `level` int(5) DEFAULT '1' COMMENT '等级',
  `reg_time` int(10) DEFAULT NULL COMMENT '注册时间',
  `last_login_time` int(10) DEFAULT NULL COMMENT '最后登录时间',
  `last_login_ip` varchar(15) DEFAULT '未知' COMMENT '登录IP',
  PRIMARY KEY (`user_id`),
  KEY `username` (`username`),
  KEY `group_id` (`group_id`) USING BTREE,
  KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='后台管理员';

-- -----------------------------
-- Records of `dux_admin_user`
-- -----------------------------
INSERT INTO `dux_admin_user` VALUES ('1', '1', 'admin', '21232f297a57a5a743894a0e4a801fc3', '管理员', 'admin@duxcms.com', '1', '1', '1399361747', '1466384075', '113.99.26.74');

-- -----------------------------
-- Table structure for `dux_category`
-- -----------------------------
DROP TABLE IF EXISTS `dux_category`;
CREATE TABLE `dux_category` (
  `class_id` int(10) NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) DEFAULT '0',
  `app` varchar(20) DEFAULT NULL,
  `show` tinyint(1) unsigned DEFAULT '1',
  `sequence` int(10) DEFAULT '0',
  `type` int(10) NOT NULL DEFAULT '1',
  `name` varchar(250) DEFAULT NULL,
  `urlname` varchar(250) DEFAULT NULL,
  `subname` varchar(250) DEFAULT NULL,
  `image` varchar(250) DEFAULT NULL,
  `class_tpl` varchar(250) DEFAULT NULL,
  `keywords` varchar(250) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `upload_config` int(10) DEFAULT '1',
  PRIMARY KEY (`class_id`),
  UNIQUE KEY `urlname` (`urlname`) USING BTREE,
  KEY `pid` (`parent_id`),
  KEY `mid` (`app`),
  KEY `sequence` (`sequence`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COMMENT='栏目基础信息';

-- -----------------------------
-- Records of `dux_category`
-- -----------------------------
INSERT INTO `dux_category` VALUES ('1', '0', 'Page', '1', '1', '1', '海方介绍', 'haifangjieshao', '', '/Uploads/2016-01-25/56a5dafc7d521.jpg', 'page', '海方介绍,纸方管,环保', '', '1');
INSERT INTO `dux_category` VALUES ('2', '0', 'Article', '1', '1', '0', '产品及应用', 'chanpinjiyingyong', '海方「方形纸管」技术是我国纸制品行业的一次技术革命，更是传统行业的技术革新。 ', '', 'productlist', '', '', '1');
INSERT INTO `dux_category` VALUES ('3', '0', 'Page', '1', '1', '1', '市场布局', 'shichangbuju', '', '', 'market', '', '', '1');
INSERT INTO `dux_category` VALUES ('4', '0', 'Article', '1', '1', '1', '合作案例', 'hezuoanli', '', '', 'case', '', '', '1');
INSERT INTO `dux_category` VALUES ('6', '0', 'Article', '1', '1', '0', '新闻与活动', 'xinwenyuhuodong', '', '', 'news', '', '', '1');
INSERT INTO `dux_category` VALUES ('7', '0', 'Page', '1', '1', '1', '联系海方', 'lianxihaifang', '', '', 'contact', '', '', '1');
INSERT INTO `dux_category` VALUES ('8', '1', 'Page', '1', '1', '1', '董事长致辞', 'dongshichangzhici', '', '/Uploads/2015-02-01/54cdb4405451e.jpg', 'page_about', '董事长致辞,环保,纸方管', '董事长致辞', '1');
INSERT INTO `dux_category` VALUES ('9', '0', 'Article', '1', '1', '1', '海方荣誉', 'haifangrongyu', '', '', 'rongyu', '', '', '1');
INSERT INTO `dux_category` VALUES ('10', '0', 'Article', '1', '1', '1', '海方团队', 'haifangtuandui', '', '/Uploads/2015-02-02/54cf1fb953148.jpg', 'team', '', '', '1');
INSERT INTO `dux_category` VALUES ('11', '0', 'Article', '1', '1', '1', '资料下载', 'ziliaoxiazai', '', '', 'down', '', '', '1');
INSERT INTO `dux_category` VALUES ('13', '2', 'Article', '1', '1', '1', '方形纸管', 'fangxingzhiguan', '绿色环保材料 / 独家专利 / 具备“轻钢强韧”特性 / 规格多样可量产 /  应用领域广', '/Uploads/2016-01-16/5699b98708aef.jpg', 'productlist', '方形纸管,纸方管,方管,包装,纸家具,纸托盘', '方形纸管,纸方管,方管,包装,纸家具,纸托盘', '1');
INSERT INTO `dux_category` VALUES ('14', '2', 'Article', '1', '2', '1', '物流托盘', 'wuliutuopan', '专利产品 /  环保免熏蒸 /  结构坚固载荷高 / 防静电 /  品质恒定 /  规格多样可定制生产', '', 'productlist', '', '', '1');
INSERT INTO `dux_category` VALUES ('15', '2', 'Article', '1', '3', '1', '包装箱', 'baozhuangxiang', '专利产品 / 环保免熏蒸 / 结构稳定承载性强 / 防静电 / 品质恒定 / 产能大 /  定制生产', '', 'productlist', '', '', '1');
INSERT INTO `dux_category` VALUES ('16', '2', 'Article', '1', '4', '1', '框架包装', 'kuangjiabaozhuang', '专利产品 /  环保免熏蒸 /  结构稳定承载性强 /  防静电 /  品质恒定 / 产能大 / 定制生产', '', 'productlist', '', '', '1');
INSERT INTO `dux_category` VALUES ('17', '2', 'Article', '1', '5', '1', '内置外包装', 'neizhiwaibaozhuang', '专利产品 / 环保免熏蒸 / 结构稳定承载性强 / 方形不滚动易叠码 / 品质恒定 / 定制生产', '', 'productlist', '', '', '1');
INSERT INTO `dux_category` VALUES ('18', '2', 'Article', '1', '7', '1', '展示架堆头架', 'zhanshijiaduitoujia', '绿色环保 / 百变造型自由组装 / 重量轻便于携带 /  结构稳定实用性强 /  定制生产', '', 'productlist', '', '', '1');
INSERT INTO `dux_category` VALUES ('19', '2', 'Article', '1', '8', '1', '商装家装', 'shangzhuangjiazhuang', '全新概念 / 绿色环保 / 创意设计 / 安装便捷 / 综合成本低 / 定制生产', '', 'productlist', '', '', '1');
INSERT INTO `dux_category` VALUES ('20', '2', 'Article', '1', '9', '1', '家居办公', 'jiajubangong', '全新概念 / 绿色环保 / 创意设计 / 百变造型 /  定制生产', '', 'productlist', '', '', '1');
INSERT INTO `dux_category` VALUES ('21', '2', 'Article', '1', '10', '1', '房屋临时安置', 'fangwulinshianzhi', '全新概念 / 绿色环保 / 创意设计 / 安装便捷 / 综合成本低 / 定制生产', '', 'productlist', '', '', '1');
INSERT INTO `dux_category` VALUES ('22', '2', 'Article', '1', '11', '1', '概念产品', 'gainianchanpin', '全新概念 / 绿色环保 / 创意设计 /  用创新引领我们不断前行', '', 'productlist', '', '', '1');
INSERT INTO `dux_category` VALUES ('23', '6', 'Article', '1', '1', '1', '行业新闻', 'xingyexinwen', '', '', 'news', '', '', '1');
INSERT INTO `dux_category` VALUES ('24', '6', 'Article', '1', '1', '1', '活动新闻', 'huodongxinwen', '', '', 'news', '', '', '1');
INSERT INTO `dux_category` VALUES ('25', '6', 'Article', '1', '1', '1', '公司动态', 'gongsidongtai', '', '', 'news', '', '', '1');
INSERT INTO `dux_category` VALUES ('26', '0', 'Article', '0', '1', '1', 'banner', 'banner', '', '', 'list', '', '', '1');
INSERT INTO `dux_category` VALUES ('27', '0', 'Article', '1', '1', '1', '海方大事记', 'haifangdashiji', '', '', 'events', '', '', '1');
INSERT INTO `dux_category` VALUES ('28', '0', 'Article', '1', '1', '1', '我们的视频', 'womendeshipin', '', '', 'video', '', '', '1');
INSERT INTO `dux_category` VALUES ('29', '2', 'Article', '1', '6', '1', '展览特装环保桁架', 'zhanlantezhuanghuanbaojia', '全新概念 / 绿色环保 / 创意定制 / 施工便捷 / 重复拆卸 / 结构稳定 / 经济实用', '', 'productlist', '', '', '1');

-- -----------------------------
-- Table structure for `dux_category_article`
-- -----------------------------
DROP TABLE IF EXISTS `dux_category_article`;
CREATE TABLE `dux_category_article` (
  `class_id` int(10) NOT NULL,
  `fieldset_id` int(10) NOT NULL,
  `content_tpl` varchar(250) NOT NULL,
  `config_upload` text NOT NULL,
  `content_order` varchar(250) NOT NULL,
  `page` int(10) NOT NULL DEFAULT '10'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文章栏目信息';

-- -----------------------------
-- Records of `dux_category_article`
-- -----------------------------
INSERT INTO `dux_category_article` VALUES ('2', '0', 'product', '', 'time DESC', '12');
INSERT INTO `dux_category_article` VALUES ('4', '0', 'case_content', '', 'time DESC', '12');
INSERT INTO `dux_category_article` VALUES ('6', '0', 'news_detail', '', 'time DESC', '10');
INSERT INTO `dux_category_article` VALUES ('9', '0', 'content', '', 'time DESC', '10');
INSERT INTO `dux_category_article` VALUES ('10', '0', 'content', '', 'time DESC', '10');
INSERT INTO `dux_category_article` VALUES ('11', '2', 'content', '', 'time DESC', '10');
INSERT INTO `dux_category_article` VALUES ('13', '0', 'fangxingzhiguan', '', 'time DESC', '12');
INSERT INTO `dux_category_article` VALUES ('14', '0', 'wuliutuopan', '', 'time DESC', '12');
INSERT INTO `dux_category_article` VALUES ('15', '0', 'baozhuangxiang', '', 'time DESC', '12');
INSERT INTO `dux_category_article` VALUES ('16', '0', 'kuangjiabaozhuang', '', 'time DESC', '12');
INSERT INTO `dux_category_article` VALUES ('17', '0', 'neizhiwaibaozhuang', '', 'time DESC', '12');
INSERT INTO `dux_category_article` VALUES ('18', '0', 'zhanshijia', '', 'time DESC', '12');
INSERT INTO `dux_category_article` VALUES ('19', '0', 'shangzhuangjiazhuang', '', 'time DESC', '12');
INSERT INTO `dux_category_article` VALUES ('20', '0', 'jiajubangong', '', 'time DESC', '12');
INSERT INTO `dux_category_article` VALUES ('21', '0', 'fangwu', '', 'time DESC', '12');
INSERT INTO `dux_category_article` VALUES ('22', '0', 'gainian', '', 'time DESC', '12');
INSERT INTO `dux_category_article` VALUES ('23', '0', 'news_detail', '', 'time DESC', '10');
INSERT INTO `dux_category_article` VALUES ('24', '0', 'news_detail', '', 'time DESC', '10');
INSERT INTO `dux_category_article` VALUES ('25', '0', 'news_detail', '', 'time DESC', '10');
INSERT INTO `dux_category_article` VALUES ('26', '0', 'content', '', 'time DESC', '11');
INSERT INTO `dux_category_article` VALUES ('27', '3', 'content', '', 'time DESC', '12');
INSERT INTO `dux_category_article` VALUES ('28', '4', 'video_detail', '', 'time DESC', '12');
INSERT INTO `dux_category_article` VALUES ('29', '0', 'fangwu', '', 'time DESC', '10');

-- -----------------------------
-- Table structure for `dux_category_page`
-- -----------------------------
DROP TABLE IF EXISTS `dux_category_page`;
CREATE TABLE `dux_category_page` (
  `class_id` int(10) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext COMMENT '内容',
  KEY `cid` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='单页栏目信息';

-- -----------------------------
-- Records of `dux_category_page`
-- -----------------------------
INSERT INTO `dux_category_page` VALUES ('1', '&lt;p style=&quot;line-height:22px;text-indent:2em;font-family:microsoft yahei;font-size:14px;&quot;&gt;\r\n	&lt;span style=&quot;font-size:16px;&quot;&gt; &lt;span style=&quot;font-family:SimHei;font-size:16px;&quot;&gt;海方是专业研发、生产和销售特种纸类新材料、新产品的科技型环保企业。&lt;/span&gt;&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p style=&quot;line-height:22px;text-indent:2em;font-family:microsoft yahei;font-size:14px;&quot;&gt;\r\n	&lt;span style=&quot;font-family:SimHei;font-size:16px;&quot;&gt; 总部位于珠三角经济圈的广州市，集团旗下子公司分别位于环渤海经济圈的河北石家庄、山东德州、浙江奉化，以及长三角经济圈的江苏丹阳，并逐步往内陆中心城市拓展。海方的发展格局已形成了“以区域辐射三圈，以沿海驱动内陆”的市场布局。&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p style=&quot;line-height:22px;text-indent:2em;font-family:microsoft yahei;font-size:14px;&quot;&gt;\r\n	&lt;span style=&quot;font-family:SimHei;font-size:16px;&quot;&gt; 海方做为中国纸制品行业纸管技术的领军企业，研发的「方形纸管」技术及在各行业领域应用的「方形纸管产品」均已获得国家发明专利。&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p style=&quot;line-height:22px;text-indent:2em;font-family:microsoft yahei;font-size:14px;&quot;&gt;\r\n	&lt;span style=&quot;font-family:SimHei;font-size:16px;&quot;&gt; 海方「方形纸管」在工业包装、物流运输、展览展示、建材装饰、商装家装、办公家居、救援等行业应用中，其“代木、代塑、代金属”的产品特性，为我国纸制品行业发展拓宽了适用领域，同时更环保、更便捷、使用成本更低。海方「方形纸管」填补了国内技术和产品空白，是我国纸制品行业的一次技术革命，更是传统行业的一次技术革新。&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p style=&quot;line-height:22px;text-indent:2em;font-family:microsoft yahei;font-size:14px;&quot;&gt;\r\n	&lt;span style=&quot;font-family:SimHei;font-size:16px;&quot;&gt; 做为企业公民，海方将持续研发制造更具科技含量的节能环保新材料、新产品服务社会！&lt;/span&gt; \r\n&lt;/p&gt;');
INSERT INTO `dux_category_page` VALUES ('3', '&lt;p style=&quot;line-height:22px;text-indent:2em;font-family:microsoft yahei;font-size:14px;&quot;&gt;\r\n	&lt;img alt=&quot;&quot; src=&quot;/Uploads/2015-01-31/54ccdfab74cd5.gif&quot; /&gt; \r\n&lt;/p&gt;');
INSERT INTO `dux_category_page` VALUES ('7', '&lt;div class=&quot;contact fl&quot;&gt;\r\n	&amp;nbsp;\r\n&lt;/div&gt;');
INSERT INTO `dux_category_page` VALUES ('8', '&lt;p class=&quot;p0&quot;&gt;\r\n	&lt;span style=&quot;font-family:\'黑体\';font-size:16pt;font-weight:bold;&quot;&gt;大道行思    取则行远&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:16pt;font-weight:bold;&quot;&gt;&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p0&quot;&gt;\r\n	&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt;&lt;/span&gt;\r\n&lt;/p&gt;\r\n&lt;p class=&quot;p0&quot;&gt;\r\n	&lt;span style=&quot;font-family:\'黑体\';font-size:16px;&quot;&gt;&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p0&quot;&gt;\r\n	&lt;span style=&quot;font-family:\'黑体\';font-size:14px;&quot;&gt;十余载，&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt; \r\n&lt;/p&gt;\r\n&lt;/span&gt; \r\n&lt;p class=&quot;p0&quot;&gt;\r\n	&lt;span style=&quot;font-family:\'黑体\';font-size:14px;&quot;&gt;凭着奋进与变革，&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt;&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:14px;&quot;&gt;海方历经风雨实现了质的跨越与蜕变，&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p0&quot;&gt;\r\n	&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt;&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt;&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:14px;&quot;&gt;如今的海方已成为一个稳健而又不失活力的行业领导者。&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt;&lt;/span&gt;&lt;br /&gt;\r\n&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt;&lt;/span&gt;\r\n&lt;/p&gt;\r\n&lt;p class=&quot;p0&quot;&gt;\r\n	&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt;&lt;br /&gt;\r\n&lt;/span&gt;\r\n&lt;/p&gt;\r\n&lt;p class=&quot;p0&quot;&gt;\r\n	&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt;&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:14px;&quot;&gt;海方感谢来自全国，&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p0&quot;&gt;\r\n	&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt;&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt;&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:14px;&quot;&gt;十几个行业几十家企业选择海方品牌，&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p0&quot;&gt;\r\n	&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt;&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt;&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:14px;&quot;&gt;将我们的「方形纸管」专利产品和定制方案，&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p0&quot;&gt;\r\n	&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt;&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt;&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:14px;&quot;&gt;应用到几百款产品设备的包装、物流、展示等诸多领域。&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p0&quot;&gt;\r\n	&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt;&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt;&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt;&lt;br /&gt;\r\n&lt;/span&gt;\r\n&lt;/p&gt;\r\n&lt;p class=&quot;p0&quot;&gt;\r\n	&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt;&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:14px;&quot;&gt;为了持续提升客户满意度，&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:14px;&quot;&gt;我们将不断锐意进取、努力奋斗，&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p0&quot;&gt;\r\n	&lt;span style=&quot;font-family:\'黑体\';font-size:16px;&quot;&gt;&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt;&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:14px;&quot;&gt;为企业、为家庭、为社会研发制造更具科技含量的节能环保新材料、新产品！&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt;&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;&quot;&gt; &lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;font-weight:bold;&quot;&gt;\r\n&lt;/p&gt;\r\n&lt;/span&gt; \r\n&lt;p class=&quot;p0&quot;&gt;\r\n	&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;font-weight:bold;&quot;&gt;&lt;br /&gt;\r\n&lt;/span&gt;\r\n&lt;/p&gt;\r\n&lt;p class=&quot;p0&quot;&gt;\r\n	&lt;span style=&quot;font-family:\'黑体\';font-size:14px;font-weight:bold;&quot;&gt;                                       海方集团董事长  王殿海&lt;/span&gt;&lt;span style=&quot;font-family:\'黑体\';font-size:10.5pt;font-weight:bold;&quot;&gt;&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p0&quot;&gt;\r\n	&lt;span style=&quot;font-size:14px;&quot;&gt; &lt;/span&gt;\r\n&lt;/p&gt;');

-- -----------------------------
-- Table structure for `dux_config`
-- -----------------------------
DROP TABLE IF EXISTS `dux_config`;
CREATE TABLE `dux_config` (
  `name` varchar(250) NOT NULL,
  `data` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='网站配置';

-- -----------------------------
-- Records of `dux_config`
-- -----------------------------
INSERT INTO `dux_config` VALUES ('site_title', '海方科技');
INSERT INTO `dux_config` VALUES ('site_subtitle', '纸管,方形纸管,免熏蒸包装箱,免熏蒸托盘,环保包装,环保托盘,环保材料,展架,桁架');
INSERT INTO `dux_config` VALUES ('site_url', 'http://www.haifangchina.com/');
INSERT INTO `dux_config` VALUES ('site_keywords', '纸管,方形纸管,免熏蒸包装箱,免熏蒸托盘,环保包装,环保托盘,环保材料,展架,桁架');
INSERT INTO `dux_config` VALUES ('site_description', ' 海方是专业研发、生产和销售特种纸类新材料、新产品的科技型环保企业。 \r\n海方作为中国纸制品行业纸管技术的领军企业，研发的「方形纸管」技术及在各行业领域应用的「方形纸管产品」均已获得国家发明专利。');
INSERT INTO `dux_config` VALUES ('site_email', '2850182916@qq.com');
INSERT INTO `dux_config` VALUES ('site_copyright', '海方科技');
INSERT INTO `dux_config` VALUES ('site_tel', '020-39122816');
INSERT INTO `dux_config` VALUES ('tpl_name', 'default');
INSERT INTO `dux_config` VALUES ('tpl_index', 'index');
INSERT INTO `dux_config` VALUES ('tpl_search', 'search');
INSERT INTO `dux_config` VALUES ('site_statistics', '&lt;script&gt;\r\nvar _hmt = _hmt || [];\r\n(function() {\r\n  var hm = document.createElement(&quot;script&quot;);\r\n  hm.src = &quot;//hm.baidu.com/hm.js?59654dc8ab7bb1de212b55c88106fef2&quot;;\r\n  var s = document.getElementsByTagName(&quot;script&quot;)[');
INSERT INTO `dux_config` VALUES ('mobile_status', '0');
INSERT INTO `dux_config` VALUES ('mobile_tpl', 'mobile');
INSERT INTO `dux_config` VALUES ('mobile_domain', '');
INSERT INTO `dux_config` VALUES ('site_address', '河北省石家庄市长安区跃进路171号');
INSERT INTO `dux_config` VALUES ('site_title', '海方科技');
INSERT INTO `dux_config` VALUES ('site_subtitle', '纸管,方形纸管,免熏蒸包装箱,免熏蒸托盘,环保包装,环保托盘,环保材料,展架,桁架');
INSERT INTO `dux_config` VALUES ('site_url', 'http://www.haifangchina.com/');
INSERT INTO `dux_config` VALUES ('site_keywords', '纸管,方形纸管,免熏蒸包装箱,免熏蒸托盘,环保包装,环保托盘,环保材料,展架,桁架');
INSERT INTO `dux_config` VALUES ('site_description', ' 海方是专业研发、生产和销售特种纸类新材料、新产品的科技型环保企业。 \r\n海方作为中国纸制品行业纸管技术的领军企业，研发的「方形纸管」技术及在各行业领域应用的「方形纸管产品」均已获得国家发明专利。');
INSERT INTO `dux_config` VALUES ('site_email', '2850182916@qq.com');
INSERT INTO `dux_config` VALUES ('site_copyright', '海方科技');
INSERT INTO `dux_config` VALUES ('site_statistics', '&lt;script&gt;\r\nvar _hmt = _hmt || [];\r\n(function() {\r\n  var hm = document.createElement(&quot;script&quot;);\r\n  hm.src = &quot;//hm.baidu.com/hm.js?59654dc8ab7bb1de212b55c88106fef2&quot;;\r\n  var s = document.getElementsByTagName(&quot;script&quot;)[');
INSERT INTO `dux_config` VALUES ('tpl_name', 'default');
INSERT INTO `dux_config` VALUES ('tpl_index', 'index');
INSERT INTO `dux_config` VALUES ('tpl_search', 'search');
INSERT INTO `dux_config` VALUES ('tpl_tags', 'tag');
INSERT INTO `dux_config` VALUES ('mobile_status', '0');
INSERT INTO `dux_config` VALUES ('mobile_tpl', 'mobile');
INSERT INTO `dux_config` VALUES ('mobile_domain', '');

-- -----------------------------
-- Table structure for `dux_config_upload`
-- -----------------------------
DROP TABLE IF EXISTS `dux_config_upload`;
CREATE TABLE `dux_config_upload` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `upload_size` int(10) NOT NULL,
  `upload_exts` varchar(250) DEFAULT NULL,
  `upload_replace` tinyint(1) DEFAULT NULL,
  `thumb_status` tinyint(1) DEFAULT NULL,
  `water_status` tinyint(1) DEFAULT NULL,
  `thumb_type` tinyint(1) DEFAULT NULL,
  `thumb_width` int(10) DEFAULT NULL,
  `thumb_height` int(10) DEFAULT NULL,
  `water_image` varchar(250) DEFAULT NULL,
  `water_position` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='网站配置';

-- -----------------------------
-- Records of `dux_config_upload`
-- -----------------------------
INSERT INTO `dux_config_upload` VALUES ('1', '默认', '50', 'jpg,gif,bmp,png,txt,pdf,ppt,doc', '0', '0', '0', '1', '800', '800', 'logo.jpg', '1');

-- -----------------------------
-- Table structure for `dux_content`
-- -----------------------------
DROP TABLE IF EXISTS `dux_content`;
CREATE TABLE `dux_content` (
  `content_id` int(10) NOT NULL AUTO_INCREMENT COMMENT '文章ID',
  `class_id` int(10) DEFAULT NULL COMMENT '栏目ID',
  `title` varchar(250) DEFAULT NULL COMMENT '标题',
  `urltitle` varchar(250) DEFAULT NULL COMMENT 'URL路径',
  `font_color` varchar(250) DEFAULT NULL COMMENT '颜色',
  `font_bold` tinyint(1) DEFAULT NULL COMMENT '加粗',
  `font_em` tinyint(1) DEFAULT NULL,
  `position` varchar(250) DEFAULT NULL,
  `keywords` varchar(250) DEFAULT NULL COMMENT '关键词',
  `description` varchar(250) DEFAULT NULL COMMENT '描述',
  `time` int(10) DEFAULT NULL COMMENT '更新时间',
  `image` varchar(250) DEFAULT NULL COMMENT '封面图',
  `url` varchar(250) DEFAULT NULL COMMENT '跳转',
  `sequence` int(10) DEFAULT NULL COMMENT '排序',
  `status` int(10) DEFAULT NULL COMMENT '状态',
  `copyfrom` varchar(250) DEFAULT NULL COMMENT '来源',
  `views` int(10) DEFAULT '0' COMMENT '浏览数',
  `taglink` int(10) DEFAULT '0' COMMENT 'TAG链接',
  `tpl` varchar(250) DEFAULT NULL,
  `site` int(10) DEFAULT '1',
  PRIMARY KEY (`content_id`),
  UNIQUE KEY `urltitle` (`urltitle`) USING BTREE,
  KEY `title` (`title`) USING BTREE,
  KEY `description` (`description`) USING BTREE,
  KEY `keywords` (`keywords`),
  KEY `class_id` (`class_id`) USING BTREE,
  KEY `time` (`time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=376 DEFAULT CHARSET=utf8 COMMENT='内容基础';

-- -----------------------------
-- Records of `dux_content`
-- -----------------------------
INSERT INTO `dux_content` VALUES ('1', '26', 'banner1', 'banner1', '', '', '', '', '', 'banner1', '1421489160', '/Uploads/2015-01-17/54ba344809a4c.gif', '', '0', '1', '本站', '1230', '1', '', '1');
INSERT INTO `dux_content` VALUES ('2', '26', 'banner2', 'banner2', '', '', '', '', '', 'banner2', '1421489220', '/Uploads/2015-01-31/54cc586e77845.jpg', '', '0', '1', '本站', '0', '1', '', '1');
INSERT INTO `dux_content` VALUES ('3', '26', '企业责任', 'qiyezeren', '', '', '', '', '', '企业责任', '1421489580', '/Uploads/2015-01-31/54cc611527c21.jpg', '', '0', '1', '本站', '2', '1', '', '1');
INSERT INTO `dux_content` VALUES ('4', '26', '荣誉', 'rongyu', '', '', '', '', '', '荣誉', '1421489700', '/Uploads/2015-01-17/54ba37d559c09.jpg', '', '0', '1', '本站', '1', '1', '', '1');
INSERT INTO `dux_content` VALUES ('5', '26', '5', '5', '', '', '', '', '', '5', '1421490240', '/Uploads/2015-01-31/54cc60e15d29f.jpg', '', '0', '1', '本站', '0', '1', '', '1');
INSERT INTO `dux_content` VALUES ('7', '9', '方形纸管机专利证书', 'fangxingzhiguanjizhuanlizhengs', '', '', '', '', '', '1', '1421575860', '/Uploads/2015-02-02/54cf19b669f17.jpg', '', '0', '1', '本站', '35', '1', '', '1');
INSERT INTO `dux_content` VALUES ('8', '9', '新型方形纸管机专利证书', 'xinxingfangxingzhiguanjizhuanl', '', '', '', '', '', '', '1421575860', '/Uploads/2015-02-02/54cf1a402917e.jpg', '', '0', '1', '本站', '48', '1', '', '1');
INSERT INTO `dux_content` VALUES ('9', '9', '方形纸管框架包装连接结构专利证书', 'fangxingzhiguankuangjiabaozhua56491009', '', '', '', '', '', '', '1421575860', '/Uploads/2015-02-02/54cf1c6a530e1.jpg', '', '0', '1', '本站', '31', '1', '', '1');
INSERT INTO `dux_content` VALUES ('10', '9', '方形纸管连接件专利证书', 'fangxingzhiguanlianjiejianzhua', '', '', '', '', '', '', '1421575860', '/Uploads/2015-02-02/54cf1ce030b90.jpg', '', '0', '1', '本站', '52', '1', '', '1');
INSERT INTO `dux_content` VALUES ('11', '25', '公司网站上线测试', 'gongsiwangzhanshangxianceshi', '', '', '', '', '', '公司网站上线测试公司网站上线测试公司网站上线测试网址：www.haifangchina.com', '1421577660', '', '', '0', '1', '本站', '46', '1', '', '1');
INSERT INTO `dux_content` VALUES ('12', '11', '海方方形纸管SGS报告', 'haifangfangxingzhiguanSGSbaoga', '', '', '', '', '', '', '1421579280', '', '', '0', '1', '本站', '2', '1', '', '1');
INSERT INTO `dux_content` VALUES ('14', '4', '方形纸管房屋', 'fangxingzhiguanfangwu', '', '', '', '2', '', '', '1422677100', '/Uploads/2015-01-31/54cc549436aac.jpg', '', '0', '1', '本站', '71', '1', '', '1');
INSERT INTO `dux_content` VALUES ('15', '26', '进化史', 'jinhuashi', '', '', '', '', '', '', '1422678180', '/Uploads/2015-01-31/54cc58de3e4be.jpg', '', '0', '1', '本站', '1', '1', '', '1');
INSERT INTO `dux_content` VALUES ('23', '17', '内置外包装', 'neizhiwaibaozhuang', '', '', '', '', '', '', '1422692220', '/Uploads/2015-01-31/54cc8f939a663.jpg', '', '0', '1', '本站', '28', '1', '', '1');
INSERT INTO `dux_content` VALUES ('24', '18', '展示架/堆头架', 'zhanshijiaduitoujia', '', '', '', '2', '', '', '1422784800', '/Uploads/2015-01-31/54cc8fd4612dc.jpg', '', '0', '1', '本站', '389', '1', '', '1');
INSERT INTO `dux_content` VALUES ('28', '22', '概念产品', 'gainianchanpin', '', '', '', '', '', '', '1422800580', '/Uploads/2015-01-31/54cc9124b1499.jpg', '', '0', '1', '本站', '50', '1', '', '1');
INSERT INTO `dux_content` VALUES ('29', '4', '第十届深圳文博会创意展架', 'dishijieshenwenbohuichuangyizh', '', '', '', '', '', '', '1422697560', '/Uploads/2015-01-31/54cca4b518f30.jpg', '', '0', '1', '本站', '88', '1', '', '1');
INSERT INTO `dux_content` VALUES ('30', '4', 'LED T5 T8灯管包装', 'LED-T5-T8dengguanbaozhuang', '', '', '', '', '', '', '1422697620', '/Uploads/2015-01-31/54cca50987935.jpg', '', '0', '1', '本站', '1068', '1', '', '1');
INSERT INTO `dux_content` VALUES ('31', '4', '新大洲摩托包装', 'xindazhoumotuobaozhuang', '', '', '', '', '', '', '1422697740', '/Uploads/2015-01-31/54cca57428354.jpg', '', '0', '1', '本站', '1758', '1', '', '1');
INSERT INTO `dux_content` VALUES ('32', '4', '精密仪器包装', 'jingmiyiqibaozhuang', '', '', '', '', '', '', '1422697800', '/Uploads/2015-01-31/54cca604adb8f.jpg', '', '0', '1', '方形纸管', '2327', '1', '', '1');
INSERT INTO `dux_content` VALUES ('34', '13', '方形纸管', 'fangxingzhiguan', '', '', '', '', '', '', '1422769740', '/Uploads/2015-02-01/54cdbedb450fa.jpg', '', '0', '1', '本站', '35', '1', '', '1');
INSERT INTO `dux_content` VALUES ('35', '13', '方形纸管', 'fangxingzhiguan53531029', '', '', '', '', '', '', '1422769860', '/Uploads/2015-02-01/54cdbf2204361.jpg', '', '0', '1', '本站', '32', '1', '', '1');
INSERT INTO `dux_content` VALUES ('36', '13', '方形纸管', 'fangxingzhiguan55561005', '', '', '', '', '', '', '1422769920', '/Uploads/2015-02-01/54cdbf5458227.jpg', '', '0', '1', '本站', '30', '1', '', '1');
INSERT INTO `dux_content` VALUES ('37', '13', '方形纸管', 'fangxingzhiguan97555497', '', '', '', '', '', '', '1422769980', '/Uploads/2015-02-01/54cdbf67ca935.jpg', '', '0', '1', '本站', '35', '1', '', '1');
INSERT INTO `dux_content` VALUES ('38', '13', '方形纸管', 'fangxingzhiguan51541024', '', '', '', '', '', '', '1422769980', '/Uploads/2015-02-01/54cdbf9dbf21a.jpg', '', '0', '1', '本站', '33', '1', '', '1');
INSERT INTO `dux_content` VALUES ('39', '13', '方形纸管', 'fangxingzhiguan97971021', '', '', '', '', '', '', '1422770040', '/Uploads/2015-02-01/54cdbfb8b3aff.jpg', '', '0', '1', '本站', '32', '1', '', '1');
INSERT INTO `dux_content` VALUES ('40', '13', '方形纸管', 'fangxingzhiguan10210149', '', '', '', '', '', '', '1422770700', '/Uploads/2015-02-01/54cdc24d399df.jpg', '', '0', '1', '本站', '41', '1', '', '1');
INSERT INTO `dux_content` VALUES ('41', '13', '方形纸管', 'fangxingzhiguan48101495', '', '', '', '', '', '', '1422770760', '/Uploads/2015-02-01/54cdc25e63942.jpg', '', '0', '1', '本站', '35', '1', '', '1');
INSERT INTO `dux_content` VALUES ('42', '13', '方形纸管', 'fangxingzhiguan55551015', '', '', '', '', '', '', '1422770760', '/Uploads/2015-02-01/54cdc270268b2.jpg', '', '0', '1', '本站', '32', '1', '', '1');
INSERT INTO `dux_content` VALUES ('43', '13', '方形纸管', 'fangxingzhiguan10010050', '', '', '', '', '', '', '1422770760', '/Uploads/2015-02-01/54cdc28bc2f23.jpg', '', '0', '1', '本站', '41', '1', '', '1');
INSERT INTO `dux_content` VALUES ('44', '13', '方形纸管', 'fangxingzhiguan57555497', '', '', '', '', '', '', '1422770820', '/Uploads/2015-02-01/54cdc2b650815.jpg', '', '0', '1', '本站', '34', '1', '', '1');
INSERT INTO `dux_content` VALUES ('45', '13', '方形纸管', 'fangxingzhiguan56575610', '', '', '', '', '', '', '1422770820', '/Uploads/2015-02-01/54cdc2c6b3aff.jpg', '', '0', '1', '本站', '46', '1', '', '1');
INSERT INTO `dux_content` VALUES ('46', '13', '方形纸管', 'fangxingzhiguan98571005', '', '', '', '2', '', '', '1422766800', '/Uploads/2015-02-01/54cdc36f04361.jpg', '', '0', '1', '本站', '60103', '1', '', '1');
INSERT INTO `dux_content` VALUES ('47', '14', '四面进叉托盘', 'simianjinchatuopan', '', '', '', '', '', '', '1422771240', '/Uploads/2015-02-01/54cdc4956b354.jpg', '', '0', '1', '本站', '40', '1', '', '1');
INSERT INTO `dux_content` VALUES ('48', '14', '四面进叉托盘', 'simianjinchatuopan57515757', '', '', '', '', '', '', '1422771420', '/Uploads/2015-02-01/54cdc528afdf6.jpg', '', '0', '1', '本站', '38', '1', '', '1');
INSERT INTO `dux_content` VALUES ('49', '14', '两面进叉托盘', 'liangmianjinchatuopan', '', '', '', '', '', '', '1422771480', '/Uploads/2015-02-01/54cdc5531748e.jpg', '', '0', '1', '本站', '49', '1', '', '1');
INSERT INTO `dux_content` VALUES ('50', '14', '两面进叉托盘', 'liangmianjinchatuopan55565798', '', '', '', '', '', '', '1422771540', '/Uploads/2015-02-01/54cdc573d2347.jpg', '', '0', '1', '本站', '47', '1', '', '1');
INSERT INTO `dux_content` VALUES ('51', '14', '四面进叉托盘', 'simianjinchatuopan10254985', '', '', '', '', '', '', '1422771540', '/Uploads/2015-02-01/54cdc598ca935.jpg', '', '0', '1', '本站', '37', '1', '', '1');
INSERT INTO `dux_content` VALUES ('52', '15', '包装箱', 'baozhuangxiang51545510', '', '', '', '', '', '', '1422771720', '/Uploads/2015-02-01/54cdc6616b354.jpg', '', '0', '1', '本站', '25', '1', '', '1');
INSERT INTO `dux_content` VALUES ('53', '15', '包装箱', 'baozhuangxiang51559710', '', '', '', '', '', '', '1422771840', '/Uploads/2015-02-01/54cdc6a150815.jpg', '', '0', '1', '本站', '36', '1', '', '1');
INSERT INTO `dux_content` VALUES ('54', '15', '包装箱', 'baozhuangxiang53975697', '', '', '', '', '', '', '1422771840', '/Uploads/2015-02-01/54cdc6c80fa7c.jpg', '', '0', '1', '本站', '29', '1', '', '1');
INSERT INTO `dux_content` VALUES ('55', '15', '包装箱', 'baozhuangxiang55101575', '', '', '', '', '', '', '1422771900', '/Uploads/2015-02-01/54cdc6e6a46db.jpg', '', '0', '1', '本站', '36', '1', '', '1');
INSERT INTO `dux_content` VALUES ('56', '15', '包装箱', 'baozhuangxiang55974948', '', '', '', '', '', '', '1422771900', '/Uploads/2015-02-01/54cdc7044cb0c.jpg', '', '0', '1', '本站', '35', '1', '', '1');
INSERT INTO `dux_content` VALUES ('57', '15', '包装箱', 'baozhuangxiang51541025', '', '', '', '', '', '', '1422771960', '/Uploads/2015-02-01/54cdc71ce5474.jpg', '', '0', '1', '本站', '45', '1', '', '1');
INSERT INTO `dux_content` VALUES ('58', '15', '包装箱', 'baozhuangxiang54525355', '', '', '', '', '', '', '1422771960', '/Uploads/2015-02-01/54cdc7455bf30.jpg', '', '0', '1', '本站', '33', '1', '', '1');
INSERT INTO `dux_content` VALUES ('59', '15', '包装箱', 'baozhuangxiang57565452', '', '', '', '', '', '', '1422772020', '/Uploads/2015-02-01/54cdc75c1eea0.jpg', '', '0', '1', '本站', '27', '1', '', '1');
INSERT INTO `dux_content` VALUES ('60', '15', '包装箱', 'baozhuangxiang97974948', '', '', '', '', '', '', '1422772020', '/Uploads/2015-02-01/54cdc76dd9d59.jpg', '', '0', '1', '本站', '37', '1', '', '1');
INSERT INTO `dux_content` VALUES ('61', '15', '包装箱', 'baozhuangxiang98541025', '', '', '', '', '', '', '1422772080', '/Uploads/2015-02-01/54cdc78b5bf30.jpg', '', '0', '1', '本站', '35', '1', '', '1');
INSERT INTO `dux_content` VALUES ('62', '15', '包装箱', 'baozhuangxiang10152575', '', '', '', '', '', '', '1422772080', '/Uploads/2015-02-01/54cdc7a25fc39.jpg', '', '0', '1', '本站', '35', '1', '', '1');
INSERT INTO `dux_content` VALUES ('63', '15', '包装箱', 'baozhuangxiang56521004', '', '', '', '', '', '', '1422772080', '/Uploads/2015-02-01/54cdc7b1e917d.jpg', '', '0', '1', '本站', '35', '1', '', '1');
INSERT INTO `dux_content` VALUES ('64', '15', '包装箱', 'baozhuangxiang97561001', '', '', '', '', '', '', '1422772140', '/Uploads/2015-02-01/54cdc7ddbb511.jpg', '', '0', '1', '本站', '34', '1', '', '1');
INSERT INTO `dux_content` VALUES ('65', '15', '包装箱', 'baozhuangxiang99501015', '', '', '', '', '', '', '1422772140', '/Uploads/2015-02-01/54cdc7e9e917d.jpg', '', '0', '1', '本站', '33', '1', '', '1');
INSERT INTO `dux_content` VALUES ('66', '15', '包装箱', 'baozhuangxiang10156505', '', '', '', '', '', '', '1422772200', '/Uploads/2015-02-01/54cdc7fdbb511.jpg', '', '0', '1', '本站', '34', '1', '', '1');
INSERT INTO `dux_content` VALUES ('67', '15', '包装箱', 'baozhuangxiang48555150', '', '', '', '', '', '', '1422772200', '/Uploads/2015-02-01/54cdc81a450fa.jpg', '', '0', '1', '本站', '38', '1', '', '1');
INSERT INTO `dux_content` VALUES ('68', '15', '包装箱', 'baozhuangxiang', '', '', '', '2', '', '', '1422772200', '/Uploads/2015-02-01/54cdc82b2a5bb.jpg', '', '0', '1', '本站', '9624', '1', '', '1');
INSERT INTO `dux_content` VALUES ('69', '16', '框架包装', 'kuangjiabaozhuang10249555', '', '', '', '', '', '', '1422772320', '/Uploads/2015-02-01/54cdc8871748e.jpg', '', '0', '1', '本站', '42', '1', '', '1');
INSERT INTO `dux_content` VALUES ('70', '16', '框架包装', 'kuangjiabaozhuang49539952', '', '', '', '', '', '', '1422772320', '/Uploads/2015-02-01/54cdc8a72a5bb.jpg', '', '0', '1', '本站', '32', '1', '', '1');
INSERT INTO `dux_content` VALUES ('71', '16', '框架包装', 'kuangjiabaozhuang10197565', '', '', '', '', '', '', '1422772380', '/Uploads/2015-02-01/54cdc968915ae.jpg', '', '0', '1', '本站', '37', '1', '', '1');
INSERT INTO `dux_content` VALUES ('72', '16', '框架包装', 'kuangjiabaozhuang49545598', '', '', '', '', '', '', '1422772560', '/Uploads/2015-02-01/54cdc978b3aff.jpg', '', '0', '1', '本站', '33', '1', '', '1');
INSERT INTO `dux_content` VALUES ('73', '16', '框架包装', 'kuangjiabaozhuang10250979', '', '', '', '', '', '', '1422772560', '/Uploads/2015-02-01/54cdc987bf21a.jpg', '', '0', '1', '本站', '35', '1', '', '1');
INSERT INTO `dux_content` VALUES ('74', '16', '框架包装', 'kuangjiabaozhuang10299101', '', '', '', '', '', '', '1422772560', '/Uploads/2015-02-01/54cdc9a335cd6.jpg', '', '0', '1', '本站', '41', '1', '', '1');
INSERT INTO `dux_content` VALUES ('75', '16', '框架包装', 'kuangjiabaozhuang10298989', '', '', '', '', '', '', '1422772620', '/Uploads/2015-02-01/54cdc9b176a6f.jpg', '', '0', '1', '本站', '46', '1', '', '1');
INSERT INTO `dux_content` VALUES ('76', '16', '框架包装', 'kuangjiabaozhuang10253565', '', '', '', '', '', '', '1422772680', '/Uploads/2015-02-01/54cdc9eba83e4.jpg', '', '0', '1', '本站', '33', '1', '', '1');
INSERT INTO `dux_content` VALUES ('77', '16', '框架包装', 'kuangjiabaozhuang48989897', '', '', '', '', '', '', '1422772680', '/Uploads/2015-02-01/54cdc9f935cd6.jpg', '', '0', '1', '本站', '41', '1', '', '1');
INSERT INTO `dux_content` VALUES ('78', '16', '框架包装', 'kuangjiabaozhuang98535655', '', '', '', '', '', '', '1422772680', '/Uploads/2015-02-01/54cdca1fe176b.jpg', '', '0', '1', '本站', '40', '1', '', '1');
INSERT INTO `dux_content` VALUES ('79', '16', '框架包装', 'kuangjiabaozhuang10056545', '', '', '', '', '', '', '1422772740', '/Uploads/2015-02-01/54cdca3385e93.jpg', '', '0', '1', '本站', '25', '1', '', '1');
INSERT INTO `dux_content` VALUES ('80', '16', '框架包装', 'kuangjiabaozhuang10010110', '', '', '', '', '', '', '1422772740', '/Uploads/2015-02-01/54cdca4c1eea0.jpg', '', '0', '1', '本站', '48', '1', '', '1');
INSERT INTO `dux_content` VALUES ('81', '16', '框架包装', 'kuangjiabaozhuang97101575', '', '', '', '', '', '', '1422772800', '/Uploads/2015-02-01/54cdca60b7808.jpg', '', '0', '1', '本站', '34', '1', '', '1');
INSERT INTO `dux_content` VALUES ('82', '16', '框架包装', 'kuangjiabaozhuang56485298', '', '', '', '2', '', '', '1422772800', '/Uploads/2015-02-01/54cdca7400658.jpg', '', '0', '1', '本站', '1573', '1', '', '1');
INSERT INTO `dux_content` VALUES ('83', '16', '框架包装', 'kuangjiabaozhuang51551015', '', '', '', '', '', '', '1422772800', '/Uploads/2015-02-01/54cdcaa876a6f.jpg', '', '0', '1', '本站', '51', '1', '', '1');
INSERT INTO `dux_content` VALUES ('84', '16', '框架包装', 'kuangjiabaozhuang49100545', '', '', '', '', '', '', '1422772860', '/Uploads/2015-02-01/54cdcabdac0ed.jpg', '', '0', '1', '本站', '42', '1', '', '1');
INSERT INTO `dux_content` VALUES ('85', '16', '框架包装', 'kuangjiabaozhuang', '', '', '', '', '', '', '1422772920', '/Uploads/2015-02-01/54cdcacdb3aff.jpg', '', '0', '1', '本站', '38', '1', '', '1');
INSERT INTO `dux_content` VALUES ('86', '17', '纸管滚轴', 'zhiguangunzhou', '', '', '', '', '', '', '1422773100', '/Uploads/2015-02-01/54cdcc095fc39.jpg', '', '0', '1', '本站', '36', '1', '', '1');
INSERT INTO `dux_content` VALUES ('87', '17', '内置外包装', 'neizhiwaibaozhuang97559755', '', '', '', '', '', '', '1422773280', '/Uploads/2015-02-01/54cdcc471748e.jpg', '', '0', '1', '本站', '34', '1', '', '1');
INSERT INTO `dux_content` VALUES ('88', '17', '内置外包装', 'neizhiwaibaozhuang10255101', '', '', '', '', '', '', '1422773280', '/Uploads/2015-02-01/54cdcc5c268b2.jpg', '', '0', '1', '本站', '30', '1', '', '1');
INSERT INTO `dux_content` VALUES ('89', '17', '内置外包装', 'neizhiwaibaozhuang10050975', '', '', '', '', '', '', '1422773340', '/Uploads/2015-02-01/54cdcca45bf30.jpg', '', '0', '1', '本站', '40', '1', '', '1');
INSERT INTO `dux_content` VALUES ('90', '17', '内置外包装', 'neizhiwaibaozhuang10197525', '', '', '', '', '', '', '1422773400', '/Uploads/2015-02-01/54cdccbc915ae.jpg', '', '0', '1', '本站', '42', '1', '', '1');
INSERT INTO `dux_content` VALUES ('91', '17', '内置外包装', 'neizhiwaibaozhuang56100505', '', '', '', '', '', '', '1422773400', '/Uploads/2015-02-01/54cdcce6b7808.jpg', '', '0', '1', '本站', '37', '1', '', '1');
INSERT INTO `dux_content` VALUES ('92', '17', '内置外包装', 'neizhiwaibaozhuang55524951', '', '', '', '', '', '', '1422773460', '/Uploads/2015-02-01/54cdccf4d9d59.jpg', '', '0', '1', '本站', '43', '1', '', '1');
INSERT INTO `dux_content` VALUES ('93', '17', '内置外包装', 'neizhiwaibaozhuang10056579', '', '', '', '', '', '', '1422773460', '/Uploads/2015-02-01/54cdcd0ab7808.jpg', '', '0', '1', '本站', '35', '1', '', '1');
INSERT INTO `dux_content` VALUES ('94', '17', '内置外包装', 'neizhiwaibaozhuang10253565', '', '', '', '', '', '', '1422773460', '/Uploads/2015-02-01/54cdcd1d63942.jpg', '', '0', '1', '本站', '39', '1', '', '1');
INSERT INTO `dux_content` VALUES ('95', '17', '内置外包装', 'neizhiwaibaozhuang97555497', '', '', '', '', '', '', '1422773520', '/Uploads/2015-02-01/54cdcd38f0b8f.jpg', '', '0', '1', '本站', '40', '1', '', '1');
INSERT INTO `dux_content` VALUES ('96', '17', '内置外包装', 'neizhiwaibaozhuang10255975', '', '', '', '', '', '', '1422773520', '/Uploads/2015-02-01/54cdcd4e1748e.jpg', '', '0', '1', '本站', '39', '1', '', '1');
INSERT INTO `dux_content` VALUES ('97', '17', '内置外包装', 'neizhiwaibaozhuang51991015', '', '', '', '', '', '', '1422773580', '/Uploads/2015-02-01/54cdcd612e2c4.jpg', '', '0', '1', '本站', '36', '1', '', '1');
INSERT INTO `dux_content` VALUES ('98', '17', '内置外包装', 'neizhiwaibaozhuang56511005', '', '', '', '', '', '', '1422773580', '/Uploads/2015-02-01/54cdcd76afdf6.jpg', '', '0', '1', '本站', '35', '1', '', '1');
INSERT INTO `dux_content` VALUES ('99', '17', '内置外包装', 'neizhiwaibaozhuang50555550', '', '', '', '2', '', '', '1422781200', '/Uploads/2015-02-01/54cdcd86d2347.jpg', '', '0', '1', '本站', '1605', '1', '', '1');
INSERT INTO `dux_content` VALUES ('100', '18', '展示架', 'zhanshijia', '', '', '', '', '', '', '1422773640', '/Uploads/2015-02-01/54cdcdf0952b7.jpg', '', '0', '1', '本站', '31', '1', '', '1');
INSERT INTO `dux_content` VALUES ('101', '18', '展示架', 'zhanshijia57485251', '', '', '', '', '', '', '1422773760', '/Uploads/2015-02-01/54cdce211b197.jpg', '', '0', '1', '本站', '37', '1', '', '1');
INSERT INTO `dux_content` VALUES ('102', '18', '展示架', 'zhanshijia50535650', '', '', '', '', '', '', '1422773760', '/Uploads/2015-02-01/54cdce40399df.jpg', '', '0', '1', '本站', '28', '1', '', '1');
INSERT INTO `dux_content` VALUES ('103', '18', '展示架', 'zhanshijia52100100', '', '', '', '', '', '', '1422773820', '/Uploads/2015-02-01/54cdce6231fcd.jpg', '', '0', '1', '本站', '30', '1', '', '1');
INSERT INTO `dux_content` VALUES ('104', '18', '展示架', 'zhanshijia54999757', '', '', '', '', '', '', '1422773820', '/Uploads/2015-02-01/54cdce84e176b.jpg', '', '0', '1', '本站', '28', '1', '', '1');
INSERT INTO `dux_content` VALUES ('105', '18', '展示架', 'zhanshijia10299501', '', '', '', '', '', '', '1422773880', '/Uploads/2015-02-01/54cdce9d639a8.jpg', '', '0', '1', '本站', '34', '1', '', '1');
INSERT INTO `dux_content` VALUES ('106', '18', '展示架', 'zhanshijia48485648', '', '', '', '', '', '', '1422773880', '/Uploads/2015-02-01/54cdcebe32033.jpg', '', '0', '1', '本站', '30', '1', '', '1');
INSERT INTO `dux_content` VALUES ('107', '18', '展示架', 'zhanshijia10049555', '', '', '', '', '', '', '1422773940', '/Uploads/2015-02-01/54cdcecc0bdd9.jpg', '', '0', '1', '本站', '26', '1', '', '1');
INSERT INTO `dux_content` VALUES ('108', '18', '展示架', 'zhanshijia98535650', '', '', '', '', '', '', '1422773940', '/Uploads/2015-02-01/54cdcef76f0c3.jpg', '', '0', '1', '本站', '30', '1', '', '1');
INSERT INTO `dux_content` VALUES ('109', '18', '展示架', 'zhanshijia10299975', '', '', '', '', '', '', '1422774000', '/Uploads/2015-02-01/54cdcf0a89c02.jpg', '', '0', '1', '本站', '33', '1', '', '1');
INSERT INTO `dux_content` VALUES ('110', '18', '展示架', 'zhanshijia10098555', '', '', '', '', '', '', '1422774000', '/Uploads/2015-02-01/54cdcf2ad60b6.jpg', '', '0', '1', '本站', '26', '1', '', '1');
INSERT INTO `dux_content` VALUES ('111', '18', '堆头架', 'duitoujia', '', '', '', '', '', '', '1422774060', '/Uploads/2015-02-01/54cdcf6b5bf96.jpg', '', '0', '1', '本站', '35', '1', '', '1');
INSERT INTO `dux_content` VALUES ('113', '18', '堆头架', 'duitoujia55545554', '', '', '', '', '', '', '1422774120', '/Uploads/2015-02-01/54cdd0851b1fd.jpg', '', '0', '1', '本站', '27', '1', '', '1');
INSERT INTO `dux_content` VALUES ('114', '18', '堆头架', 'duitoujia50531029', '', '', '', '', '', '', '1422774360', '/Uploads/2015-02-01/54cdd09ee54da.jpg', '', '0', '1', '本站', '30', '1', '', '1');
INSERT INTO `dux_content` VALUES ('115', '18', '堆头架', 'duitoujia55995499', '', '', '', '', '', '', '1422774420', '/Uploads/2015-02-01/54cdd0b448e69.jpg', '', '0', '1', '本站', '34', '1', '', '1');
INSERT INTO `dux_content` VALUES ('116', '18', '堆头架', 'duitoujia10148485', '', '', '', '', '', '', '1422774420', '/Uploads/2015-02-01/54cdd0cb0fae2.jpg', '', '0', '1', '本站', '28', '1', '', '1');
INSERT INTO `dux_content` VALUES ('118', '18', '堆头架', 'duitoujia10257574', '', '', '', '', '', '', '1422774420', '/Uploads/2015-02-01/54cdd0e52e32a.jpg', '', '0', '1', '本站', '29', '1', '', '1');
INSERT INTO `dux_content` VALUES ('119', '18', '置物架', 'zhiwujia', '', '', '', '', '', '', '1422774480', '/Uploads/2015-02-01/54cdd112137eb.jpg', '', '0', '1', '本站', '31', '1', '', '1');
INSERT INTO `dux_content` VALUES ('120', '18', '陈列柜', 'chenliegui', '', '', '', '', '', '', '1422774540', '/Uploads/2015-02-01/54cdd12c89c02.jpg', '', '0', '1', '本站', '28', '1', '', '1');
INSERT INTO `dux_content` VALUES ('121', '18', '陈列柜', 'chenliegui56545554', '', '', '', '', '', '', '1422774540', '/Uploads/2015-02-01/54cdd14499026.jpg', '', '0', '1', '本站', '32', '1', '', '1');
INSERT INTO `dux_content` VALUES ('122', '18', '陈列柜', 'chenliegui51579910', '', '', '', '', '', '', '1422774600', '/Uploads/2015-02-01/54cdd15a4145c.jpg', '', '0', '1', '本站', '38', '1', '', '1');
INSERT INTO `dux_content` VALUES ('123', '18', '置物架', 'zhiwujia10252561', '', '', '', '', '', '', '1422774600', '/Uploads/2015-02-01/54cdd187953de.jpg', '', '0', '1', '本站', '41', '1', '', '1');
INSERT INTO `dux_content` VALUES ('124', '18', '陈列柜', 'chenliegui10256505', '', '', '', '', '', '', '1422774660', '/Uploads/2015-02-01/54cdd1b9ddbfb.jpg', '', '0', '1', '本站', '30', '1', '', '1');
INSERT INTO `dux_content` VALUES ('125', '18', '展示架', 'zhanshijia56975653', '', '', '', '', '', '', '1422774720', '/Uploads/2015-02-01/54cdd1db22da9.jpg', '', '0', '1', '本站', '42', '1', '', '1');
INSERT INTO `dux_content` VALUES ('126', '18', '展示架', 'zhanshijia56495554', '', '', '', '', '', '', '1422774720', '/Uploads/2015-02-01/54cdd1f5d9f59.jpg', '', '0', '1', '本站', '34', '1', '', '1');
INSERT INTO `dux_content` VALUES ('127', '18', '展示架', 'zhanshijia53101535', '', '', '', '', '', '', '1422774780', '/Uploads/2015-02-01/54cdd211a85e4.jpg', '', '0', '1', '本站', '38', '1', '', '1');
INSERT INTO `dux_content` VALUES ('128', '18', '展示架', 'zhanshijia54981025', '', '', '', '', '', '', '1422774780', '/Uploads/2015-02-01/54cdd22fe93e3.jpg', '', '0', '1', '本站', '37', '1', '', '1');
INSERT INTO `dux_content` VALUES ('129', '18', '展示架', 'zhanshijia10299979', '', '', '', '', '', '', '1422774780', '/Uploads/2015-02-01/54cdd24d678b1.jpg', '', '0', '1', '本站', '37', '1', '', '1');
INSERT INTO `dux_content` VALUES ('130', '18', '展示架', 'zhanshijia52989855', '', '', '', '', '', '', '1422774840', '/Uploads/2015-02-01/54cdd26239c7d.jpg', '', '0', '1', '本站', '30', '1', '', '1');
INSERT INTO `dux_content` VALUES ('132', '18', '展示架', 'zhanshijia99995149', '', '', '', '', '', '', '1422774840', '/Uploads/2015-02-01/54cdd28fe944a.jpg', '', '0', '1', '本站', '26', '1', '', '1');
INSERT INTO `dux_content` VALUES ('134', '19', '商装', 'shangzhuang', '', '', '', '', '', '', '1422775020', '/Uploads/2015-02-01/54cdd36d91948.jpg', '', '0', '1', '本站', '37', '1', '', '1');
INSERT INTO `dux_content` VALUES ('135', '19', '商装', 'shangzhuang49501015', '', '', '', '', '', '', '1422775140', '/Uploads/2015-02-01/54cdd37dbb8ab.jpg', '', '0', '1', '本站', '40', '1', '', '1');
INSERT INTO `dux_content` VALUES ('136', '19', '商装/家装', 'shangzhuangjiazhuang', '', '', '', '2', '', '', '1422789540', '/Uploads/2015-02-01/54cdd38d1f23a.jpg', '', '0', '1', '本站', '130', '1', '', '1');
INSERT INTO `dux_content` VALUES ('137', '19', '特装', 'tezhuang', '', '', '', '', '', '', '1422775140', '/Uploads/2015-02-01/54cdd3a0009f2.jpg', '', '0', '1', '本站', '40', '1', '', '1');
INSERT INTO `dux_content` VALUES ('138', '20', '便携凳', 'bianxiedeng', '', '', '', '', '', '', '1422775260', '/Uploads/2015-02-01/54cdd4897ab12.jpg', '', '0', '1', '本站', '30', '1', '', '1');
INSERT INTO `dux_content` VALUES ('139', '20', '便携凳', 'bianxiedeng99539950', '', '', '', '', '', '', '1422775440', '/Uploads/2015-02-01/54cdd4b7d63ea.jpg', '', '0', '1', '本站', '35', '1', '', '1');
INSERT INTO `dux_content` VALUES ('140', '20', '便携凳', 'bianxiedeng97515051', '', '', '', '', '', '', '1422775440', '/Uploads/2015-02-01/54cdd4c76b6ee.jpg', '', '0', '1', '本站', '27', '1', '', '1');
INSERT INTO `dux_content` VALUES ('141', '20', '桌子', 'zhuozi', '', '', '', '', '', '', '1422775500', '/Uploads/2015-02-01/54cdd4d9bb8ab.jpg', '', '0', '1', '本站', '32', '1', '', '1');
INSERT INTO `dux_content` VALUES ('142', '20', '衣柜', 'yigui', '', '', '', '', '', '', '1422775500', '/Uploads/2015-02-01/54cdd583ac487.jpg', '', '0', '1', '本站', '33', '1', '', '1');
INSERT INTO `dux_content` VALUES ('143', '20', '衣柜', 'yigui10298985', '', '', '', '', '', '', '1422775680', '/Uploads/2015-02-01/54cdd59a63cdc.jpg', '', '0', '1', '本站', '25', '1', '', '1');
INSERT INTO `dux_content` VALUES ('144', '20', '床', 'chuang', '', '', '', '', '', '', '1422775680', '/Uploads/2015-02-01/54cdd5b626c4c.jpg', '', '0', '1', '本站', '38', '1', '', '1');
INSERT INTO `dux_content` VALUES ('145', '20', '衣柜', 'yigui10155979', '', '', '', '', '', '', '1422775740', '/Uploads/2015-02-01/54cdd5d95c2ca.jpg', '', '0', '1', '本站', '43', '1', '', '1');
INSERT INTO `dux_content` VALUES ('146', '20', '桌子', 'zhuozi10149555', '', '', '', '', '', '', '1422775740', '/Uploads/2015-02-01/54cdd613b0190.jpg', '', '0', '1', '本站', '33', '1', '', '1');
INSERT INTO `dux_content` VALUES ('147', '20', '柜子', 'guizi', '', '', '', '', '', '', '1422775800', '/Uploads/2015-02-01/54cdd633ed220.jpg', '', '0', '1', '本站', '25', '1', '', '1');
INSERT INTO `dux_content` VALUES ('148', '20', '柜子', 'guizi10098102', '', '', '', '', '', '', '1422775860', '/Uploads/2015-02-01/54cdd666da0f3.jpg', '', '0', '1', '本站', '26', '1', '', '1');
INSERT INTO `dux_content` VALUES ('149', '20', '柜子', 'guizi50481021', '', '', '', '', '', '', '1422775860', '/Uploads/2015-02-01/54cdd67c63cdc.jpg', '', '0', '1', '本站', '35', '1', '', '1');
INSERT INTO `dux_content` VALUES ('150', '20', '组合柜', 'zuhegui', '', '', '', '', '', '', '1422775920', '/Uploads/2015-02-01/54cdd6d1dddfc.jpg', '', '0', '1', '本站', '35', '1', '', '1');
INSERT INTO `dux_content` VALUES ('151', '20', '组合柜', 'zuhegui56531021', '', '', '', '', '', '', '1422776040', '/Uploads/2015-02-01/54cdd70339d79.jpg', '', '0', '1', '本站', '33', '1', '', '1');
INSERT INTO `dux_content` VALUES ('152', '20', '组合柜', 'zuhegui98100100', '', '', '', '', '', '', '1422776040', '/Uploads/2015-02-01/54cdd7149935a.jpg', '', '0', '1', '本站', '29', '1', '', '1');
INSERT INTO `dux_content` VALUES ('153', '20', '桌子+多层架', 'zhuoziduocengjia', '', '', '', '', '', '', '1422776040', '/Uploads/2015-02-01/54cdd730da0f3.jpg', '', '0', '1', '本站', '37', '1', '', '1');
INSERT INTO `dux_content` VALUES ('154', '20', '沙发', 'shafa', '', '', '', '', '', '', '1422776100', '/Uploads/2015-02-01/54cdd75650baf.jpg', '', '0', '1', '本站', '35', '1', '', '1');
INSERT INTO `dux_content` VALUES ('155', '20', '茶几', 'chaji', '', '', '', '', '', '', '1422776100', '/Uploads/2015-02-01/54cdd7670fe16.jpg', '', '0', '1', '本站', '37', '1', '', '1');
INSERT INTO `dux_content` VALUES ('156', '20', '床', 'chuang52565450', '', '', '', '', '', '', '1422776160', '/Uploads/2015-02-01/54cdd77dcaccf.jpg', '', '0', '1', '本站', '30', '1', '', '1');
INSERT INTO `dux_content` VALUES ('157', '20', '床', 'chuang52975655', '', '', '', '', '', '', '1422776160', '/Uploads/2015-02-01/54cdd790ce9d8.jpg', '', '0', '1', '本站', '37', '1', '', '1');
INSERT INTO `dux_content` VALUES ('158', '20', '方凳', 'fangdeng', '', '', '', '', '', '', '1422776160', '/Uploads/2015-02-01/54cdd7b236070.jpg', '', '0', '1', '本站', '44', '1', '', '1');
INSERT INTO `dux_content` VALUES ('159', '20', '方凳', 'fangdeng57489949', '', '', '', '', '', '', '1422776220', '/Uploads/2015-02-01/54cdd7c6a0d6c.jpg', '', '0', '1', '本站', '31', '1', '', '1');
INSERT INTO `dux_content` VALUES ('160', '20', '家居/办公', 'jiajubangong', '', '', '', '2', '', '', '1422794220', '/Uploads/2015-02-01/54cdd7dbed220.jpg', '', '0', '1', '本站', '142', '1', '', '1');
INSERT INTO `dux_content` VALUES ('161', '21', '临时安置隔断', 'linshianzhigeduan', '', '', '', '', '', '', '1422776280', '/Uploads/2015-02-01/54cdd84f91948.jpg', '', '0', '1', '本站', '41', '1', '', '1');
INSERT INTO `dux_content` VALUES ('162', '21', '临时安置隔断', 'linshianzhigeduan51565053', '', '', '', '', '', '', '1422776400', '/Uploads/2015-02-01/54cdd8636f3f7.jpg', '', '0', '1', '本站', '43', '1', '', '1');
INSERT INTO `dux_content` VALUES ('163', '21', '房舍', 'fangshe', '', '', '', '', '', '', '1422776400', '/Uploads/2015-02-01/54cdd8a5e580e.jpg', '', '0', '1', '本站', '32', '1', '', '1');
INSERT INTO `dux_content` VALUES ('164', '21', '房舍', 'fangshe10057535', '', '', '', '', '房舍', '房舍', '1422776520', '/Uploads/2015-02-01/54cdd8d40fe16.jpg', '', '0', '1', '本站', '35', '1', '', '1');
INSERT INTO `dux_content` VALUES ('165', '21', '亭子', 'tingzi', '', '', '', '', '', '', '1422776520', '/Uploads/2015-02-01/54cddc5408404.jpg', '', '0', '1', '本站', '36', '1', '', '1');
INSERT INTO `dux_content` VALUES ('166', '21', '房屋/临时安置', 'fangwulinshianzhi', '', '', '', '2', '', '', '1422795600', '/Uploads/2015-02-01/54cddc6ada0f3.jpg', '', '0', '1', '本站', '136', '1', '', '1');
INSERT INTO `dux_content` VALUES ('167', '22', '组合柜', 'zuhegui49574957', '', '', '', '', '', '', '1422777420', '/Uploads/2015-02-01/54cde569a877e.jpg', '', '0', '1', '本站', '41', '1', '', '1');
INSERT INTO `dux_content` VALUES ('168', '22', '组合柜', 'zuhegui49559798', '', '', '', '', '', '', '1422779760', '/Uploads/2015-02-01/54cde57b50baf.jpg', '', '0', '1', '本站', '32', '1', '', '1');
INSERT INTO `dux_content` VALUES ('169', '22', '组合柜', 'zuhegui50974810', '', '', '', '', '', '', '1422779760', '/Uploads/2015-02-01/54cde58b6f3f7.jpg', '', '0', '1', '本站', '40', '1', '', '1');
INSERT INTO `dux_content` VALUES ('170', '22', '组合柜', 'zuhegui98985598', '', '', '', '', '', '', '1422779760', '/Uploads/2015-02-01/54cde5b017828.jpg', '', '0', '1', '本站', '41', '1', '', '1');
INSERT INTO `dux_content` VALUES ('171', '22', '折叠架', 'zhediejia', '', '', '', '', '', '', '1422779820', '/Uploads/2015-02-01/54cde5d4b7ba2.jpg', '', '0', '1', '本站', '36', '1', '', '1');
INSERT INTO `dux_content` VALUES ('172', '22', '折叠架', 'zhediejia50529910', '', '', '', '', '', '', '1422779820', '/Uploads/2015-02-01/54cde5ec0fe16.jpg', '', '0', '1', '本站', '37', '1', '', '1');
INSERT INTO `dux_content` VALUES ('173', '22', '折叠架', 'zhediejia99101535', '', '', '', '', '', '', '1422779880', '/Uploads/2015-02-01/54cde5fbb0190.jpg', '', '0', '1', '本站', '42', '1', '', '1');
INSERT INTO `dux_content` VALUES ('174', '19', '形象墙+前台', 'xingxiangqiangqiantai', '', '', '', '', '', '', '1422782340', '/Uploads/2015-02-01/54cdefc61f2a0.jpg', '', '0', '1', '本站', '39', '1', '', '1');
INSERT INTO `dux_content` VALUES ('175', '19', '形象墙+前台', 'xingxiangqiangqiantai57991019', '', '', '', '', '', '', '1422782400', '/Uploads/2015-02-01/54cdf020454fa.jpg', '', '0', '1', '本站', '33', '1', '', '1');
INSERT INTO `dux_content` VALUES ('176', '19', '镂空隔断（灯光效果）', 'konggeduandengguangxiaoguo', '', '', '', '', '', '', '1422782460', '/Uploads/2015-02-01/54cdf042e1b6b.jpg', '', '0', '1', '本站', '48', '1', '', '1');
INSERT INTO `dux_content` VALUES ('177', '19', '镂空隔断', 'konggeduan', '', '', '', '', '', '', '1422782520', '/Uploads/2015-02-01/54cdf0765491e.jpg', '', '0', '1', '本站', '42', '1', '', '1');
INSERT INTO `dux_content` VALUES ('178', '19', '隔断+储物架', 'geduanchuwujia', '', '', '', '', '', '', '1422782580', '/Uploads/2015-02-01/54cdf08fa87e4.jpg', '', '0', '1', '本站', '37', '1', '', '1');
INSERT INTO `dux_content` VALUES ('179', '19', '隔断+储物架', 'geduanchuwujia99974810', '', '', '', '', '', '', '1422782580', '/Uploads/2015-02-01/54cdf0c304761.jpg', '', '0', '1', '本站', '44', '1', '', '1');
INSERT INTO `dux_content` VALUES ('180', '19', '隔断+储物架', 'geduanchuwujia48561009', '', '', '', '', '', '', '1422782640', '/Uploads/2015-02-01/54cdf0d65c330.jpg', '', '0', '1', '本站', '40', '1', '', '1');
INSERT INTO `dux_content` VALUES ('181', '19', '隔断+储物架', 'geduanchuwujia55491025', '', '', '', '', '', '', '1422782640', '/Uploads/2015-02-01/54cdf0f067a4b.jpg', '', '0', '1', '本站', '33', '1', '', '1');
INSERT INTO `dux_content` VALUES ('182', '14', '四面进叉托盘', 'simianjinchatuopan10255515', '', '', '', '', '', '', '1422784680', '/Uploads/2015-02-01/54cdf8d96bb54.jpg', '', '0', '1', '本站', '40', '1', '', '1');
INSERT INTO `dux_content` VALUES ('183', '14', '四面进叉托盘', 'simianjinchatuopan10255971', '', '', '', '', '', '', '1422784740', '/Uploads/2015-02-01/54cdf8fc04b61.jpg', '', '0', '1', '本站', '39', '1', '', '1');
INSERT INTO `dux_content` VALUES ('184', '14', '物流托盘', 'wuliutuopan', '', '', '', '2', '', '', '1422770940', '/Uploads/2015-02-01/54cdf90c8e0a5.jpg', '', '0', '1', '本站', '19694', '1', '', '1');
INSERT INTO `dux_content` VALUES ('185', '14', '四面进叉托盘', 'simianjinchatuopan99575397', '', '', '', '', '', '', '1422784740', '/Uploads/2015-02-01/54cdf918233a9.jpg', '', '0', '1', '本站', '40', '1', '', '1');
INSERT INTO `dux_content` VALUES ('186', '27', '广州海方科技股份有限公司成立', 'guangzhouhaifangkejigufenyouxi', '', '', '', '', '', '', '981082260', '', '', '0', '1', '本站', '0', '1', '', '1');
INSERT INTO `dux_content` VALUES ('188', '27', '方形纸管连接件获得“国家实用新型专利证书”', 'fangxingzhiguanlianjiejianhuod', '', '', '', '', '', '', '1367377080', '', '', '0', '1', '本站', '0', '1', '', '1');
INSERT INTO `dux_content` VALUES ('189', '27', '广州海方科技股份有限公司获得“广州民营科技企业”荣誉称号', 'guangzhouhaifangkejigufenyouxi52991024', '', '', '', '', '', '', '1343876460', '', '', '0', '1', '本站', '0', '1', '', '1');
INSERT INTO `dux_content` VALUES ('190', '27', '山东海方纸制品科技有限公司成立', 'shandonghaifangzhizhipinkejiyo', '', '', '', '', '', '', '1383361440', '', '', '0', '1', '本站', '2', '1', '', '1');
INSERT INTO `dux_content` VALUES ('191', '27', '方形纸管托盘获得国家“实用新型专利证书”', 'fangxingzhiguantuopanhuodeguoj', '', '', '', '', '', '', '1401419100', '', '', '0', '1', '本站', '0', '1', '', '1');
INSERT INTO `dux_content` VALUES ('192', '27', '方形纸管框架包装结构获得“实用新型专利证书”', 'fangxingzhiguankuangjiabaozhua', '', '', '', '', '', '', '1401419220', '', '', '0', '1', '本站', '0', '1', '', '1');
INSERT INTO `dux_content` VALUES ('193', '27', '河北海方纸制品科技有限公司成立', 'hebeihaifangzhizhipinkejiyouxi', '', '', '', '', '', '', '1393729800', '', '', '0', '1', '本站', '1', '1', '', '1');
INSERT INTO `dux_content` VALUES ('194', '27', '方形纸管制造设备获得“国家发明专利证书” ', 'fangxingzhiguanzhizaoshebeihuo10057102', '', '', '', '', '', '', '1259723700', '', '', '0', '1', '本站', '0', '1', '', '1');
INSERT INTO `dux_content` VALUES ('195', '27', '新型方形纸管制造设备获得“国家发明专利证书” ', 'xinxingfangxingzhiguanzhizaosh', '', '', '', '', '', '', '1308107700', '', '', '0', '1', '本站', '0', '1', '', '1');
INSERT INTO `dux_content` VALUES ('196', '27', '方形纸管框架连接结构获得“国家实用新型专利证书” ', 'fangxingzhiguankuangjialianjie', '', '', '', '', '', '', '1409714340', '', '', '0', '1', '本站', '1', '1', '', '1');
INSERT INTO `dux_content` VALUES ('197', '4', '免熏蒸包装箱（内部结构）', 'mianxunzhengbaozhuangxiangneib', '', '', '', '', '', '', '1422850860', '/Uploads/2015-02-02/54cefbe3382d6.jpg', '', '0', '1', '本站', '78', '1', '', '1');
INSERT INTO `dux_content` VALUES ('198', '4', '免熏蒸包装箱', 'mianxunzhengbaozhuangxiang', '', '', '', '', '', '', '1422851040', '/Uploads/2015-02-02/54cefc332cbbb.jpg', '', '0', '1', '本站', '112', '1', '', '1');
INSERT INTO `dux_content` VALUES ('199', '4', 'LED屏免熏蒸包装箱', 'LEDpingmianxunzhengbaozhuangxi', '', '', '', '', '', '', '1422851100', '/Uploads/2015-02-02/54cefc784b403.jpg', '', '0', '1', '本站', '104', '1', '', '1');
INSERT INTO `dux_content` VALUES ('200', '4', '免熏蒸包装箱（连接件结构）', 'mianxunzhengbaozhuangxianglian', '', '', '', '', '', '', '1422851220', '/Uploads/2015-02-02/54cefcac308c4.jpg', '', '0', '1', '本站', '46', '1', '', '1');
INSERT INTO `dux_content` VALUES ('201', '4', '免熏蒸包装箱（连接件结构）', 'mianxunzhengbaozhuangxianglian50995750', '', '', '', '', '', '', '1422851220', '/Uploads/2015-02-02/54cefcd093bae.jpg', '', '0', '1', '本站', '58', '1', '', '1');
INSERT INTO `dux_content` VALUES ('202', '4', '精密仪器包装箱', 'jingmiyiqibaozhuangxiang', '', '', '', '', '', '', '1422851280', '/Uploads/2015-02-02/54cefceb62239.jpg', '', '0', '1', '本站', '112', '1', '', '1');
INSERT INTO `dux_content` VALUES ('203', '4', '激光扫描仪包装箱', 'jiguangsaomiaoyibaozhuangxiang', '', '', '', '', '', '', '1422851580', '/Uploads/2015-02-02/54cefe146d954.jpg', '', '0', '1', '本站', '98', '1', '', '1');
INSERT INTO `dux_content` VALUES ('204', '4', '临时隔断（用途：赈灾、展览、演出等）', 'linshigeduanyongtuzaizhanlanya', '', '', '', '', '', '', '1422851580', '/Uploads/2015-02-02/54cefeac0e3d9.jpg', '', '0', '1', '本站', '86', '1', '', '1');
INSERT INTO `dux_content` VALUES ('205', '4', '临时隔断（用途：赈灾、展览、演出等）', 'linshigeduanyongtuzaizhanlanya49505350', '', '', '', '', '', '', '1422851760', '/Uploads/2015-02-02/54cefeff52e7b.jpg', '', '0', '1', '本站', '50', '1', '', '1');
INSERT INTO `dux_content` VALUES ('206', '4', '房屋（用途：赈灾、展览、演出、临时接待等）', 'fangwuyongtuzaizhanlanyanchuli', '', '', '', '', '', '', '1422851820', '/Uploads/2015-02-02/54ceff0ac9292.jpg', '', '0', '1', '本站', '32', '1', '', '1');
INSERT INTO `dux_content` VALUES ('207', '4', '房屋（用途：赈灾、展览、演出、临时接待等）', 'fangwuyongtuzaizhanlanyanchuli99102514', '', '', '', '', '', '', '1422851880', '/Uploads/2015-02-02/54ceff59eb7e3.jpg', '', '0', '1', '本站', '97', '1', '', '1');
INSERT INTO `dux_content` VALUES ('208', '4', '房屋（用途：展览、演出、临时接待等）', 'fangwuyongtuzhanlanyanchulinsh', '', '', '', '', '', '', '1422851880', '/Uploads/2015-02-02/54ceff743092a.jpg', '', '0', '1', '本站', '70', '1', '', '1');
INSERT INTO `dux_content` VALUES ('209', '4', '房屋（用途：展览、演出、临时接待等）', 'fangwuyongtuzhanlanyanchulinsh56555351', '', '', '', '', '', '', '1422851940', '/Uploads/2015-02-02/54ceffb5884f9.jpg', '', '0', '1', '本站', '77', '1', '', '1');
INSERT INTO `dux_content` VALUES ('210', '4', '便携方凳', 'bianxiefangdeng', '', '', '', '', '', '', '1422852060', '/Uploads/2015-02-02/54cf000302cbe.jpg', '', '0', '1', '本站', '38', '1', '', '1');
INSERT INTO `dux_content` VALUES ('211', '4', '便携方凳', 'bianxiefangdeng57505350', '', '', '', '', '', '', '1422852060', '/Uploads/2015-02-02/54cf0017716c3.jpg', '', '0', '1', '本站', '964', '1', '', '1');
INSERT INTO `dux_content` VALUES ('212', '4', '便携方凳', 'bianxiefangdeng57975410', '', '', '', '', '', '', '1422852120', '/Uploads/2015-02-02/54cf0035a6d41.jpg', '', '0', '1', '本站', '1899', '1', '', '1');
INSERT INTO `dux_content` VALUES ('213', '4', '茶几', 'chaji50101102', '', '', '', '', '', '', '1422852120', '/Uploads/2015-02-02/54cf00553fd4e.jpg', '', '0', '1', '本站', '96', '1', '', '1');
INSERT INTO `dux_content` VALUES ('214', '4', '床', 'chuang54975410', '', '', '', '', '', '', '1422852180', '/Uploads/2015-02-02/54cf007034633.jpg', '', '0', '1', '本站', '70', '1', '', '1');
INSERT INTO `dux_content` VALUES ('215', '4', '沙发', 'shafa54504953', '', '', '', '', '', '', '1422852180', '/Uploads/2015-02-02/54cf0080b9e6e.jpg', '', '0', '1', '本站', '102', '1', '', '1');
INSERT INTO `dux_content` VALUES ('216', '4', '柜子', 'guizi10252555', '', '', '', '', '', '', '1422852180', '/Uploads/2015-02-02/54cf009a2520f.jpg', '', '0', '1', '本站', '104', '1', '', '1');
INSERT INTO `dux_content` VALUES ('217', '4', '柜子', 'guizi98525555', '', '', '', '', '', '', '1422852240', '/Uploads/2015-02-02/54cf00a7884f9.jpg', '', '0', '1', '本站', '53', '1', '', '1');
INSERT INTO `dux_content` VALUES ('218', '4', '方凳', 'fangdeng10299495', '', '', '', '', '', '', '1422852240', '/Uploads/2015-02-02/54cf00b9120e2.jpg', '', '0', '1', '本站', '56', '1', '', '1');
INSERT INTO `dux_content` VALUES ('219', '4', '方凳', 'fangdeng51999910', '', '', '', '', '', '', '1422852240', '/Uploads/2015-02-02/54cf00d03c045.jpg', '', '0', '1', '本站', '66', '1', '', '1');
INSERT INTO `dux_content` VALUES ('220', '4', '床', 'chuang98511021', '', '', '', '', '', '', '1422852300', '/Uploads/2015-02-02/54cf00e6e7ada.jpg', '', '0', '1', '本站', '62', '1', '', '1');
INSERT INTO `dux_content` VALUES ('221', '4', '沙发茶几组合', 'shafachajizuhe', '', '', '', '', '', '', '1422852300', '/Uploads/2015-02-02/54cf00f8ae753.jpg', '', '0', '1', '本站', '112', '1', '', '1');
INSERT INTO `dux_content` VALUES ('222', '4', '桌子多层架组合', 'zhuoziduocengjiazuhe', '', '', '', '', '', '', '1422852300', '/Uploads/2015-02-02/54cf011119af4.jpg', '', '0', '1', '本站', '96', '1', '', '1');
INSERT INTO `dux_content` VALUES ('223', '4', '床+梳妆台', 'chuangshuzhuangtai', '', '', '', '', '', '', '1422852360', '/Uploads/2015-02-02/54cf012d9f32f.jpg', '', '0', '1', '本站', '91', '1', '', '1');
INSERT INTO `dux_content` VALUES ('224', '4', '魔方组合柜', 'mofangzuhegui', '', '', '', '', '', '', '1422852420', '/Uploads/2015-02-02/54cf0163e3dd1.jpg', '', '0', '1', '本站', '51', '1', '', '1');
INSERT INTO `dux_content` VALUES ('225', '4', '魔方组合柜', 'mofangzuhegui10150535', '', '', '', '', '', '', '1422852420', '/Uploads/2015-02-02/54cf017a753cc.jpg', '', '0', '1', '本站', '89', '1', '', '1');
INSERT INTO `dux_content` VALUES ('226', '4', '魔方组合柜', 'mofangzuhegui10010251', '', '', '', '', '', '', '1422852420', '/Uploads/2015-02-02/54cf018b9f32f.jpg', '', '0', '1', '本站', '61', '1', '', '1');
INSERT INTO `dux_content` VALUES ('227', '4', '柜子', 'guizi10056489', '', '', '', '', '', '', '1422852480', '/Uploads/2015-02-02/54cf0197b6165.jpg', '', '0', '1', '本站', '47', '1', '', '1');
INSERT INTO `dux_content` VALUES ('228', '4', '桌子', 'zhuozi49525197', '', '', '', '', '', '', '1422852480', '/Uploads/2015-02-02/54cf01ab3092a.jpg', '', '0', '1', '本站', '61', '1', '', '1');
INSERT INTO `dux_content` VALUES ('229', '4', '桌子', 'zhuozi54529852', '', '', '', '', '', '', '1422852480', '/Uploads/2015-02-02/54cf01d13c045.jpg', '', '0', '1', '本站', '55', '1', '', '1');
INSERT INTO `dux_content` VALUES ('230', '4', 'H160电机包装框架', 'H160dianjibaozhuangkuangjia', '', '', '', '', '', '', '1422852540', '/Uploads/2015-02-02/54cf01e756b84.jpg', '', '0', '1', '本站', '89', '1', '', '1');
INSERT INTO `dux_content` VALUES ('231', '4', 'H160电机框架包装', 'H160dianjikuangjiabaozhuang', '', '', '', '', '', '', '1422852600', '/Uploads/2015-02-02/54cf02108c269.jpg', '', '0', '1', '本站', '104', '1', '', '1');
INSERT INTO `dux_content` VALUES ('232', '4', 'H160电机框架包装', 'H160dianjikuangjiabaozhuang99565653', '', '', '', '', '', '', '1422852600', '/Uploads/2015-02-02/54cf02250a737.jpg', '', '0', '1', '本站', '68', '1', '', '1');
INSERT INTO `dux_content` VALUES ('233', '4', 'H200电机框架包装', 'H200dianjikuangjiabaozhuang', '', '', '', '', '', '', '1422852600', '/Uploads/2015-02-02/54cf023906a2e.jpg', '', '0', '1', '本站', '69', '1', '', '1');
INSERT INTO `dux_content` VALUES ('234', '4', 'H200电机框架包装', 'H200dianjikuangjiabaozhuang52100529', '', '', '', '', '', '', '1422852660', '/Uploads/2015-02-02/54cf024952ee2.jpg', '', '0', '1', '本站', '118', '1', '', '1');
INSERT INTO `dux_content` VALUES ('235', '4', '玻璃出口框架包装', 'bolichukoukuangjiabaozhuang', '', '', '', '', '', '', '1422852660', '/Uploads/2015-02-02/54cf0260477c7.jpg', '', '0', '1', '本站', '61', '1', '', '1');
INSERT INTO `dux_content` VALUES ('236', '4', '玻璃出口框架包装', 'bolichukoukuangjiabaozhuang97981009', '', '', '', '', '', '', '1422852720', '/Uploads/2015-02-02/54cf027880bae.jpg', '', '0', '1', '本站', '33', '1', '', '1');
INSERT INTO `dux_content` VALUES ('237', '4', '玻璃出口框架包装', 'bolichukoukuangjiabaozhuang10050535', '', '', '', '', '', '', '1422852720', '/Uploads/2015-02-02/54cf0289c93c7.jpg', '', '0', '1', '本站', '74', '1', '', '1');
INSERT INTO `dux_content` VALUES ('238', '4', '石墨电极出口框架包装', 'shimodianjichukoukuangjiabaozh', '', '', '', '', '', '', '1422852720', '/Uploads/2015-02-02/54cf029e216a0.jpg', '', '0', '1', '本站', '108', '1', '', '1');
INSERT INTO `dux_content` VALUES ('239', '4', '石墨电极出口框架包装', 'shimodianjichukoukuangjiabaozh53505748', '', '', '', '', '', '', '1422852780', '/Uploads/2015-02-02/54cf0302c1a55.jpg', '', '0', '1', '本站', '52', '1', '', '1');
INSERT INTO `dux_content` VALUES ('240', '4', '新大洲摩托框架包装', 'xindazhoumotuokuangjiabaozhuan', '', '', '', '', '', '', '1422852840', '/Uploads/2015-02-02/54cf031080ce7.jpg', '', '0', '1', '本站', '100', '1', '', '1');
INSERT INTO `dux_content` VALUES ('241', '4', '新大洲摩托框架包装', 'xindazhoumotuokuangjiabaozhuan10048975', '', '', '', '', '', '', '1422852840', '/Uploads/2015-02-02/54cf032a5307b.jpg', '', '0', '1', '本站', '44', '1', '', '1');
INSERT INTO `dux_content` VALUES ('242', '4', 'LED T5 T8灯管包装', 'LED-T5-T8dengguanbaozhuang10050574', '', '', '', '', '', '', '1422852900', '/Uploads/2015-02-02/54cf0342f33f5.jpg', '', '0', '1', '本站', '91', '1', '', '1');
INSERT INTO `dux_content` VALUES ('243', '4', 'LED T5 T8灯管包装', 'LED-T5-T8dengguanbaozhuang48491009', '', '', '', '', '', '', '1422852900', '/Uploads/2015-02-02/54cf039e2ce3f.jpg', '', '0', '1', '本站', '57', '1', '', '1');
INSERT INTO `dux_content` VALUES ('244', '4', 'LED灯管包装', 'LEDdengguanbaozhuang', '', '', '', '', '', '', '1422853020', '/Uploads/2015-02-02/54cf03c44b6cf.jpg', '', '0', '1', '本站', '78', '1', '', '1');
INSERT INTO `dux_content` VALUES ('245', '4', '工艺包装盒', 'gongyibaozhuanghe', '', '', '', '', '', '', '1422853020', '/Uploads/2015-02-02/54cf03e76dc20.jpg', '', '0', '1', '本站', '53', '1', '', '1');
INSERT INTO `dux_content` VALUES ('246', '4', '工艺包装盒', 'gongyibaozhuanghe48541009', '', '', '', '', '', '', '1422853080', '/Uploads/2015-02-02/54cf03ffd891c.jpg', '', '0', '1', '本站', '73', '1', '', '1');
INSERT INTO `dux_content` VALUES ('247', '4', '工艺包装盒', 'gongyibaozhuanghe98979799', '', '', '', '', '', '', '1422853080', '/Uploads/2015-02-02/54cf0409bdddd.jpg', '', '0', '1', '本站', '51', '1', '', '1');
INSERT INTO `dux_content` VALUES ('248', '4', '工艺包装盒', 'gongyibaozhuanghe98981001', '', '', '', '', '', '', '1422853080', '/Uploads/2015-02-02/54cf0426b63cb.jpg', '', '0', '1', '本站', '49', '1', '', '1');
INSERT INTO `dux_content` VALUES ('249', '4', '工艺包装盒', 'gongyibaozhuanghe54101989', '', '', '', '', '', '', '1422853140', '/Uploads/2015-02-02/54cf0434aacb0.jpg', '', '0', '1', '本站', '64', '1', '', '1');
INSERT INTO `dux_content` VALUES ('250', '4', '工艺包装盒', 'gongyibaozhuanghe53485499', '', '', '', '', '', '', '1422853140', '/Uploads/2015-02-02/54cf04426620e.jpg', '', '0', '1', '本站', '44', '1', '', '1');
INSERT INTO `dux_content` VALUES ('251', '4', '工艺包装盒', 'gongyibaozhuanghe53574849', '', '', '', '', '', '', '1422853140', '/Uploads/2015-02-02/54cf044fc1ae6.jpg', '', '0', '1', '本站', '79', '1', '', '1');
INSERT INTO `dux_content` VALUES ('252', '4', 'FT90电机轴包装', 'FT90dianjizhoubaozhuang', '', '', '', '', '', '', '1422853200', '/Uploads/2015-02-02/54cf0462ba0d4.jpg', '', '0', '1', '本站', '132', '1', '', '1');
INSERT INTO `dux_content` VALUES ('253', '4', 'FT90电机轴包装', 'FT90dianjizhoubaozhuang52531015', '', '', '', '', '', '', '1422853200', '/Uploads/2015-02-02/54cf048219d5a.jpg', '', '0', '1', '本站', '3114', '1', '', '1');
INSERT INTO `dux_content` VALUES ('254', '4', '纸管滚轴', 'zhiguangunzhou10057559', '', '', '', '', '', '', '1422853200', '/Uploads/2015-02-02/54cf0495d0f0a.jpg', '', '0', '1', '本站', '65', '1', '', '1');
INSERT INTO `dux_content` VALUES ('255', '4', '形象墙+前台', 'xingxiangqiangqiantai10157484', '', '', '', '', '', '', '1422853260', '/Uploads/2015-02-02/54cf0a4b56dea.jpg', '', '0', '1', '本站', '58', '1', '', '1');
INSERT INTO `dux_content` VALUES ('256', '4', '形象墙+前台', 'xingxiangqiangqiantai98535410', '', '', '', '', '', '', '1422854700', '/Uploads/2015-02-02/54cf0a5875632.jpg', '', '0', '1', '本站', '87', '1', '', '1');
INSERT INTO `dux_content` VALUES ('257', '4', '特装展位', 'tezhuangzhanwei', '', '', '', '', '', '', '1422854700', '/Uploads/2015-02-02/54cf0aaa8875f.jpg', '', '0', '1', '本站', '74', '1', '', '1');
INSERT INTO `dux_content` VALUES ('258', '4', '镂空隔断（灯光效果）', 'konggeduandengguangxiaoguo10252555', '', '', '', '', '', '', '1422854820', '/Uploads/2015-02-02/54cf0acb43cbd.jpg', '', '0', '1', '本站', '83', '1', '', '1');
INSERT INTO `dux_content` VALUES ('259', '4', '镂空隔断', 'konggeduan49491009', '', '', '', '', '', '', '1422854820', '/Uploads/2015-02-02/54cf0b8669f17.jpg', '', '0', '1', '本站', '104', '1', '', '1');
INSERT INTO `dux_content` VALUES ('260', '4', '酒店客房装修', 'jiudiankefangzhuangxiu', '', '', '', '', '', '', '1422854880', '/Uploads/2015-02-02/54cf0aee2ce87.jpg', '', '0', '1', '本站', '64', '1', '', '1');
INSERT INTO `dux_content` VALUES ('261', '4', '酒店客房装修', 'jiudiankefangzhuangxiu56995752', '', '', '', '', '', '', '1422854940', '/Uploads/2015-02-02/54cf0b2fe032e.jpg', '', '0', '1', '本站', '79', '1', '', '1');
INSERT INTO `dux_content` VALUES ('262', '4', '酒店客房装修', 'jiudiankefangzhuangxiu49495051', '', '', '', '', '', '', '1422854940', '/Uploads/2015-02-02/54cf0b5dc1ae6.jpg', '', '0', '1', '本站', '53', '1', '', '1');
INSERT INTO `dux_content` VALUES ('263', '4', '隔断+储物架（箱）', 'geduanchuwujiaxiang', '', '', '', '', '', '', '1422855060', '/Uploads/2015-02-02/54cf0bb38c468.jpg', '', '0', '1', '本站', '55', '1', '', '1');
INSERT INTO `dux_content` VALUES ('264', '4', '隔断+储物架（箱）', 'geduanchuwujiaxiang54514898', '', '', '', '', '', '', '1422855060', '/Uploads/2015-02-02/54cf0bc2c94f8.jpg', '', '0', '1', '本站', '113', '1', '', '1');
INSERT INTO `dux_content` VALUES ('265', '4', '隔断+储物架（箱）', 'geduanchuwujiaxiang50102515', '', '', '', '', '', '', '1422855060', '/Uploads/2015-02-02/54cf0bd0530e1.jpg', '', '0', '1', '本站', '61', '1', '', '1');
INSERT INTO `dux_content` VALUES ('266', '4', '隔断+储物架（箱）', 'geduanchuwujiaxiang49541009', '', '', '', '', '', '', '1422855120', '/Uploads/2015-02-02/54cf0bde90171.jpg', '', '0', '1', '本站', '42', '1', '', '1');
INSERT INTO `dux_content` VALUES ('267', '4', '超强型纸管托盘', 'chaoqiangxingzhiguantuopan', '', '', '', '', '', '', '1422855120', '/Uploads/2015-02-02/54cf0bfdae9b9.jpg', '', '0', '1', '本站', '92', '1', '', '1');
INSERT INTO `dux_content` VALUES ('268', '4', '超强型纸管托盘', 'chaoqiangxingzhiguantuopan97551004', '', '', '', '', '', '', '1422855180', '/Uploads/2015-02-02/54cf0c27aacb0.jpg', '', '0', '1', '本站', '68', '1', '', '1');
INSERT INTO `dux_content` VALUES ('269', '4', '超强型纸管托盘', 'chaoqiangxingzhiguantuopan55989748', '', '', '', '', '', '', '1422855180', '/Uploads/2015-02-02/54cf0c40bdddd.jpg', '', '0', '1', '本站', '51', '1', '', '1');
INSERT INTO `dux_content` VALUES ('270', '4', '四面进叉蜂窝纸管托盘', 'simianjinchafengwozhiguantuopa', '', '', '', '', '', '', '1422855240', '/Uploads/2015-02-02/54cf0c6f0a936.jpg', '', '0', '1', '本站', '87', '1', '', '1');
INSERT INTO `dux_content` VALUES ('271', '4', '四面进叉蜂窝纸管托盘', 'simianjinchafengwozhiguantuopa57991005', '', '', '', '', '', '', '1422855240', '/Uploads/2015-02-02/54cf0c85c1ae6.jpg', '', '0', '1', '本站', '71', '1', '', '1');
INSERT INTO `dux_content` VALUES ('272', '4', '两面进叉方形纸管托盘', 'liangmianjinchafangxingzhiguan', '', '', '', '', '', '', '1422855300', '/Uploads/2015-02-02/54cf0c99c57ef.jpg', '', '0', '1', '本站', '72', '1', '', '1');
INSERT INTO `dux_content` VALUES ('273', '4', '两面进叉方形纸管托盘', 'liangmianjinchafangxingzhiguan97515256', '', '', '', '', '', '', '1422855300', '/Uploads/2015-02-02/54cf0cb7e7d40.jpg', '', '0', '1', '本站', '50', '1', '', '1');
INSERT INTO `dux_content` VALUES ('274', '4', '四面进叉方形纸管托盘', 'simianjinchafangxingzhiguantuo', '', '', '', '', '', '', '1422855300', '/Uploads/2015-02-02/54cf0cd1d891c.jpg', '', '0', '1', '本站', '76', '1', '', '1');
INSERT INTO `dux_content` VALUES ('275', '4', '四面进叉方形纸管托盘', 'simianjinchafangxingzhiguantuo50529854', '', '', '', '', '', '', '1422855360', '/Uploads/2015-02-02/54cf0cebd891c.jpg', '', '0', '1', '本站', '101', '1', '', '1');
INSERT INTO `dux_content` VALUES ('277', '4', '包装展展架', 'baozhuangzhanzhanjia', '', '', '', '', '', '', '1422855420', '/Uploads/2015-02-02/54cf0d2aa6fa7.jpg', '', '0', '1', '本站', '107', '1', '', '1');
INSERT INTO `dux_content` VALUES ('278', '4', '变形展架', 'bianxingzhanjia', '', '', '', '', '', '', '1422855420', '/Uploads/2015-02-02/54cf0d47dc625.jpg', '', '0', '1', '本站', '89', '1', '', '1');
INSERT INTO `dux_content` VALUES ('279', '4', '变形展架', 'bianxingzhanjia99491009', '', '', '', '', '', '', '1422855480', '/Uploads/2015-02-02/54cf0d59e4037.jpg', '', '0', '1', '本站', '64', '1', '', '1');
INSERT INTO `dux_content` VALUES ('280', '4', '变形展架组合', 'bianxingzhanjiazuhe', '', '', '', '', '', '', '1422855480', '/Uploads/2015-02-02/54cf0d6f62505.jpg', '', '0', '1', '本站', '100', '1', '', '1');
INSERT INTO `dux_content` VALUES ('281', '4', '变形展架组合', 'bianxingzhanjiazuhe98994997', '', '', '', '', '', '', '1422855540', '/Uploads/2015-02-02/54cf0d8116051.jpg', '', '0', '1', '本站', '49', '1', '', '1');
INSERT INTO `dux_content` VALUES ('282', '4', '标准展架', 'biaozhunzhanjia', '', '', '', '', '', '', '1422855540', '/Uploads/2015-02-02/54cf0d9516051.jpg', '', '0', '1', '本站', '73', '1', '', '1');
INSERT INTO `dux_content` VALUES ('283', '4', '标准展架', 'biaozhunzhanjia57529854', '', '', '', '', '', '', '1422855540', '/Uploads/2015-02-02/54cf0db706c2d.jpg', '', '0', '1', '本站', '102', '1', '', '1');
INSERT INTO `dux_content` VALUES ('284', '4', '办公室陈列架', 'bangongshichenliejia', '', '', '', '', '', '', '1422855600', '/Uploads/2015-02-02/54cf0dd29f595.jpg', '', '0', '1', '本站', '99', '1', '', '1');
INSERT INTO `dux_content` VALUES ('285', '4', '陈列柜', 'chenliegui99100481', '', '', '', '', '', '', '1422855600', '/Uploads/2015-02-02/54cf0de702f24.jpg', '', '0', '1', '本站', '53', '1', '', '1');
INSERT INTO `dux_content` VALUES ('286', '4', '陈列柜', 'chenliegui10153514', '', '', '', '', '', '', '1422855660', '/Uploads/2015-02-02/54cf0e6bef752.jpg', '', '0', '1', '本站', '97', '1', '', '1');
INSERT INTO `dux_content` VALUES ('287', '4', '深圳第十届文博会展架', 'shendishijiewenbohuizhanjia', '', '', '', '', '', '', '1422855660', '/Uploads/2015-02-02/54cf0e0f12348.jpg', '', '0', '1', '本站', '46', '1', '', '1');
INSERT INTO `dux_content` VALUES ('288', '4', '深圳第十届文博会展架', 'shendishijiewenbohuizhanjia49565655', '', '', '', '', '', '', '1422855660', '/Uploads/2015-02-02/54cf0e2f2176c.jpg', '', '0', '1', '本站', '81', '1', '', '1');
INSERT INTO `dux_content` VALUES ('289', '4', '深圳第十届文博会展架', 'shendishijiewenbohuizhanjia10149505', '', '', '', '', '', '', '1422855780', '/Uploads/2015-02-02/54cf0e879f595.jpg', '', '0', '1', '本站', '97', '1', '', '1');
INSERT INTO `dux_content` VALUES ('290', '4', '深圳第十届文博会展架', 'shendishijiewenbohuizhanjia99505352', '', '', '', '', '', '', '1422855780', '/Uploads/2015-02-02/54cf0e98b63cb.jpg', '', '0', '1', '本站', '47', '1', '', '1');
INSERT INTO `dux_content` VALUES ('291', '4', '深圳第十届文博会展架', 'shendishijiewenbohuizhanjia10299535', '', '', '', '', '', '', '1422855780', '/Uploads/2015-02-02/54cf0ebda6fa7.jpg', '', '0', '1', '本站', '53', '1', '', '1');
INSERT INTO `dux_content` VALUES ('292', '4', '创意置物架', 'chuangyizhiwujia', '', '', '', '', '', '', '1422855840', '/Uploads/2015-02-02/54cf0ed6aacb0.jpg', '', '0', '1', '本站', '86', '1', '', '1');
INSERT INTO `dux_content` VALUES ('293', '4', '商超堆头架', 'shangchaoduitoujia', '', '', '', '', '', '', '1422855900', '/Uploads/2015-02-02/54cf0efe62505.jpg', '', '0', '1', '本站', '74', '1', '', '1');
INSERT INTO `dux_content` VALUES ('294', '4', '多层置物架', 'duocengzhiwujia', '', '', '', '', '', '', '1422855900', '/Uploads/2015-02-02/54cf0f1719d5a.jpg', '', '0', '1', '本站', '96', '1', '', '1');
INSERT INTO `dux_content` VALUES ('295', '4', '广交会现场展架搭建', 'guangjiaohuixianchangzhanjiada', '', '', '', '', '', '', '1422855960', '/Uploads/2015-02-02/54cf0f32cd201.jpg', '', '0', '1', '本站', '109', '1', '', '1');
INSERT INTO `dux_content` VALUES ('296', '4', '国际珠宝展展架', 'guojizhubaozhanzhanjia', '', '', '', '', '', '', '1422855960', '/Uploads/2015-02-02/54cf0f4c93e7a.jpg', '', '0', '1', '本站', '97', '1', '', '1');
INSERT INTO `dux_content` VALUES ('297', '4', '商超堆头架', 'shangchaoduitoujia10099535', '', '', '', '', '', '', '1422855960', '/Uploads/2015-02-02/54cf0f6c8875f.jpg', '', '0', '1', '本站', '52', '1', '', '1');
INSERT INTO `dux_content` VALUES ('298', '4', '商超堆头架', 'shangchaoduitoujia48101551', '', '', '', '', '', '', '1422856020', '/Uploads/2015-02-02/54cf0f9e479c6.jpg', '', '0', '1', '本站', '94', '1', '', '1');
INSERT INTO `dux_content` VALUES ('299', '4', '商超堆头架', 'shangchaoduitoujia51975150', '', '', '', '', '', '', '1422856080', '/Uploads/2015-02-02/54cf0faf3ffb4.jpg', '', '0', '1', '本站', '69', '1', '', '1');
INSERT INTO `dux_content` VALUES ('300', '4', '商超堆头架', 'shangchaoduitoujia54995752', '', '', '', '', '', '', '1422856080', '/Uploads/2015-02-02/54cf0fc4385a2.jpg', '', '0', '1', '本站', '49', '1', '', '1');
INSERT INTO `dux_content` VALUES ('301', '4', '商超堆头架', 'shangchaoduitoujia10251489', '', '', '', '', '', '', '1422856080', '/Uploads/2015-02-02/54cf0fd98875f.jpg', '', '0', '1', '本站', '61', '1', '', '1');
INSERT INTO `dux_content` VALUES ('302', '4', '陶瓷展展架', 'taocizhanzhanjia', '', '', '', '', '', '', '1422856140', '/Uploads/2015-02-02/54cf103f6dc20.jpg', '', '0', '1', '本站', '105', '1', '', '1');
INSERT INTO `dux_content` VALUES ('303', '4', '香港钟表展展架', 'xianggangzhongbiaozhanzhanjia', '', '', '', '', '', '', '1422856260', '/Uploads/2015-02-02/54cf105490171.jpg', '', '0', '1', '本站', '85', '1', '', '1');
INSERT INTO `dux_content` VALUES ('304', '4', '置物架', 'zhiwujia10298974', '', '', '', '', '', '', '1422856260', '/Uploads/2015-02-02/54cf10771da63.jpg', '', '0', '1', '本站', '96', '1', '', '1');
INSERT INTO `dux_content` VALUES ('305', '9', '优质供应商证书', 'youzhigongyingshangzhengshu', '', '', '', '', '', '', '1422859500', '/Uploads/2015-02-02/54cf1d166dc20.jpg', '', '0', '1', '本站', '32', '1', '', '1');
INSERT INTO `dux_content` VALUES ('306', '10', '海方科技团队文化', 'haifangkejituanduiwenhua', '', '', '', '', '', '', '1422860280', '/Uploads/2016-01-26/56a710f21417c.png', '', '0', '1', '本站', '41', '1', '', '1');
INSERT INTO `dux_content` VALUES ('307', '10', '海方科技组织架构', 'haifangkejizuzhijiagou', '', '', '', '', '', '', '1422860460', '/Uploads/2016-01-25/56a5e2722cfec.png', '', '0', '1', '本站', '53', '1', '', '1');
INSERT INTO `dux_content` VALUES ('309', '28', '深圳文博会海方[方形纸管展馆]宣传片', 'shenwenbohuihaifangfangxingzhi', '', '', '', '2', '', '', '1422867660', '/Uploads/2015-02-02/54cf48600381b.jpg', '', '0', '1', '本站', '121', '1', '', '1');
INSERT INTO `dux_content` VALUES ('310', '28', '海方[方形纸管托盘]最大压力测试', 'haifangfangxingzhiguantuopanzu', '', '', '', '2', '', '', '1422867720', '/Uploads/2015-02-02/54cf48a6be710.jpg', '', '0', '1', '本站', '157', '1', '', '1');
INSERT INTO `dux_content` VALUES ('311', '28', '海方[方形纸管托盘]角跌落试验', 'haifangfangxingzhiguantuopanji', '', '', '', '2', '', '', '1422867780', '/Uploads/2015-02-02/54cf48c689092.jpg', '', '0', '1', '本站', '137', '1', '', '1');
INSERT INTO `dux_content` VALUES ('312', '28', '海方[方形纸管托盘]剪切试验', 'haifangfangxingzhiguantuopanji97551005', '', '', '', '', '', '', '1422867840', '/Uploads/2015-02-02/54cf4d57ec37c.jpg', '', '0', '1', '本站', '35', '1', '', '1');
INSERT INTO `dux_content` VALUES ('313', '28', '海方[方形纸管托盘]动态载荷测试', 'haifangfangxingzhiguantuopando', '', '', '', '', '', '', '1422867840', '/Uploads/2015-02-02/54cf4d4138ed5.jpg', '', '0', '1', '本站', '38', '1', '', '1');
INSERT INTO `dux_content` VALUES ('314', '28', '海方[方形纸管便携凳]组装', 'haifangfangxingzhiguanbianxied', '', '', '', '2', '', '', '1422867900', '/Uploads/2015-02-02/54cf48f3e0c61.jpg', '', '0', '1', '本站', '106', '1', '', '1');
INSERT INTO `dux_content` VALUES ('315', '28', '海方[方形纸管框架箱体]连续冲击试验', 'haifangfangxingzhiguankuangjia', '', '', '', '', '', '', '1422867960', '/Uploads/2015-02-02/54cf4d1d12c7b.jpg', '', '0', '1', '本站', '39', '1', '', '1');
INSERT INTO `dux_content` VALUES ('316', '28', '多层板箱与海方[方形纸管箱]自由跌落对比试验', 'duocengbanxiangyuhaifangfangxi', '', '', '', '2', '', '', '1422868020', '/Uploads/2015-02-02/54cf491dd183d.jpg', '', '0', '1', '本站', '106', '1', '', '1');
INSERT INTO `dux_content` VALUES ('317', '28', '海方[方形纸管框架箱]地面推移试验', 'haifangfangxingzhiguankuangjia10152102', '', '', '', '2', '', '', '1422868140', '/Uploads/2015-02-02/54cf493baf2ec.jpg', '', '0', '1', '本站', '180', '1', '', '1');
INSERT INTO `dux_content` VALUES ('318', '28', '海方[方形纸管框架箱]棱跌落试验', 'haifangfangxingzhiguankuangjia53102511', '', '', '', '', '', '', '1422868260', '/Uploads/2015-02-02/54cf4d031a68d.jpg', '', '0', '1', '本站', '28', '1', '', '1');
INSERT INTO `dux_content` VALUES ('319', '28', '海方[方形纸管框架箱]淋水试验', 'haifangfangxingzhiguankuangjia98100575', '', '', '', '', '', '', '1422868260', '/Uploads/2015-02-02/54cf4cdd9c1bf.jpg', '', '0', '1', '本站', '29', '1', '', '1');
INSERT INTO `dux_content` VALUES ('320', '11', 'TTS检测报告（海方四面进叉方形纸管托盘）', 'TTSjiancebaogaohaifangsimianji', '', '', '', '', '', '', '1422880200', '', '', '0', '1', '本站', '0', '1', '', '1');
INSERT INTO `dux_content` VALUES ('321', '11', '海方[方形纸管]产品介绍', 'haifangfangxingzhiguanchanpinj', '', '', '', '', '', '', '1422933960', '', '', '0', '1', '本站', '0', '1', '', '1');
INSERT INTO `dux_content` VALUES ('322', '4', '中粮•名庄荟商超终端红酒架', 'zhongliangmingzhuangshangchaoz', '', '', '', '', '', '', '1423107720', '/Uploads/2015-02-05/54d2e715c3db1.jpg', '', '0', '1', '本站', '112', '1', '', '1');
INSERT INTO `dux_content` VALUES ('323', '4', '中粮•名庄荟商超终端红酒架', 'zhongliangmingzhuangshangchaoz56545652', '', '', '', '', '', '', '1423107840', '/Uploads/2015-02-05/54d2e764e6302.jpg', '', '0', '1', '本站', '83', '1', '', '1');
INSERT INTO `dux_content` VALUES ('324', '4', '中粮•名庄荟商超终端红酒架', 'zhongliangmingzhuangshangchaoz10053495', '', '', '', '', '', '', '1423107900', '/Uploads/2015-02-05/54d2e785b0c84.jpg', '', '0', '1', '本站', '75', '1', '', '1');
INSERT INTO `dux_content` VALUES ('325', '18', '中粮•名庄荟商超终端红酒架', 'zhongliangmingzhuangshangchaoz99525610', '', '', '', '', '', '', '1423202100', '/Uploads/2015-02-06/54d45758d9dab.jpg', '', '0', '1', '本站', '31', '1', '', '1');
INSERT INTO `dux_content` VALUES ('326', '18', '中粮•名庄荟商超终端红酒架', 'zhongliangmingzhuangshangchaoz97975652', '', '', '', '', '', '', '1423202100', '/Uploads/2015-02-06/54d45785f0be1.jpg', '', '0', '1', '本站', '29', '1', '', '1');
INSERT INTO `dux_content` VALUES ('327', '18', '中粮•名庄荟商超终端红酒架', 'zhongliangmingzhuangshangchaoz49574954', '', '', '', '', '', '', '1423202160', '/Uploads/2015-02-06/54d4579e5bf82.jpg', '', '0', '1', '本站', '41', '1', '', '1');
INSERT INTO `dux_content` VALUES ('328', '29', '展览特装', 'zhanlantezhuang', '', '', '', '', '', '', '1423202160', '/Uploads/2015-02-06/54d4581b1eef2.jpg', '', '0', '1', '本站', '35', '1', '', '1');
INSERT INTO `dux_content` VALUES ('329', '29', '展览特装', 'zhanlantezhuang10050545', '', '', '', '', '', '', '1423202280', '/Uploads/2015-02-06/54d458472a60d.jpg', '', '0', '1', '本站', '39', '1', '', '1');
INSERT INTO `dux_content` VALUES ('330', '29', '展览特装', 'zhanlantezhuang49100544', '', '', '', '', '', '', '1423202340', '/Uploads/2015-02-06/54d4586f95309.jpg', '', '0', '1', '本站', '36', '1', '', '1');
INSERT INTO `dux_content` VALUES ('331', '18', '展览特装', 'zhanlantezhuang52985198', '', '', '', '', '', '', '1423202400', '/Uploads/2015-02-06/54d45881a0a24.jpg', '', '0', '1', '本站', '37', '1', '', '1');
INSERT INTO `dux_content` VALUES ('332', '29', '展览特装', 'zhanlantezhuang52495155', '', '', '', '', '', '', '1423202400', '/Uploads/2015-02-06/54d4589e2e316.jpg', '', '0', '1', '本站', '40', '1', '', '1');
INSERT INTO `dux_content` VALUES ('333', '29', '展览特装', 'zhanlantezhuang10150975', '', '', '', '2', '', '', '1422784740', '/Uploads/2015-02-06/54d458b2e54c6.jpg', '', '0', '1', '本站', '150', '1', '', '1');
INSERT INTO `dux_content` VALUES ('334', '4', '展览特装', 'zhanlantezhuang10099501', '', '', '', '', '', '', '1423203480', '/Uploads/2015-02-06/54d45cda2e316.jpg', '', '0', '1', '本站', '72', '1', '', '1');
INSERT INTO `dux_content` VALUES ('335', '4', '展览特装', 'zhanlantezhuang99535650', '', '', '', '', '', '', '1423203540', '/Uploads/2015-02-06/54d45cf863994.jpg', '', '0', '1', '本站', '59', '1', '', '1');
INSERT INTO `dux_content` VALUES ('336', '4', '展览特装', 'zhanlantezhuang98574954', '', '', '', '', '', '', '1423203540', '/Uploads/2015-02-06/54d45d090bdc5.jpg', '', '0', '1', '本站', '122', '1', '', '1');
INSERT INTO `dux_content` VALUES ('337', '4', '展览特装', 'zhanlantezhuang98985556', '', '', '', '', '', '', '1423203540', '/Uploads/2015-02-06/54d45d18a0a24.jpg', '', '0', '1', '本站', '56', '1', '', '1');
INSERT INTO `dux_content` VALUES ('338', '4', '展览特装', 'zhanlantezhuang57524952', '', '', '', '', '', '', '1423203600', '/Uploads/2015-02-06/54d45d26e17bd.jpg', '', '0', '1', '本站', '50', '1', '', '1');
INSERT INTO `dux_content` VALUES ('339', '19', '茶室隔断+文件架', 'chashigeduanwenjianjia', '', '', '', '', '', '', '1423216500', '/Uploads/2015-02-06/54d49085495ee.jpg', '', '0', '1', '本站', '34', '1', '', '1');
INSERT INTO `dux_content` VALUES ('340', '19', '茶室隔断+文件架', 'chashigeduanwenjianjia56485010', '', '', '', '', '', '', '1423216740', '/Uploads/2015-02-07/54d5990493e00.jpg', '', '0', '1', '本站', '36', '1', '', '1');
INSERT INTO `dux_content` VALUES ('342', '4', '楼梯间隔断+储物架', 'loutijiangeduanchuwujia', '', '', '', '', '', '', '1423217160', '/Uploads/2015-02-06/54d492205c71b.jpg', '', '0', '1', '本站', '114', '1', '', '1');
INSERT INTO `dux_content` VALUES ('343', '4', '茶室隔断+文件架', 'chashigeduanwenjianjia97525356', '', '', '', '', '', '', '1423217220', '/Uploads/2015-02-06/54d4926d00e43.jpg', '', '0', '1', '本站', '126', '1', '', '1');
INSERT INTO `dux_content` VALUES ('344', '4', '茶室隔断+造型墙', 'chashigeduanzaoxingqiang', '', '', '', '', '', '', '1423217220', '/Uploads/2015-02-07/54d5994d93e00.jpg', '', '0', '1', '本站', '98', '1', '', '1');
INSERT INTO `dux_content` VALUES ('345', '29', '背景桁架', 'beijingjia', '', '', '', '', '', '', '1423305000', '/Uploads/2015-02-07/54d5e9a65ef82.jpg', '', '0', '1', '本站', '44', '1', '', '1');
INSERT INTO `dux_content` VALUES ('346', '29', '展览特装', 'zhanlantezhuang52535156', '', '', '', '', '', '', '1423305120', '/Uploads/2015-02-07/54d5e9e357570.jpg', '', '0', '1', '本站', '59', '1', '', '1');
INSERT INTO `dux_content` VALUES ('347', '29', '展览特装', 'zhanlantezhuang50579948', '', '', '', '', '', '', '1423305240', '/Uploads/2015-02-07/54d5ea4a29904.jpg', '', '0', '1', '本站', '45', '1', '', '1');
INSERT INTO `dux_content` VALUES ('348', '29', '环保桁架', 'huanbaojia', '', '', '', '', '', '', '1423305240', '/Uploads/2015-02-07/54d5ea68814d3.jpg', '', '0', '1', '本站', '56', '1', '', '1');
INSERT INTO `dux_content` VALUES ('349', '4', '展览特装', 'zhanlantezhuang49565610', '', '', '', '', '', '', '1423305300', '/Uploads/2015-02-07/54d5ea977d7ca.jpg', '', '0', '1', '本站', '65', '1', '', '1');
INSERT INTO `dux_content` VALUES ('350', '4', '展览特装', 'zhanlantezhuang10110110', '', '', '', '', '', '', '1423305360', '/Uploads/2015-02-07/54d5eab99c012.jpg', '', '0', '1', '本站', '100', '1', '', '1');
INSERT INTO `dux_content` VALUES ('351', '13', '方形纸管', 'fangxingzhiguan10254981', '', '', '', '', '', '', '1452929400', '/Uploads/2016-01-16/5699f4aba1457.jpg', '', '0', '1', '本站', '34', '1', '', '1');
INSERT INTO `dux_content` VALUES ('352', '13', '方形纸管', 'fangxingzhiguan53101531', '', '', '', '', '', '', '1452930360', '/Uploads/2016-01-16/5699f579737eb.jpg', '', '0', '1', '本站', '30', '1', '', '1');
INSERT INTO `dux_content` VALUES ('353', '17', '内置外包装', 'neizhiwaibaozhuang55505154', '', '', '', '', '', '', '1452930600', '/Uploads/2016-01-16/5699f669a8e69.jpg', '', '0', '1', '本站', '25', '1', '', '1');
INSERT INTO `dux_content` VALUES ('354', '17', '内置外包装', 'neizhiwaibaozhuang53559849', '', '', '', '', '', '', '1452930660', '/Uploads/2016-01-16/5699f7026bdd9.jpg', '', '0', '1', '本站', '28', '1', '', '1');
INSERT INTO `dux_content` VALUES ('355', '17', '内置外包装', 'neizhiwaibaozhuang51575797', '', '', '', '', '', '', '1452932100', '/Uploads/2016-01-16/5699fc4e6fb48.jpg', '', '0', '1', '本站', '24', '1', '', '1');
INSERT INTO `dux_content` VALUES ('356', '13', '方形纸管', 'fangxingzhiguan51561015', '', '', '', '', '', '', '1452932160', '/Uploads/2016-01-16/5699fd7e45be5.jpg', '', '0', '1', '本站', '28', '1', '', '1');
INSERT INTO `dux_content` VALUES ('357', '13', '方形纸管', 'fangxingzhiguan98985650', '', '', '', '', '', '', '1452932460', '/Uploads/2016-01-16/5699fe7704e4c.jpg', '', '0', '1', '本站', '25', '1', '', '1');
INSERT INTO `dux_content` VALUES ('358', '17', '内置外包装', 'neizhiwaibaozhuang52491025', '', '', '', '', '', '', '1452932700', '/Uploads/2016-01-16/5699fef0e9c68.jpg', '', '0', '1', '本站', '31', '1', '', '1');
INSERT INTO `dux_content` VALUES ('359', '27', '广州海方科技股份有限公司荣获为“广东省守合同重信用企业证书”', 'guangzhouhaifangkejigufenyouxi48565749', '', '', '', '', '', '', '1453703280', '', '', '0', '1', '本站', '0', '1', '', '1');
INSERT INTO `dux_content` VALUES ('360', '27', '广州海方科技股份有限公司荣获为“中国中小企业协会信用管理中心会员单位证书”', 'guangzhouhaifangkejigufenyouxi49515497', '', '', '', '', '', '', '1453703820', '', '', '0', '1', '本站', '0', '1', '', '1');
INSERT INTO `dux_content` VALUES ('361', '27', '广州海方科技股份有限公司荣获为“企业信用等级证书”', 'guangzhouhaifangkejigufenyouxi97565348', '', '', '', '', '', '', '1453704060', '', '', '0', '1', '本站', '0', '1', '', '1');
INSERT INTO `dux_content` VALUES ('362', '27', '广州海方科技股份有限公司荣获为“科学技术成果证书”', 'guangzhouhaifangkejigufenyouxi50100491', '', '', '', '', '', '', '1453704180', '', '', '0', '1', '本站', '0', '1', '', '1');
INSERT INTO `dux_content` VALUES ('363', '27', '浙江海方纸制品科技有限公司成立', 'zhejianghaifangzhizhipinkejiyo', '', '', '', '', '', '', '1453704600', '', '', '0', '1', '本站', '0', '1', '', '1');
INSERT INTO `dux_content` VALUES ('364', '9', '广东省守合同重信用企业证书', 'guangdongshengshouhetongzhongx', '', '', '', '', '', '', '1453704720', '/Uploads/2016-01-25/56a5c6f90eb59.jpg', '', '0', '1', '本站', '19', '1', '', '1');
INSERT INTO `dux_content` VALUES ('365', '9', '中国中小企业协会信用管理中心会员单位', 'zhongguozhongxiaoqiyexiehuixin', '', '', '', '', '', '', '1453704960', '/Uploads/2016-01-25/56a5c939dca30.jpg', '', '0', '1', '本站', '20', '1', '', '1');
INSERT INTO `dux_content` VALUES ('366', '9', '企业信用等级证书', 'qiyexinyongdengjizhengshu', '', '', '', '', '', '', '1453705740', '/Uploads/2016-01-25/56a5ca62c3347.jpg', '', '0', '1', '本站', '22', '1', '', '1');
INSERT INTO `dux_content` VALUES ('367', '9', '科学技术成果证书', 'kexuejishuchengguozhengshu', '', '', '', '', '', '', '1453705800', '/Uploads/2016-01-25/56a5cad964e4c.jpg', '', '0', '1', '本站', '25', '1', '', '1');
INSERT INTO `dux_content` VALUES ('368', '9', '营业执照', 'yingyezhizhao', '', '', '', '', '', '', '1453705920', '/Uploads/2016-01-25/56a5cba3aa0c0.jpg', '', '0', '1', '本站', '28', '1', '', '1');
INSERT INTO `dux_content` VALUES ('370', '18', '展示架：HF-01', 'zhanshijiaHF-01', '', '', '', '', '', '', '1459911060', '/Uploads/2016-04-06/57047c526b472.png', '', '0', '1', '本站', '18', '1', '', '1');
INSERT INTO `dux_content` VALUES ('371', '18', '展示架：HF-01', 'zhanshijiaHF-0148971005', '', '', '', '', '', '', '1459913340', '/Uploads/2016-04-06/570482bf22cc7.png', '', '0', '1', '本站', '17', '1', '', '1');
INSERT INTO `dux_content` VALUES ('372', '18', '展示架：HF-02', 'zhanshijiaHF-02', '', '', '', '', '', '', '1459913400', '/Uploads/2016-04-06/570483c022cc7.png', '', '0', '1', '本站', '20', '1', '', '1');
INSERT INTO `dux_content` VALUES ('373', '18', '展示架：HF-03', 'zhanshijiaHF-03', '', '', '', '', '', '', '1459913640', '/Uploads/2016-04-06/57048530bf338.png', '', '0', '1', '本站', '22', '1', '', '1');
INSERT INTO `dux_content` VALUES ('374', '18', '展示架：HF-04', 'zhanshijiaHF-04', '', '', '', '', '', '', '1462349400', '/Uploads/2016-05-04/5729b21fc1d5c.png', '', '0', '1', '本站', '16', '1', '', '1');
INSERT INTO `dux_content` VALUES ('375', '18', '展示架：HF-05', 'zhanshijiaHF-05', '', '', '', '', '', '', '1462350420', '/Uploads/2016-05-04/5729b29514c93.png', '', '0', '1', '本站', '20', '1', '', '1');

-- -----------------------------
-- Table structure for `dux_content_article`
-- -----------------------------
DROP TABLE IF EXISTS `dux_content_article`;
CREATE TABLE `dux_content_article` (
  `content_id` int(10) DEFAULT NULL,
  `content` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文章内容信息';

-- -----------------------------
-- Records of `dux_content_article`
-- -----------------------------
INSERT INTO `dux_content_article` VALUES ('1', 'banner1');
INSERT INTO `dux_content_article` VALUES ('2', '&lt;img src=&quot;/Uploads/2015-01-31/54cc586e77845.jpg&quot; /&gt;');
INSERT INTO `dux_content_article` VALUES ('3', '企业责任');
INSERT INTO `dux_content_article` VALUES ('4', '荣誉');
INSERT INTO `dux_content_article` VALUES ('5', '5');
INSERT INTO `dux_content_article` VALUES ('7', '&lt;p&gt;\r\n	&amp;nbsp;\r\n&lt;/p&gt;');
INSERT INTO `dux_content_article` VALUES ('8', '&lt;p&gt;\r\n	&amp;nbsp;\r\n&lt;/p&gt;');
INSERT INTO `dux_content_article` VALUES ('9', '&lt;p&gt;\r\n	&amp;nbsp;\r\n&lt;/p&gt;');
INSERT INTO `dux_content_article` VALUES ('10', '&lt;p&gt;\r\n	&amp;nbsp;\r\n&lt;/p&gt;');
INSERT INTO `dux_content_article` VALUES ('11', '公司网站上线测试公司网站上线测试公司网站上线测试网址：www.haifangchina.com');
INSERT INTO `dux_content_article` VALUES ('12', '&lt;p&gt;\r\n	&amp;nbsp;\r\n&lt;/p&gt;');
INSERT INTO `dux_content_article` VALUES ('14', '&lt;img alt=&quot;&quot; src=&quot;/Uploads/2015-01-31/54cc54a073b3c.jpg&quot; /&gt;');
INSERT INTO `dux_content_article` VALUES ('15', '');
INSERT INTO `dux_content_article` VALUES ('23', '');
INSERT INTO `dux_content_article` VALUES ('24', '');
INSERT INTO `dux_content_article` VALUES ('28', '');
INSERT INTO `dux_content_article` VALUES ('29', '');
INSERT INTO `dux_content_article` VALUES ('30', '');
INSERT INTO `dux_content_article` VALUES ('31', '');
INSERT INTO `dux_content_article` VALUES ('32', '&lt;p&gt;\r\n	2014\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;img src=&quot;/Uploads/2015-01-31/54cca604adb8f.jpg&quot; /&gt;\r\n&lt;/p&gt;');
INSERT INTO `dux_content_article` VALUES ('34', '');
INSERT INTO `dux_content_article` VALUES ('35', '');
INSERT INTO `dux_content_article` VALUES ('36', '');
INSERT INTO `dux_content_article` VALUES ('37', '');
INSERT INTO `dux_content_article` VALUES ('38', '');
INSERT INTO `dux_content_article` VALUES ('39', '');
INSERT INTO `dux_content_article` VALUES ('40', '');
INSERT INTO `dux_content_article` VALUES ('41', '');
INSERT INTO `dux_content_article` VALUES ('42', '');
INSERT INTO `dux_content_article` VALUES ('43', '');
INSERT INTO `dux_content_article` VALUES ('44', '');
INSERT INTO `dux_content_article` VALUES ('45', '');
INSERT INTO `dux_content_article` VALUES ('46', '');
INSERT INTO `dux_content_article` VALUES ('47', '');
INSERT INTO `dux_content_article` VALUES ('48', '');
INSERT INTO `dux_content_article` VALUES ('49', '');
INSERT INTO `dux_content_article` VALUES ('50', '');
INSERT INTO `dux_content_article` VALUES ('51', '');
INSERT INTO `dux_content_article` VALUES ('52', '');
INSERT INTO `dux_content_article` VALUES ('53', '');
INSERT INTO `dux_content_article` VALUES ('54', '');
INSERT INTO `dux_content_article` VALUES ('55', '');
INSERT INTO `dux_content_article` VALUES ('56', '');
INSERT INTO `dux_content_article` VALUES ('57', '');
INSERT INTO `dux_content_article` VALUES ('58', '');
INSERT INTO `dux_content_article` VALUES ('59', '');
INSERT INTO `dux_content_article` VALUES ('60', '');
INSERT INTO `dux_content_article` VALUES ('61', '');
INSERT INTO `dux_content_article` VALUES ('62', '');
INSERT INTO `dux_content_article` VALUES ('63', '');
INSERT INTO `dux_content_article` VALUES ('64', '');
INSERT INTO `dux_content_article` VALUES ('65', '');
INSERT INTO `dux_content_article` VALUES ('66', '');
INSERT INTO `dux_content_article` VALUES ('67', '');
INSERT INTO `dux_content_article` VALUES ('68', '');
INSERT INTO `dux_content_article` VALUES ('69', '');
INSERT INTO `dux_content_article` VALUES ('70', '');
INSERT INTO `dux_content_article` VALUES ('71', '');
INSERT INTO `dux_content_article` VALUES ('72', '');
INSERT INTO `dux_content_article` VALUES ('73', '');
INSERT INTO `dux_content_article` VALUES ('74', '');
INSERT INTO `dux_content_article` VALUES ('75', '');
INSERT INTO `dux_content_article` VALUES ('76', '');
INSERT INTO `dux_content_article` VALUES ('77', '');
INSERT INTO `dux_content_article` VALUES ('78', '');
INSERT INTO `dux_content_article` VALUES ('79', '');
INSERT INTO `dux_content_article` VALUES ('80', '');
INSERT INTO `dux_content_article` VALUES ('81', '');
INSERT INTO `dux_content_article` VALUES ('82', '');
INSERT INTO `dux_content_article` VALUES ('83', '');
INSERT INTO `dux_content_article` VALUES ('84', '');
INSERT INTO `dux_content_article` VALUES ('85', '');
INSERT INTO `dux_content_article` VALUES ('86', '');
INSERT INTO `dux_content_article` VALUES ('87', '');
INSERT INTO `dux_content_article` VALUES ('88', '');
INSERT INTO `dux_content_article` VALUES ('89', '');
INSERT INTO `dux_content_article` VALUES ('90', '');
INSERT INTO `dux_content_article` VALUES ('91', '');
INSERT INTO `dux_content_article` VALUES ('92', '');
INSERT INTO `dux_content_article` VALUES ('93', '');
INSERT INTO `dux_content_article` VALUES ('94', '');
INSERT INTO `dux_content_article` VALUES ('95', '');
INSERT INTO `dux_content_article` VALUES ('96', '');
INSERT INTO `dux_content_article` VALUES ('97', '');
INSERT INTO `dux_content_article` VALUES ('98', '');
INSERT INTO `dux_content_article` VALUES ('99', '');
INSERT INTO `dux_content_article` VALUES ('100', '');
INSERT INTO `dux_content_article` VALUES ('101', '');
INSERT INTO `dux_content_article` VALUES ('102', '');
INSERT INTO `dux_content_article` VALUES ('103', '');
INSERT INTO `dux_content_article` VALUES ('104', '');
INSERT INTO `dux_content_article` VALUES ('105', '');
INSERT INTO `dux_content_article` VALUES ('106', '');
INSERT INTO `dux_content_article` VALUES ('107', '');
INSERT INTO `dux_content_article` VALUES ('108', '');
INSERT INTO `dux_content_article` VALUES ('109', '');
INSERT INTO `dux_content_article` VALUES ('110', '');
INSERT INTO `dux_content_article` VALUES ('111', '');
INSERT INTO `dux_content_article` VALUES ('113', '');
INSERT INTO `dux_content_article` VALUES ('114', '');
INSERT INTO `dux_content_article` VALUES ('115', '');
INSERT INTO `dux_content_article` VALUES ('116', '');
INSERT INTO `dux_content_article` VALUES ('118', '');
INSERT INTO `dux_content_article` VALUES ('119', '');
INSERT INTO `dux_content_article` VALUES ('120', '');
INSERT INTO `dux_content_article` VALUES ('121', '');
INSERT INTO `dux_content_article` VALUES ('122', '');
INSERT INTO `dux_content_article` VALUES ('123', '');
INSERT INTO `dux_content_article` VALUES ('124', '');
INSERT INTO `dux_content_article` VALUES ('125', '');
INSERT INTO `dux_content_article` VALUES ('126', '');
INSERT INTO `dux_content_article` VALUES ('127', '');
INSERT INTO `dux_content_article` VALUES ('128', '');
INSERT INTO `dux_content_article` VALUES ('129', '');
INSERT INTO `dux_content_article` VALUES ('130', '');
INSERT INTO `dux_content_article` VALUES ('132', '');
INSERT INTO `dux_content_article` VALUES ('134', '');
INSERT INTO `dux_content_article` VALUES ('135', '');
INSERT INTO `dux_content_article` VALUES ('136', '');
INSERT INTO `dux_content_article` VALUES ('137', '');
INSERT INTO `dux_content_article` VALUES ('138', '');
INSERT INTO `dux_content_article` VALUES ('139', '');
INSERT INTO `dux_content_article` VALUES ('140', '');
INSERT INTO `dux_content_article` VALUES ('141', '');
INSERT INTO `dux_content_article` VALUES ('142', '');
INSERT INTO `dux_content_article` VALUES ('143', '');
INSERT INTO `dux_content_article` VALUES ('144', '');
INSERT INTO `dux_content_article` VALUES ('145', '');
INSERT INTO `dux_content_article` VALUES ('146', '');
INSERT INTO `dux_content_article` VALUES ('147', '');
INSERT INTO `dux_content_article` VALUES ('148', '');
INSERT INTO `dux_content_article` VALUES ('149', '');
INSERT INTO `dux_content_article` VALUES ('150', '');
INSERT INTO `dux_content_article` VALUES ('151', '');
INSERT INTO `dux_content_article` VALUES ('152', '');
INSERT INTO `dux_content_article` VALUES ('153', '');
INSERT INTO `dux_content_article` VALUES ('154', '');
INSERT INTO `dux_content_article` VALUES ('155', '');
INSERT INTO `dux_content_article` VALUES ('156', '');
INSERT INTO `dux_content_article` VALUES ('157', '');
INSERT INTO `dux_content_article` VALUES ('158', '');
INSERT INTO `dux_content_article` VALUES ('159', '');
INSERT INTO `dux_content_article` VALUES ('160', '');
INSERT INTO `dux_content_article` VALUES ('161', '');
INSERT INTO `dux_content_article` VALUES ('162', '');
INSERT INTO `dux_content_article` VALUES ('163', '');
INSERT INTO `dux_content_article` VALUES ('164', '房舍');
INSERT INTO `dux_content_article` VALUES ('165', '');
INSERT INTO `dux_content_article` VALUES ('166', '');
INSERT INTO `dux_content_article` VALUES ('167', '');
INSERT INTO `dux_content_article` VALUES ('168', '');
INSERT INTO `dux_content_article` VALUES ('169', '');
INSERT INTO `dux_content_article` VALUES ('170', '');
INSERT INTO `dux_content_article` VALUES ('171', '');
INSERT INTO `dux_content_article` VALUES ('172', '');
INSERT INTO `dux_content_article` VALUES ('173', '');
INSERT INTO `dux_content_article` VALUES ('174', '');
INSERT INTO `dux_content_article` VALUES ('175', '');
INSERT INTO `dux_content_article` VALUES ('176', '');
INSERT INTO `dux_content_article` VALUES ('177', '');
INSERT INTO `dux_content_article` VALUES ('178', '');
INSERT INTO `dux_content_article` VALUES ('179', '');
INSERT INTO `dux_content_article` VALUES ('180', '');
INSERT INTO `dux_content_article` VALUES ('181', '');
INSERT INTO `dux_content_article` VALUES ('182', '');
INSERT INTO `dux_content_article` VALUES ('183', '');
INSERT INTO `dux_content_article` VALUES ('184', '');
INSERT INTO `dux_content_article` VALUES ('185', '');
INSERT INTO `dux_content_article` VALUES ('186', '');
INSERT INTO `dux_content_article` VALUES ('188', '');
INSERT INTO `dux_content_article` VALUES ('189', '');
INSERT INTO `dux_content_article` VALUES ('190', '');
INSERT INTO `dux_content_article` VALUES ('191', '');
INSERT INTO `dux_content_article` VALUES ('192', '');
INSERT INTO `dux_content_article` VALUES ('193', '');
INSERT INTO `dux_content_article` VALUES ('194', '');
INSERT INTO `dux_content_article` VALUES ('195', '');
INSERT INTO `dux_content_article` VALUES ('196', '');
INSERT INTO `dux_content_article` VALUES ('197', '');
INSERT INTO `dux_content_article` VALUES ('198', '');
INSERT INTO `dux_content_article` VALUES ('199', '');
INSERT INTO `dux_content_article` VALUES ('200', '');
INSERT INTO `dux_content_article` VALUES ('201', '');
INSERT INTO `dux_content_article` VALUES ('202', '');
INSERT INTO `dux_content_article` VALUES ('203', '');
INSERT INTO `dux_content_article` VALUES ('204', '');
INSERT INTO `dux_content_article` VALUES ('205', '');
INSERT INTO `dux_content_article` VALUES ('206', '');
INSERT INTO `dux_content_article` VALUES ('207', '');
INSERT INTO `dux_content_article` VALUES ('208', '');
INSERT INTO `dux_content_article` VALUES ('209', '');
INSERT INTO `dux_content_article` VALUES ('210', '');
INSERT INTO `dux_content_article` VALUES ('211', '');
INSERT INTO `dux_content_article` VALUES ('212', '');
INSERT INTO `dux_content_article` VALUES ('213', '');
INSERT INTO `dux_content_article` VALUES ('214', '');
INSERT INTO `dux_content_article` VALUES ('215', '');
INSERT INTO `dux_content_article` VALUES ('216', '');
INSERT INTO `dux_content_article` VALUES ('217', '');
INSERT INTO `dux_content_article` VALUES ('218', '');
INSERT INTO `dux_content_article` VALUES ('219', '');
INSERT INTO `dux_content_article` VALUES ('220', '');
INSERT INTO `dux_content_article` VALUES ('221', '');
INSERT INTO `dux_content_article` VALUES ('222', '');
INSERT INTO `dux_content_article` VALUES ('223', '');
INSERT INTO `dux_content_article` VALUES ('224', '');
INSERT INTO `dux_content_article` VALUES ('225', '');
INSERT INTO `dux_content_article` VALUES ('226', '');
INSERT INTO `dux_content_article` VALUES ('227', '');
INSERT INTO `dux_content_article` VALUES ('228', '');
INSERT INTO `dux_content_article` VALUES ('229', '');
INSERT INTO `dux_content_article` VALUES ('230', '');
INSERT INTO `dux_content_article` VALUES ('231', '');
INSERT INTO `dux_content_article` VALUES ('232', '');
INSERT INTO `dux_content_article` VALUES ('233', '');
INSERT INTO `dux_content_article` VALUES ('234', '');
INSERT INTO `dux_content_article` VALUES ('235', '');
INSERT INTO `dux_content_article` VALUES ('236', '');
INSERT INTO `dux_content_article` VALUES ('237', '');
INSERT INTO `dux_content_article` VALUES ('238', '');
INSERT INTO `dux_content_article` VALUES ('239', '');
INSERT INTO `dux_content_article` VALUES ('240', '');
INSERT INTO `dux_content_article` VALUES ('241', '');
INSERT INTO `dux_content_article` VALUES ('242', '');
INSERT INTO `dux_content_article` VALUES ('243', '');
INSERT INTO `dux_content_article` VALUES ('244', '');
INSERT INTO `dux_content_article` VALUES ('245', '');
INSERT INTO `dux_content_article` VALUES ('246', '');
INSERT INTO `dux_content_article` VALUES ('247', '');
INSERT INTO `dux_content_article` VALUES ('248', '');
INSERT INTO `dux_content_article` VALUES ('249', '');
INSERT INTO `dux_content_article` VALUES ('250', '');
INSERT INTO `dux_content_article` VALUES ('251', '');
INSERT INTO `dux_content_article` VALUES ('252', '');
INSERT INTO `dux_content_article` VALUES ('253', '');
INSERT INTO `dux_content_article` VALUES ('254', '');
INSERT INTO `dux_content_article` VALUES ('255', '');
INSERT INTO `dux_content_article` VALUES ('256', '');
INSERT INTO `dux_content_article` VALUES ('257', '');
INSERT INTO `dux_content_article` VALUES ('258', '');
INSERT INTO `dux_content_article` VALUES ('259', '');
INSERT INTO `dux_content_article` VALUES ('260', '');
INSERT INTO `dux_content_article` VALUES ('261', '');
INSERT INTO `dux_content_article` VALUES ('262', '');
INSERT INTO `dux_content_article` VALUES ('263', '');
INSERT INTO `dux_content_article` VALUES ('264', '');
INSERT INTO `dux_content_article` VALUES ('265', '');
INSERT INTO `dux_content_article` VALUES ('266', '');
INSERT INTO `dux_content_article` VALUES ('267', '');
INSERT INTO `dux_content_article` VALUES ('268', '');
INSERT INTO `dux_content_article` VALUES ('269', '');
INSERT INTO `dux_content_article` VALUES ('270', '');
INSERT INTO `dux_content_article` VALUES ('271', '');
INSERT INTO `dux_content_article` VALUES ('272', '');
INSERT INTO `dux_content_article` VALUES ('273', '');
INSERT INTO `dux_content_article` VALUES ('274', '');
INSERT INTO `dux_content_article` VALUES ('275', '');
INSERT INTO `dux_content_article` VALUES ('277', '');
INSERT INTO `dux_content_article` VALUES ('278', '');
INSERT INTO `dux_content_article` VALUES ('279', '');
INSERT INTO `dux_content_article` VALUES ('280', '');
INSERT INTO `dux_content_article` VALUES ('281', '');
INSERT INTO `dux_content_article` VALUES ('282', '');
INSERT INTO `dux_content_article` VALUES ('283', '');
INSERT INTO `dux_content_article` VALUES ('284', '');
INSERT INTO `dux_content_article` VALUES ('285', '');
INSERT INTO `dux_content_article` VALUES ('286', '');
INSERT INTO `dux_content_article` VALUES ('287', '');
INSERT INTO `dux_content_article` VALUES ('288', '');
INSERT INTO `dux_content_article` VALUES ('289', '');
INSERT INTO `dux_content_article` VALUES ('290', '');
INSERT INTO `dux_content_article` VALUES ('291', '');
INSERT INTO `dux_content_article` VALUES ('292', '');
INSERT INTO `dux_content_article` VALUES ('293', '');
INSERT INTO `dux_content_article` VALUES ('294', '');
INSERT INTO `dux_content_article` VALUES ('295', '');
INSERT INTO `dux_content_article` VALUES ('296', '');
INSERT INTO `dux_content_article` VALUES ('297', '');
INSERT INTO `dux_content_article` VALUES ('298', '');
INSERT INTO `dux_content_article` VALUES ('299', '');
INSERT INTO `dux_content_article` VALUES ('300', '');
INSERT INTO `dux_content_article` VALUES ('301', '');
INSERT INTO `dux_content_article` VALUES ('302', '');
INSERT INTO `dux_content_article` VALUES ('303', '');
INSERT INTO `dux_content_article` VALUES ('304', '');
INSERT INTO `dux_content_article` VALUES ('305', '');
INSERT INTO `dux_content_article` VALUES ('306', '');
INSERT INTO `dux_content_article` VALUES ('307', '');
INSERT INTO `dux_content_article` VALUES ('309', '');
INSERT INTO `dux_content_article` VALUES ('310', '');
INSERT INTO `dux_content_article` VALUES ('311', '');
INSERT INTO `dux_content_article` VALUES ('312', '');
INSERT INTO `dux_content_article` VALUES ('313', '');
INSERT INTO `dux_content_article` VALUES ('314', '');
INSERT INTO `dux_content_article` VALUES ('315', '');
INSERT INTO `dux_content_article` VALUES ('316', '');
INSERT INTO `dux_content_article` VALUES ('317', '');
INSERT INTO `dux_content_article` VALUES ('318', '');
INSERT INTO `dux_content_article` VALUES ('319', '');
INSERT INTO `dux_content_article` VALUES ('320', '');
INSERT INTO `dux_content_article` VALUES ('321', '');
INSERT INTO `dux_content_article` VALUES ('322', '');
INSERT INTO `dux_content_article` VALUES ('323', '');
INSERT INTO `dux_content_article` VALUES ('324', '');
INSERT INTO `dux_content_article` VALUES ('325', '');
INSERT INTO `dux_content_article` VALUES ('326', '');
INSERT INTO `dux_content_article` VALUES ('327', '');
INSERT INTO `dux_content_article` VALUES ('328', '');
INSERT INTO `dux_content_article` VALUES ('329', '');
INSERT INTO `dux_content_article` VALUES ('330', '');
INSERT INTO `dux_content_article` VALUES ('331', '');
INSERT INTO `dux_content_article` VALUES ('332', '');
INSERT INTO `dux_content_article` VALUES ('333', '');
INSERT INTO `dux_content_article` VALUES ('334', '');
INSERT INTO `dux_content_article` VALUES ('335', '');
INSERT INTO `dux_content_article` VALUES ('336', '');
INSERT INTO `dux_content_article` VALUES ('337', '');
INSERT INTO `dux_content_article` VALUES ('338', '');
INSERT INTO `dux_content_article` VALUES ('339', '');
INSERT INTO `dux_content_article` VALUES ('340', '');
INSERT INTO `dux_content_article` VALUES ('342', '');
INSERT INTO `dux_content_article` VALUES ('343', '');
INSERT INTO `dux_content_article` VALUES ('344', '');
INSERT INTO `dux_content_article` VALUES ('345', '');
INSERT INTO `dux_content_article` VALUES ('346', '');
INSERT INTO `dux_content_article` VALUES ('347', '');
INSERT INTO `dux_content_article` VALUES ('348', '');
INSERT INTO `dux_content_article` VALUES ('349', '');
INSERT INTO `dux_content_article` VALUES ('350', '');
INSERT INTO `dux_content_article` VALUES ('351', '');
INSERT INTO `dux_content_article` VALUES ('352', '');
INSERT INTO `dux_content_article` VALUES ('353', '');
INSERT INTO `dux_content_article` VALUES ('354', '');
INSERT INTO `dux_content_article` VALUES ('355', '');
INSERT INTO `dux_content_article` VALUES ('356', '');
INSERT INTO `dux_content_article` VALUES ('357', '');
INSERT INTO `dux_content_article` VALUES ('358', '');
INSERT INTO `dux_content_article` VALUES ('359', '');
INSERT INTO `dux_content_article` VALUES ('360', '');
INSERT INTO `dux_content_article` VALUES ('361', '');
INSERT INTO `dux_content_article` VALUES ('362', '');
INSERT INTO `dux_content_article` VALUES ('363', '');
INSERT INTO `dux_content_article` VALUES ('364', '');
INSERT INTO `dux_content_article` VALUES ('365', '');
INSERT INTO `dux_content_article` VALUES ('366', '');
INSERT INTO `dux_content_article` VALUES ('367', '');
INSERT INTO `dux_content_article` VALUES ('368', '');
INSERT INTO `dux_content_article` VALUES ('370', '');
INSERT INTO `dux_content_article` VALUES ('371', '');
INSERT INTO `dux_content_article` VALUES ('372', '');
INSERT INTO `dux_content_article` VALUES ('373', '');
INSERT INTO `dux_content_article` VALUES ('374', '');
INSERT INTO `dux_content_article` VALUES ('375', '');

-- -----------------------------
-- Table structure for `dux_ext_down`
-- -----------------------------
DROP TABLE IF EXISTS `dux_ext_down`;
CREATE TABLE `dux_ext_down` (
  `data_id` int(10) DEFAULT NULL,
  `downurl` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `dux_ext_down`
-- -----------------------------
INSERT INTO `dux_ext_down` VALUES ('12', '/Uploads/2015-02-02/54cf6c1766f41.PDF');
INSERT INTO `dux_ext_down` VALUES ('320', '/Uploads/2015-02-02/54cf6ef96e953.pdf');
INSERT INTO `dux_ext_down` VALUES ('321', '/Uploads/2015-02-03/54d0402dea340.ppt');

-- -----------------------------
-- Table structure for `dux_ext_event`
-- -----------------------------
DROP TABLE IF EXISTS `dux_ext_event`;
CREATE TABLE `dux_ext_event` (
  `data_id` int(10) DEFAULT NULL,
  `year` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `dux_ext_event`
-- -----------------------------
INSERT INTO `dux_ext_event` VALUES ('186', '');
INSERT INTO `dux_ext_event` VALUES ('188', '');
INSERT INTO `dux_ext_event` VALUES ('189', '');
INSERT INTO `dux_ext_event` VALUES ('190', '');
INSERT INTO `dux_ext_event` VALUES ('191', '');
INSERT INTO `dux_ext_event` VALUES ('192', '');
INSERT INTO `dux_ext_event` VALUES ('193', '');
INSERT INTO `dux_ext_event` VALUES ('194', '');
INSERT INTO `dux_ext_event` VALUES ('195', '');
INSERT INTO `dux_ext_event` VALUES ('196', '');
INSERT INTO `dux_ext_event` VALUES ('359', '');
INSERT INTO `dux_ext_event` VALUES ('360', '');
INSERT INTO `dux_ext_event` VALUES ('361', '');
INSERT INTO `dux_ext_event` VALUES ('362', '');
INSERT INTO `dux_ext_event` VALUES ('363', '2015');

-- -----------------------------
-- Table structure for `dux_ext_guestbook`
-- -----------------------------
DROP TABLE IF EXISTS `dux_ext_guestbook`;
CREATE TABLE `dux_ext_guestbook` (
  `data_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `content` text,
  `time` int(10) DEFAULT NULL,
  PRIMARY KEY (`data_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `dux_ext_video`
-- -----------------------------
DROP TABLE IF EXISTS `dux_ext_video`;
CREATE TABLE `dux_ext_video` (
  `data_id` int(10) DEFAULT NULL,
  `video` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `dux_ext_video`
-- -----------------------------
INSERT INTO `dux_ext_video` VALUES ('309', '<embed src=\"http://player.youku.com/player.php/sid/XODg0Nzk0ODA0/v.swf\" allowFullScreen=\"true\" quality=\"high\" width=\"480\" height=\"400\" align=\"middle\" allowScriptAccess=\"always\" type=\"application/x-shockwave-flash\"></embed>');
INSERT INTO `dux_ext_video` VALUES ('310', '<embed src=\"http://player.youku.com/player.php/sid/XODg0ODA1NTIw/v.swf\" allowFullScreen=\"true\" quality=\"high\" width=\"480\" height=\"400\" align=\"middle\" allowScriptAccess=\"always\" type=\"application/x-shockwave-flash\"></embed>');
INSERT INTO `dux_ext_video` VALUES ('311', '<embed src=\"http://player.youku.com/player.php/sid/XODg0ODA2MjY4/v.swf\" allowFullScreen=\"true\" quality=\"high\" width=\"480\" height=\"400\" align=\"middle\" allowScriptAccess=\"always\" type=\"application/x-shockwave-flash\"></embed> ');
INSERT INTO `dux_ext_video` VALUES ('312', '<embed src=\"http://player.youku.com/player.php/sid/XODg0ODA3MjY0/v.swf\" allowFullScreen=\"true\" quality=\"high\" width=\"480\" height=\"400\" align=\"middle\" allowScriptAccess=\"always\" type=\"application/x-shockwave-flash\"></embed>');
INSERT INTO `dux_ext_video` VALUES ('313', '<embed src=\"http://player.youku.com/player.php/sid/XODg0ODA4NjY0/v.swf\" allowFullScreen=\"true\" quality=\"high\" width=\"480\" height=\"400\" align=\"middle\" allowScriptAccess=\"always\" type=\"application/x-shockwave-flash\"></embed>');
INSERT INTO `dux_ext_video` VALUES ('314', '<embed src=\"http://player.youku.com/player.php/sid/XODg0ODIyNjI4/v.swf\" allowFullScreen=\"true\" quality=\"high\" width=\"480\" height=\"400\" align=\"middle\" allowScriptAccess=\"always\" type=\"application/x-shockwave-flash\"></embed>');
INSERT INTO `dux_ext_video` VALUES ('315', '<embed src=\"http://player.youku.com/player.php/sid/XODg0Nzk0Nzky/v.swf\" allowFullScreen=\"true\" quality=\"high\" width=\"480\" height=\"400\" align=\"middle\" allowScriptAccess=\"always\" type=\"application/x-shockwave-flash\"></embed>');
INSERT INTO `dux_ext_video` VALUES ('316', '<embed src=\"http://player.youku.com/player.php/sid/XODg0ODEwNjc2/v.swf\" allowFullScreen=\"true\" quality=\"high\" width=\"480\" height=\"400\" align=\"middle\" allowScriptAccess=\"always\" type=\"application/x-shockwave-flash\"></embed>');
INSERT INTO `dux_ext_video` VALUES ('317', '<embed src=\"http://player.youku.com/player.php/sid/XODg0ODA5OTUy/v.swf\" allowFullScreen=\"true\" quality=\"high\" width=\"480\" height=\"400\" align=\"middle\" allowScriptAccess=\"always\" type=\"application/x-shockwave-flash\"></embed>');
INSERT INTO `dux_ext_video` VALUES ('318', '<embed src=\"http://player.youku.com/player.php/sid/XODg0ODEyNDA4/v.swf\" allowFullScreen=\"true\" quality=\"high\" width=\"480\" height=\"400\" align=\"middle\" allowScriptAccess=\"always\" type=\"application/x-shockwave-flash\"></embed>');
INSERT INTO `dux_ext_video` VALUES ('319', '<embed src=\"http://player.youku.com/player.php/sid/XODg0Nzk0ODI4/v.swf\" allowFullScreen=\"true\" quality=\"high\" width=\"480\" height=\"400\" align=\"middle\" allowScriptAccess=\"always\" type=\"application/x-shockwave-flash\"></embed>');

-- -----------------------------
-- Table structure for `dux_field`
-- -----------------------------
DROP TABLE IF EXISTS `dux_field`;
CREATE TABLE `dux_field` (
  `field_id` int(10) NOT NULL AUTO_INCREMENT,
  `fieldset_id` int(10) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `field` varchar(250) DEFAULT NULL,
  `type` int(5) DEFAULT '1',
  `tip` varchar(250) DEFAULT NULL,
  `verify_type` varchar(250) DEFAULT NULL,
  `verify_data` text,
  `verify_data_js` text,
  `verify_condition` tinyint(1) DEFAULT NULL,
  `default` varchar(250) DEFAULT NULL,
  `sequence` int(10) DEFAULT '0',
  `errormsg` varchar(250) DEFAULT NULL,
  `config` text,
  PRIMARY KEY (`field_id`),
  KEY `field` (`field`),
  KEY `sequence` (`sequence`),
  KEY `fieldset_id` (`fieldset_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='扩展字段基础';

-- -----------------------------
-- Records of `dux_field`
-- -----------------------------
INSERT INTO `dux_field` VALUES ('1', '1', '昵称', 'name', '1', '', 'regex', 'cmVxdWlyZQ==', 'Kg==', '1', '', '0', '', '');
INSERT INTO `dux_field` VALUES ('2', '1', '邮箱', 'email', '1', '', 'regex', 'ZW1haWw=', 'ZQ==', '1', '', '1', '', '');
INSERT INTO `dux_field` VALUES ('3', '1', '内容', 'content', '2', '', 'regex', 'cmVxdWlyZQ==', 'Kg==', '1', '', '3', '', '');
INSERT INTO `dux_field` VALUES ('4', '1', '时间', 'time', '10', '', 'regex', '', '', '1', '', '2', '', '');
INSERT INTO `dux_field` VALUES ('5', '2', '资料下载', 'downurl', '4', '', 'regex', '', '', '1', '', '0', '', '');
INSERT INTO `dux_field` VALUES ('6', '3', '年', 'year', '1', '', 'regex', '', '', '1', '', '0', '', '');
INSERT INTO `dux_field` VALUES ('7', '4', '视频地址', 'video', '2', '', 'regex', '', '', '1', '', '0', '', '');

-- -----------------------------
-- Table structure for `dux_field_expand`
-- -----------------------------
DROP TABLE IF EXISTS `dux_field_expand`;
CREATE TABLE `dux_field_expand` (
  `field_id` int(10) DEFAULT NULL,
  `post` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='扩展字段-扩展模型';

-- -----------------------------
-- Records of `dux_field_expand`
-- -----------------------------
INSERT INTO `dux_field_expand` VALUES ('5', '');
INSERT INTO `dux_field_expand` VALUES ('6', '');
INSERT INTO `dux_field_expand` VALUES ('7', '');

-- -----------------------------
-- Table structure for `dux_field_form`
-- -----------------------------
DROP TABLE IF EXISTS `dux_field_form`;
CREATE TABLE `dux_field_form` (
  `field_id` int(10) DEFAULT NULL,
  `post` tinyint(1) DEFAULT '0',
  `show` tinyint(1) DEFAULT '0',
  `search` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='扩展字段-表单';

-- -----------------------------
-- Records of `dux_field_form`
-- -----------------------------
INSERT INTO `dux_field_form` VALUES ('1', '1', '1', '1');
INSERT INTO `dux_field_form` VALUES ('2', '1', '1', '1');
INSERT INTO `dux_field_form` VALUES ('3', '1', '1', '1');
INSERT INTO `dux_field_form` VALUES ('4', '0', '1', '1');
INSERT INTO `dux_field_form` VALUES ('1', '1', '1', '1');
INSERT INTO `dux_field_form` VALUES ('2', '1', '1', '1');
INSERT INTO `dux_field_form` VALUES ('3', '1', '1', '1');
INSERT INTO `dux_field_form` VALUES ('4', '0', '1', '1');

-- -----------------------------
-- Table structure for `dux_fieldset`
-- -----------------------------
DROP TABLE IF EXISTS `dux_fieldset`;
CREATE TABLE `dux_fieldset` (
  `fieldset_id` int(10) NOT NULL AUTO_INCREMENT,
  `table` varchar(250) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`fieldset_id`),
  UNIQUE KEY `table` (`table`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='字段集基础';

-- -----------------------------
-- Records of `dux_fieldset`
-- -----------------------------
INSERT INTO `dux_fieldset` VALUES ('1', 'guestbook', '留言板');
INSERT INTO `dux_fieldset` VALUES ('2', 'down', '下载');
INSERT INTO `dux_fieldset` VALUES ('3', 'event', 'event');
INSERT INTO `dux_fieldset` VALUES ('4', 'video', '视频地址');

-- -----------------------------
-- Table structure for `dux_fieldset_expand`
-- -----------------------------
DROP TABLE IF EXISTS `dux_fieldset_expand`;
CREATE TABLE `dux_fieldset_expand` (
  `fieldset_id` int(10) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  UNIQUE KEY `fieldset_id` (`fieldset_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='字段集-扩展模型';

-- -----------------------------
-- Records of `dux_fieldset_expand`
-- -----------------------------
INSERT INTO `dux_fieldset_expand` VALUES ('2', '1');
INSERT INTO `dux_fieldset_expand` VALUES ('3', '1');
INSERT INTO `dux_fieldset_expand` VALUES ('4', '1');

-- -----------------------------
-- Table structure for `dux_fieldset_form`
-- -----------------------------
DROP TABLE IF EXISTS `dux_fieldset_form`;
CREATE TABLE `dux_fieldset_form` (
  `fieldset_id` int(10) DEFAULT NULL,
  `show_list` tinyint(1) DEFAULT NULL,
  `show_info` tinyint(1) DEFAULT NULL,
  `list_page` int(5) DEFAULT NULL,
  `list_where` varchar(250) DEFAULT NULL,
  `list_order` varchar(250) DEFAULT NULL,
  `tpl_list` varchar(250) DEFAULT NULL,
  `tpl_info` varchar(250) DEFAULT NULL,
  `post_status` tinyint(1) DEFAULT NULL,
  `post_msg` varchar(250) DEFAULT NULL,
  `post_return_url` varchar(250) DEFAULT NULL,
  UNIQUE KEY `fieldset_id` (`fieldset_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='字段集-扩展表单';

-- -----------------------------
-- Records of `dux_fieldset_form`
-- -----------------------------
INSERT INTO `dux_fieldset_form` VALUES ('1', '1', '0', '10', '', 'data_id desc', 'guestbook', 'guestbook', '1', '留言发布成功！', '');

-- -----------------------------
-- Table structure for `dux_file`
-- -----------------------------
DROP TABLE IF EXISTS `dux_file`;
CREATE TABLE `dux_file` (
  `file_id` int(10) NOT NULL AUTO_INCREMENT,
  `url` varchar(250) DEFAULT NULL,
  `original` varchar(250) DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  `ext` varchar(250) DEFAULT NULL,
  `size` int(10) DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  PRIMARY KEY (`file_id`),
  KEY `ext` (`ext`),
  KEY `time` (`time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=431 DEFAULT CHARSET=utf8 COMMENT='上传文件';

-- -----------------------------
-- Records of `dux_file`
-- -----------------------------
INSERT INTO `dux_file` VALUES ('1', '/Uploads/2015-01-17/54ba344809a4c.gif', '/Uploads/2015-01-17/54ba344809a4c.gif', 'banner.gif', 'gif', '73274', '1421489224');
INSERT INTO `dux_file` VALUES ('2', '/Uploads/2015-01-17/54ba35be65324.jpg', '/Uploads/2015-01-17/54ba35be65324.jpg', '2.jpg', 'jpg', '75545', '1421489598');
INSERT INTO `dux_file` VALUES ('3', '/Uploads/2015-01-17/54ba36561cb79.jpg', '/Uploads/2015-01-17/54ba36561cb79.jpg', '3.jpg', 'jpg', '67904', '1421489750');
INSERT INTO `dux_file` VALUES ('4', '/Uploads/2015-01-17/54ba379442dd3.jpg', '/Uploads/2015-01-17/54ba379442dd3.jpg', '4.jpg', 'jpg', '79075', '1421490068');
INSERT INTO `dux_file` VALUES ('5', '/Uploads/2015-01-17/54ba37d559c09.jpg', '/Uploads/2015-01-17/54ba37d559c09.jpg', '4.jpg', 'jpg', '78020', '1421490133');
INSERT INTO `dux_file` VALUES ('6', '/Uploads/2015-01-17/54ba385c74748.jpg', '/Uploads/2015-01-17/54ba385c74748.jpg', '5.jpg', 'jpg', '30226', '1421490268');
INSERT INTO `dux_file` VALUES ('7', '/Uploads/2015-01-17/54ba3b5c78451.jpg', '/Uploads/2015-01-17/54ba3b5c78451.jpg', '20140717001751_7139_48.jpg', 'jpg', '66270', '1421491036');
INSERT INTO `dux_file` VALUES ('8', '/Uploads/2015-01-17/54ba3b8e78451.jpg', '/Uploads/2015-01-17/54ba3b8e78451.jpg', '详情页——1.jpg', 'jpg', '1581795', '1421491086');
INSERT INTO `dux_file` VALUES ('9', '/Uploads/2015-01-18/54bb72a529c2d.gif', '/Uploads/2015-01-18/54bb72a529c2d.gif', 'introduce.gif', 'gif', '66675', '1421570725');
INSERT INTO `dux_file` VALUES ('10', '/Uploads/2015-01-18/54bb86c0dd4d4.gif', '/Uploads/2015-01-18/54bb86c0dd4d4.gif', '1.gif', 'gif', '42862', '1421575872');
INSERT INTO `dux_file` VALUES ('11', '/Uploads/2015-01-18/54bb86d1bec8c.gif', '/Uploads/2015-01-18/54bb86d1bec8c.gif', '2.gif', 'gif', '24728', '1421575889');
INSERT INTO `dux_file` VALUES ('12', '/Uploads/2015-01-18/54bb86e1f0601.gif', '/Uploads/2015-01-18/54bb86e1f0601.gif', '3.gif', 'gif', '42032', '1421575906');
INSERT INTO `dux_file` VALUES ('13', '/Uploads/2015-01-18/54bb86f54c57e.gif', '/Uploads/2015-01-18/54bb86f54c57e.gif', '4.gif', 'gif', '35346', '1421575925');
INSERT INTO `dux_file` VALUES ('14', '/Uploads/2015-01-18/54bb94c2bec8c.txt', '/Uploads/2015-01-18/54bb94c2bec8c.txt', '新建 Text Document.txt', 'txt', '812', '1421579458');
INSERT INTO `dux_file` VALUES ('15', '/Uploads/2015-01-31/54cc549436aac.jpg', '/Uploads/2015-01-31/54cc549436aac.jpg', '房舍1.jpg', 'jpg', '319308', '1422677140');
INSERT INTO `dux_file` VALUES ('16', '/Uploads/2015-01-31/54cc54a073b3c.jpg', '/Uploads/2015-01-31/54cc54a073b3c.jpg', '房舍1.jpg', 'jpg', '319308', '1422677152');
INSERT INTO `dux_file` VALUES ('17', '/Uploads/2015-01-31/54cc586e77845.jpg', '/Uploads/2015-01-31/54cc586e77845.jpg', '大象1.jpg', 'jpg', '275978', '1422678126');
INSERT INTO `dux_file` VALUES ('18', '/Uploads/2015-01-31/54cc58de3e4be.jpg', '/Uploads/2015-01-31/54cc58de3e4be.jpg', '进化史.jpg', 'jpg', '315550', '1422678238');
INSERT INTO `dux_file` VALUES ('19', '/Uploads/2015-01-31/54cc5e779df05.jpg', '/Uploads/2015-01-31/54cc5e779df05.jpg', '详情页——1.jpg', 'jpg', '1581795', '1422679671');
INSERT INTO `dux_file` VALUES ('20', '/Uploads/2015-01-31/54cc60e15d29f.jpg', '/Uploads/2015-01-31/54cc60e15d29f.jpg', '托盘.jpg', 'jpg', '137353', '1422680289');
INSERT INTO `dux_file` VALUES ('21', '/Uploads/2015-01-31/54cc611527c21.jpg', '/Uploads/2015-01-31/54cc611527c21.jpg', '企业责任.jpg', 'jpg', '266203', '1422680341');
INSERT INTO `dux_file` VALUES ('22', '/Uploads/2015-01-31/54cc61b63ea57.jpg', '/Uploads/2015-01-31/54cc61b63ea57.jpg', '方形纸管托盘——四面进叉1.jpg', 'jpg', '263780', '1422680502');
INSERT INTO `dux_file` VALUES ('23', '/Uploads/2015-01-31/54cc624b2020f.jpg', '/Uploads/2015-01-31/54cc624b2020f.jpg', '详情页——托盘.jpg', 'jpg', '2104845', '1422680651');
INSERT INTO `dux_file` VALUES ('24', '/Uploads/2015-01-31/54cc62d65d29f.jpg', '/Uploads/2015-01-31/54cc62d65d29f.jpg', '包装箱2.jpg', 'jpg', '262024', '1422680790');
INSERT INTO `dux_file` VALUES ('25', '/Uploads/2015-01-31/54cc62e63ea57.jpg', '/Uploads/2015-01-31/54cc62e63ea57.jpg', '详情页——包装箱.jpg', 'jpg', '2855229', '1422680806');
INSERT INTO `dux_file` VALUES ('26', '/Uploads/2015-01-31/54cc63676c6c3.jpg', '/Uploads/2015-01-31/54cc63676c6c3.jpg', '框架包装4.jpg', 'jpg', '269045', '1422680935');
INSERT INTO `dux_file` VALUES ('27', '/Uploads/2015-01-31/54cc637414af4.jpg', '/Uploads/2015-01-31/54cc637414af4.jpg', '详情页——框架包装.jpg', 'jpg', '2813137', '1422680948');
INSERT INTO `dux_file` VALUES ('28', '/Uploads/2015-01-31/54cc8b6268cee.jpg', '/Uploads/2015-01-31/54cc8b6268cee.jpg', '物流托盘.jpg', 'jpg', '252254', '1422691170');
INSERT INTO `dux_file` VALUES ('29', '/Uploads/2015-01-31/54cc8d8887536.jpg', '/Uploads/2015-01-31/54cc8d8887536.jpg', '方形纸管.jpg', 'jpg', '204188', '1422691720');
INSERT INTO `dux_file` VALUES ('30', '/Uploads/2015-01-31/54cc8e1970700.jpg', '/Uploads/2015-01-31/54cc8e1970700.jpg', '包装箱.jpg', 'jpg', '187196', '1422691865');
INSERT INTO `dux_file` VALUES ('31', '/Uploads/2015-01-31/54cc8ea48382d.jpg', '/Uploads/2015-01-31/54cc8ea48382d.jpg', '包装箱.jpg', 'jpg', '187196', '1422692004');
INSERT INTO `dux_file` VALUES ('32', '/Uploads/2015-01-31/54cc8f60c08bd.jpg', '/Uploads/2015-01-31/54cc8f60c08bd.jpg', '框架包装.jpg', 'jpg', '266039', '1422692192');
INSERT INTO `dux_file` VALUES ('33', '/Uploads/2015-01-31/54cc8f939a663.jpg', '/Uploads/2015-01-31/54cc8f939a663.jpg', '内置外包装.jpg', 'jpg', '257661', '1422692243');
INSERT INTO `dux_file` VALUES ('34', '/Uploads/2015-01-31/54cc8fd4612dc.jpg', '/Uploads/2015-01-31/54cc8fd4612dc.jpg', '展架堆头架.jpg', 'jpg', '262976', '1422692308');
INSERT INTO `dux_file` VALUES ('35', '/Uploads/2015-01-31/54cc9032a5d7e.jpg', '/Uploads/2015-01-31/54cc9032a5d7e.jpg', '商装家装.jpg', 'jpg', '341949', '1422692402');
INSERT INTO `dux_file` VALUES ('36', '/Uploads/2015-01-31/54cc9097d76f3.jpg', '/Uploads/2015-01-31/54cc9097d76f3.jpg', '家居办公.jpg', 'jpg', '395329', '1422692503');
INSERT INTO `dux_file` VALUES ('37', '/Uploads/2015-01-31/54cc91017be1b.jpg', '/Uploads/2015-01-31/54cc91017be1b.jpg', '房屋临时安置.jpg', 'jpg', '356169', '1422692609');
INSERT INTO `dux_file` VALUES ('38', '/Uploads/2015-01-31/54cc9124b1499.jpg', '/Uploads/2015-01-31/54cc9124b1499.jpg', '概念产品.jpg', 'jpg', '250586', '1422692644');
INSERT INTO `dux_file` VALUES ('39', '/Uploads/2015-01-31/54cc9b554a50c.jpg', '/Uploads/2015-01-31/54cc9b554a50c.jpg', '荣誉.jpg', 'jpg', '192314', '1422695253');
INSERT INTO `dux_file` VALUES ('40', '/Uploads/2015-01-31/54cca4b518f30.jpg', '/Uploads/2015-01-31/54cca4b518f30.jpg', '创意展架——第十届文博会5.jpg', 'jpg', '492862', '1422697653');
INSERT INTO `dux_file` VALUES ('41', '/Uploads/2015-01-31/54cca50987935.jpg', '/Uploads/2015-01-31/54cca50987935.jpg', 'LED T5 T8灯管包装1.jpg', 'jpg', '261678', '1422697737');
INSERT INTO `dux_file` VALUES ('42', '/Uploads/2015-01-31/54cca57428354.jpg', '/Uploads/2015-01-31/54cca57428354.jpg', '摩托车框架包装.jpg', 'jpg', '237612', '1422697844');
INSERT INTO `dux_file` VALUES ('43', '/Uploads/2015-01-31/54cca604adb8f.jpg', '/Uploads/2015-01-31/54cca604adb8f.jpg', '包装箱——河北激光研究所2.jpg', 'jpg', '386826', '1422697988');
INSERT INTO `dux_file` VALUES ('44', '/Uploads/2015-01-31/54ccdf813b94e.gif', '/Uploads/2015-01-31/54ccdf813b94e.gif', 'layout.gif', 'gif', '203250', '1422712705');
INSERT INTO `dux_file` VALUES ('45', '/Uploads/2015-01-31/54ccdfab74cd5.gif', '/Uploads/2015-01-31/54ccdfab74cd5.gif', 'layout.gif', 'gif', '203250', '1422712747');
INSERT INTO `dux_file` VALUES ('46', '/Uploads/2015-02-01/54cdb3a17a778.jpg', '/Uploads/2015-02-01/54cdb3a17a778.jpg', '海方简介.jpg', 'jpg', '435845', '1422767009');
INSERT INTO `dux_file` VALUES ('47', '/Uploads/2015-02-01/54cdb3d31748e.jpg', '/Uploads/2015-02-01/54cdb3d31748e.jpg', '海方简介.jpg', 'jpg', '435845', '1422767059');
INSERT INTO `dux_file` VALUES ('48', '/Uploads/2015-02-01/54cdb4405451e.jpg', '/Uploads/2015-02-01/54cdb4405451e.jpg', '董事长致辞.jpg', 'jpg', '442081', '1422767168');
INSERT INTO `dux_file` VALUES ('49', '/Uploads/2015-02-01/54cdb4bda09d2.jpg', '/Uploads/2015-02-01/54cdb4bda09d2.jpg', '董事长致辞.jpg', 'jpg', '442081', '1422767293');
INSERT INTO `dux_file` VALUES ('50', '/Uploads/2015-02-01/54cdb4f0a83e4.jpg', '/Uploads/2015-02-01/54cdb4f0a83e4.jpg', '董事长致辞.jpg', 'jpg', '442081', '1422767344');
INSERT INTO `dux_file` VALUES ('51', '/Uploads/2015-02-01/54cdbedb450fa.jpg', '/Uploads/2015-02-01/54cdbedb450fa.jpg', '方形纸管1.jpg', 'jpg', '164627', '1422769883');
INSERT INTO `dux_file` VALUES ('52', '/Uploads/2015-02-01/54cdbf2204361.jpg', '/Uploads/2015-02-01/54cdbf2204361.jpg', '方形纸管12.jpg', 'jpg', '380192', '1422769954');
INSERT INTO `dux_file` VALUES ('53', '/Uploads/2015-02-01/54cdbf5458227.jpg', '/Uploads/2015-02-01/54cdbf5458227.jpg', '方形纸管10.jpg', 'jpg', '454788', '1422770004');
INSERT INTO `dux_file` VALUES ('54', '/Uploads/2015-02-01/54cdbf67ca935.jpg', '/Uploads/2015-02-01/54cdbf67ca935.jpg', '方形纸管9.jpg', 'jpg', '449390', '1422770023');
INSERT INTO `dux_file` VALUES ('55', '/Uploads/2015-02-01/54cdbf9dbf21a.jpg', '/Uploads/2015-02-01/54cdbf9dbf21a.jpg', '方形纸管8.jpg', 'jpg', '148572', '1422770077');
INSERT INTO `dux_file` VALUES ('56', '/Uploads/2015-02-01/54cdbfb8b3aff.jpg', '/Uploads/2015-02-01/54cdbfb8b3aff.jpg', '方形纸管7.jpg', 'jpg', '238799', '1422770104');
INSERT INTO `dux_file` VALUES ('57', '/Uploads/2015-02-01/54cdc24d399df.jpg', '/Uploads/2015-02-01/54cdc24d399df.jpg', '方形纸管5.jpg', 'jpg', '372433', '1422770765');
INSERT INTO `dux_file` VALUES ('58', '/Uploads/2015-02-01/54cdc25e63942.jpg', '/Uploads/2015-02-01/54cdc25e63942.jpg', '方形纸管4.jpg', 'jpg', '345705', '1422770782');
INSERT INTO `dux_file` VALUES ('59', '/Uploads/2015-02-01/54cdc270268b2.jpg', '/Uploads/2015-02-01/54cdc270268b2.jpg', '方形纸管3.jpg', 'jpg', '276836', '1422770800');
INSERT INTO `dux_file` VALUES ('60', '/Uploads/2015-02-01/54cdc28bc2f23.jpg', '/Uploads/2015-02-01/54cdc28bc2f23.jpg', '方形纸管6.jpg', 'jpg', '390995', '1422770827');
INSERT INTO `dux_file` VALUES ('61', '/Uploads/2015-02-01/54cdc2b650815.jpg', '/Uploads/2015-02-01/54cdc2b650815.jpg', '方形纸管1.jpg', 'jpg', '164627', '1422770870');
INSERT INTO `dux_file` VALUES ('62', '/Uploads/2015-02-01/54cdc2c6b3aff.jpg', '/Uploads/2015-02-01/54cdc2c6b3aff.jpg', '方形纸管2.jpg', 'jpg', '149660', '1422770886');
INSERT INTO `dux_file` VALUES ('63', '/Uploads/2015-02-01/54cdc36f04361.jpg', '/Uploads/2015-02-01/54cdc36f04361.jpg', '54cc8d8887536.jpg', 'jpg', '204188', '1422771055');
INSERT INTO `dux_file` VALUES ('64', '/Uploads/2015-02-01/54cdc4956b354.jpg', '/Uploads/2015-02-01/54cdc4956b354.jpg', '方形纸管蜂窝托盘——四面进叉1.jpg', 'jpg', '212293', '1422771349');
INSERT INTO `dux_file` VALUES ('65', '/Uploads/2015-02-01/54cdc528afdf6.jpg', '/Uploads/2015-02-01/54cdc528afdf6.jpg', '方形纸管蜂窝托盘——四面进叉2.jpg', 'jpg', '254063', '1422771496');
INSERT INTO `dux_file` VALUES ('66', '/Uploads/2015-02-01/54cdc5531748e.jpg', '/Uploads/2015-02-01/54cdc5531748e.jpg', '方形纸管托盘——两面进叉2.jpg', 'jpg', '330780', '1422771539');
INSERT INTO `dux_file` VALUES ('67', '/Uploads/2015-02-01/54cdc573d2347.jpg', '/Uploads/2015-02-01/54cdc573d2347.jpg', '方形纸管托盘——两面进叉1.jpg', 'jpg', '202933', '1422771571');
INSERT INTO `dux_file` VALUES ('68', '/Uploads/2015-02-01/54cdc598ca935.jpg', '/Uploads/2015-02-01/54cdc598ca935.jpg', '方形纸管托盘——四面进叉1.jpg', 'jpg', '263780', '1422771608');
INSERT INTO `dux_file` VALUES ('69', '/Uploads/2015-02-01/54cdc6616b354.jpg', '/Uploads/2015-02-01/54cdc6616b354.jpg', '包装箱11.jpg', 'jpg', '304046', '1422771809');
INSERT INTO `dux_file` VALUES ('70', '/Uploads/2015-02-01/54cdc6a150815.jpg', '/Uploads/2015-02-01/54cdc6a150815.jpg', '包装箱12.jpg', 'jpg', '263018', '1422771873');
INSERT INTO `dux_file` VALUES ('71', '/Uploads/2015-02-01/54cdc6c80fa7c.jpg', '/Uploads/2015-02-01/54cdc6c80fa7c.jpg', '包装箱1.jpg', 'jpg', '210460', '1422771912');
INSERT INTO `dux_file` VALUES ('72', '/Uploads/2015-02-01/54cdc6e6a46db.jpg', '/Uploads/2015-02-01/54cdc6e6a46db.jpg', '包装箱2.jpg', 'jpg', '262024', '1422771942');
INSERT INTO `dux_file` VALUES ('73', '/Uploads/2015-02-01/54cdc7044cb0c.jpg', '/Uploads/2015-02-01/54cdc7044cb0c.jpg', '包装箱3.jpg', 'jpg', '208028', '1422771972');
INSERT INTO `dux_file` VALUES ('74', '/Uploads/2015-02-01/54cdc71ce5474.jpg', '/Uploads/2015-02-01/54cdc71ce5474.jpg', '包装箱4.jpg', 'jpg', '182262', '1422771996');
INSERT INTO `dux_file` VALUES ('75', '/Uploads/2015-02-01/54cdc7455bf30.jpg', '/Uploads/2015-02-01/54cdc7455bf30.jpg', '包装箱5.jpg', 'jpg', '208696', '1422772037');
INSERT INTO `dux_file` VALUES ('76', '/Uploads/2015-02-01/54cdc75c1eea0.jpg', '/Uploads/2015-02-01/54cdc75c1eea0.jpg', '包装箱6.jpg', 'jpg', '297431', '1422772060');
INSERT INTO `dux_file` VALUES ('77', '/Uploads/2015-02-01/54cdc76dd9d59.jpg', '/Uploads/2015-02-01/54cdc76dd9d59.jpg', '包装箱7.jpg', 'jpg', '363806', '1422772077');
INSERT INTO `dux_file` VALUES ('78', '/Uploads/2015-02-01/54cdc78b5bf30.jpg', '/Uploads/2015-02-01/54cdc78b5bf30.jpg', '包装箱8.jpg', 'jpg', '247026', '1422772107');
INSERT INTO `dux_file` VALUES ('79', '/Uploads/2015-02-01/54cdc7a25fc39.jpg', '/Uploads/2015-02-01/54cdc7a25fc39.jpg', '包装箱9.jpg', 'jpg', '293508', '1422772130');
INSERT INTO `dux_file` VALUES ('80', '/Uploads/2015-02-01/54cdc7b1e917d.jpg', '/Uploads/2015-02-01/54cdc7b1e917d.jpg', '包装箱10.jpg', 'jpg', '282878', '1422772145');
INSERT INTO `dux_file` VALUES ('81', '/Uploads/2015-02-01/54cdc7ddbb511.jpg', '/Uploads/2015-02-01/54cdc7ddbb511.jpg', '包装箱——河北激光研究所4.jpg', 'jpg', '270460', '1422772189');
INSERT INTO `dux_file` VALUES ('82', '/Uploads/2015-02-01/54cdc7e9e917d.jpg', '/Uploads/2015-02-01/54cdc7e9e917d.jpg', '包装箱——河北激光研究所3.jpg', 'jpg', '401478', '1422772201');
INSERT INTO `dux_file` VALUES ('83', '/Uploads/2015-02-01/54cdc7fdbb511.jpg', '/Uploads/2015-02-01/54cdc7fdbb511.jpg', '包装箱——河北激光研究所2.jpg', 'jpg', '386826', '1422772221');
INSERT INTO `dux_file` VALUES ('84', '/Uploads/2015-02-01/54cdc81a450fa.jpg', '/Uploads/2015-02-01/54cdc81a450fa.jpg', '包装箱——河北激光研究所1.jpg', 'jpg', '317170', '1422772250');
INSERT INTO `dux_file` VALUES ('85', '/Uploads/2015-02-01/54cdc82b2a5bb.jpg', '/Uploads/2015-02-01/54cdc82b2a5bb.jpg', '包装箱14.jpg', 'jpg', '169935', '1422772267');
INSERT INTO `dux_file` VALUES ('86', '/Uploads/2015-02-01/54cdc8871748e.jpg', '/Uploads/2015-02-01/54cdc8871748e.jpg', '框架包装6.jpg', 'jpg', '137783', '1422772359');
INSERT INTO `dux_file` VALUES ('87', '/Uploads/2015-02-01/54cdc8a72a5bb.jpg', '/Uploads/2015-02-01/54cdc8a72a5bb.jpg', 'H160电机框架包装.jpg', 'jpg', '329501', '1422772391');
INSERT INTO `dux_file` VALUES ('88', '/Uploads/2015-02-01/54cdc968915ae.jpg', '/Uploads/2015-02-01/54cdc968915ae.jpg', 'H160电机框架包装2.jpg', 'jpg', '320907', '1422772584');
INSERT INTO `dux_file` VALUES ('89', '/Uploads/2015-02-01/54cdc978b3aff.jpg', '/Uploads/2015-02-01/54cdc978b3aff.jpg', 'H160电机框架包装3.jpg', 'jpg', '345966', '1422772600');
INSERT INTO `dux_file` VALUES ('90', '/Uploads/2015-02-01/54cdc987bf21a.jpg', '/Uploads/2015-02-01/54cdc987bf21a.jpg', 'H200电机框架包装1.jpg', 'jpg', '428422', '1422772615');
INSERT INTO `dux_file` VALUES ('91', '/Uploads/2015-02-01/54cdc9a335cd6.jpg', '/Uploads/2015-02-01/54cdc9a335cd6.jpg', 'H200电机框架包装2.jpg', 'jpg', '351965', '1422772643');
INSERT INTO `dux_file` VALUES ('92', '/Uploads/2015-02-01/54cdc9b176a6f.jpg', '/Uploads/2015-02-01/54cdc9b176a6f.jpg', 'H200电机框架包装3.jpg', 'jpg', '390995', '1422772657');
INSERT INTO `dux_file` VALUES ('93', '/Uploads/2015-02-01/54cdc9eba83e4.jpg', '/Uploads/2015-02-01/54cdc9eba83e4.jpg', '玻璃框架包装2.jpg', 'jpg', '409386', '1422772715');
INSERT INTO `dux_file` VALUES ('94', '/Uploads/2015-02-01/54cdc9f935cd6.jpg', '/Uploads/2015-02-01/54cdc9f935cd6.jpg', '玻璃框架包装1.jpg', 'jpg', '305091', '1422772729');
INSERT INTO `dux_file` VALUES ('95', '/Uploads/2015-02-01/54cdca1fe176b.jpg', '/Uploads/2015-02-01/54cdca1fe176b.jpg', '玻璃框架包装3.jpg', 'jpg', '348040', '1422772767');
INSERT INTO `dux_file` VALUES ('96', '/Uploads/2015-02-01/54cdca3385e93.jpg', '/Uploads/2015-02-01/54cdca3385e93.jpg', '玻璃框架包装4.jpg', 'jpg', '414038', '1422772787');
INSERT INTO `dux_file` VALUES ('97', '/Uploads/2015-02-01/54cdca4c1eea0.jpg', '/Uploads/2015-02-01/54cdca4c1eea0.jpg', '框架包装5.jpg', 'jpg', '293093', '1422772812');
INSERT INTO `dux_file` VALUES ('98', '/Uploads/2015-02-01/54cdca60b7808.jpg', '/Uploads/2015-02-01/54cdca60b7808.jpg', '框架包装1.jpg', 'jpg', '324111', '1422772832');
INSERT INTO `dux_file` VALUES ('99', '/Uploads/2015-02-01/54cdca7400658.jpg', '/Uploads/2015-02-01/54cdca7400658.jpg', '框架包装4.jpg', 'jpg', '269045', '1422772852');
INSERT INTO `dux_file` VALUES ('100', '/Uploads/2015-02-01/54cdcaa876a6f.jpg', '/Uploads/2015-02-01/54cdcaa876a6f.jpg', '摩托车框架包装1.jpg', 'jpg', '288162', '1422772904');
INSERT INTO `dux_file` VALUES ('101', '/Uploads/2015-02-01/54cdcabdac0ed.jpg', '/Uploads/2015-02-01/54cdcabdac0ed.jpg', '框架包装3.jpg', 'jpg', '302345', '1422772925');
INSERT INTO `dux_file` VALUES ('102', '/Uploads/2015-02-01/54cdcacdb3aff.jpg', '/Uploads/2015-02-01/54cdcacdb3aff.jpg', '摩托车框架包装.jpg', 'jpg', '237612', '1422772941');
INSERT INTO `dux_file` VALUES ('103', '/Uploads/2015-02-01/54cdcc095fc39.jpg', '/Uploads/2015-02-01/54cdcc095fc39.jpg', '圆纸管滚轴.jpg', 'jpg', '358855', '1422773257');
INSERT INTO `dux_file` VALUES ('104', '/Uploads/2015-02-01/54cdcc471748e.jpg', '/Uploads/2015-02-01/54cdcc471748e.jpg', '包装盒5.jpg', 'jpg', '243624', '1422773319');
INSERT INTO `dux_file` VALUES ('105', '/Uploads/2015-02-01/54cdcc5c268b2.jpg', '/Uploads/2015-02-01/54cdcc5c268b2.jpg', '包装盒4.jpg', 'jpg', '208163', '1422773340');
INSERT INTO `dux_file` VALUES ('106', '/Uploads/2015-02-01/54cdcca45bf30.jpg', '/Uploads/2015-02-01/54cdcca45bf30.jpg', '包装盒7.jpg', 'jpg', '236072', '1422773412');
INSERT INTO `dux_file` VALUES ('107', '/Uploads/2015-02-01/54cdccbc915ae.jpg', '/Uploads/2015-02-01/54cdccbc915ae.jpg', '包装盒6.jpg', 'jpg', '230235', '1422773436');
INSERT INTO `dux_file` VALUES ('108', '/Uploads/2015-02-01/54cdcce6b7808.jpg', '/Uploads/2015-02-01/54cdcce6b7808.jpg', '电机FT90轴包装2.jpg', 'jpg', '249331', '1422773478');
INSERT INTO `dux_file` VALUES ('109', '/Uploads/2015-02-01/54cdccf4d9d59.jpg', '/Uploads/2015-02-01/54cdccf4d9d59.jpg', '电机FT90轴包装1.jpg', 'jpg', '349181', '1422773492');
INSERT INTO `dux_file` VALUES ('110', '/Uploads/2015-02-01/54cdcd0ab7808.jpg', '/Uploads/2015-02-01/54cdcd0ab7808.jpg', 'LED灯管包装.jpg', 'jpg', '207401', '1422773514');
INSERT INTO `dux_file` VALUES ('111', '/Uploads/2015-02-01/54cdcd1d63942.jpg', '/Uploads/2015-02-01/54cdcd1d63942.jpg', 'LED T5 T8灯管包装1.jpg', 'jpg', '261678', '1422773533');
INSERT INTO `dux_file` VALUES ('112', '/Uploads/2015-02-01/54cdcd38f0b8f.jpg', '/Uploads/2015-02-01/54cdcd38f0b8f.jpg', 'LED T5 T8灯管包装.jpg', 'jpg', '308393', '1422773560');
INSERT INTO `dux_file` VALUES ('113', '/Uploads/2015-02-01/54cdcd4e1748e.jpg', '/Uploads/2015-02-01/54cdcd4e1748e.jpg', '包装盒1.jpg', 'jpg', '193360', '1422773582');
INSERT INTO `dux_file` VALUES ('114', '/Uploads/2015-02-01/54cdcd612e2c4.jpg', '/Uploads/2015-02-01/54cdcd612e2c4.jpg', '包装盒2.jpg', 'jpg', '231262', '1422773601');
INSERT INTO `dux_file` VALUES ('115', '/Uploads/2015-02-01/54cdcd76afdf6.jpg', '/Uploads/2015-02-01/54cdcd76afdf6.jpg', '包装盒3.jpg', 'jpg', '253869', '1422773622');
INSERT INTO `dux_file` VALUES ('116', '/Uploads/2015-02-01/54cdcd86d2347.jpg', '/Uploads/2015-02-01/54cdcd86d2347.jpg', '轴承包装1.jpg', 'jpg', '273389', '1422773638');
INSERT INTO `dux_file` VALUES ('117', '/Uploads/2015-02-01/54cdcdf0952b7.jpg', '/Uploads/2015-02-01/54cdcdf0952b7.jpg', '香港钟表展展架.jpg', 'jpg', '302266', '1422773744');
INSERT INTO `dux_file` VALUES ('118', '/Uploads/2015-02-01/54cdce211b197.jpg', '/Uploads/2015-02-01/54cdce211b197.jpg', '陶瓷展展架.jpg', 'jpg', '551620', '1422773793');
INSERT INTO `dux_file` VALUES ('119', '/Uploads/2015-02-01/54cdce40399df.jpg', '/Uploads/2015-02-01/54cdce40399df.jpg', '国际珠宝展展架.jpg', 'jpg', '335860', '1422773824');
INSERT INTO `dux_file` VALUES ('120', '/Uploads/2015-02-01/54cdce6231fcd.jpg', '/Uploads/2015-02-01/54cdce6231fcd.jpg', '包装展展架.jpg', 'jpg', '447226', '1422773858');
INSERT INTO `dux_file` VALUES ('121', '/Uploads/2015-02-01/54cdce84e176b.jpg', '/Uploads/2015-02-01/54cdce84e176b.jpg', '变形展架1.jpg', 'jpg', '241007', '1422773892');
INSERT INTO `dux_file` VALUES ('122', '/Uploads/2015-02-01/54cdce9d639a8.jpg', '/Uploads/2015-02-01/54cdce9d639a8.jpg', '变形展架2.jpg', 'jpg', '222959', '1422773917');
INSERT INTO `dux_file` VALUES ('123', '/Uploads/2015-02-01/54cdcebe32033.jpg', '/Uploads/2015-02-01/54cdcebe32033.jpg', '标准展架.jpg', 'jpg', '180023', '1422773950');
INSERT INTO `dux_file` VALUES ('124', '/Uploads/2015-02-01/54cdcecc0bdd9.jpg', '/Uploads/2015-02-01/54cdcecc0bdd9.jpg', '标准展架1.jpg', 'jpg', '219612', '1422773964');
INSERT INTO `dux_file` VALUES ('125', '/Uploads/2015-02-01/54cdcef76f0c3.jpg', '/Uploads/2015-02-01/54cdcef76f0c3.jpg', '变形展架3.jpg', 'jpg', '231263', '1422774007');
INSERT INTO `dux_file` VALUES ('126', '/Uploads/2015-02-01/54cdcf0a89c02.jpg', '/Uploads/2015-02-01/54cdcf0a89c02.jpg', '变形展架4.jpg', 'jpg', '357248', '1422774026');
INSERT INTO `dux_file` VALUES ('127', '/Uploads/2015-02-01/54cdcf2ad60b6.jpg', '/Uploads/2015-02-01/54cdcf2ad60b6.jpg', '陈列柜2.jpg', 'jpg', '398305', '1422774058');
INSERT INTO `dux_file` VALUES ('128', '/Uploads/2015-02-01/54cdcf6b5bf96.jpg', '/Uploads/2015-02-01/54cdcf6b5bf96.jpg', '商超堆头架1.jpg', 'jpg', '325667', '1422774123');
INSERT INTO `dux_file` VALUES ('129', '/Uploads/2015-02-01/54cdcfa37e4e7.jpg', '/Uploads/2015-02-01/54cdcfa37e4e7.jpg', '方形纸管4.jpg', 'jpg', '345705', '1422774179');
INSERT INTO `dux_file` VALUES ('130', '/Uploads/2015-02-01/54cdd0851b1fd.jpg', '/Uploads/2015-02-01/54cdd0851b1fd.jpg', '商超堆头1.jpg', 'jpg', '305750', '1422774405');
INSERT INTO `dux_file` VALUES ('131', '/Uploads/2015-02-01/54cdd09ee54da.jpg', '/Uploads/2015-02-01/54cdd09ee54da.jpg', '商超堆头——侧面.jpg', 'jpg', '325835', '1422774430');
INSERT INTO `dux_file` VALUES ('132', '/Uploads/2015-02-01/54cdd0b448e69.jpg', '/Uploads/2015-02-01/54cdd0b448e69.jpg', '商超堆头——内部结构.jpg', 'jpg', '316857', '1422774452');
INSERT INTO `dux_file` VALUES ('133', '/Uploads/2015-02-01/54cdd0cb0fae2.jpg', '/Uploads/2015-02-01/54cdd0cb0fae2.jpg', '商超堆头——正面.jpg', 'jpg', '300618', '1422774475');
INSERT INTO `dux_file` VALUES ('134', '/Uploads/2015-02-01/54cdd0e52e32a.jpg', '/Uploads/2015-02-01/54cdd0e52e32a.jpg', '堆头架.jpg', 'jpg', '279678', '1422774501');
INSERT INTO `dux_file` VALUES ('135', '/Uploads/2015-02-01/54cdd112137eb.jpg', '/Uploads/2015-02-01/54cdd112137eb.jpg', '置物架.jpg', 'jpg', '383049', '1422774546');
INSERT INTO `dux_file` VALUES ('136', '/Uploads/2015-02-01/54cdd12c89c02.jpg', '/Uploads/2015-02-01/54cdd12c89c02.jpg', '陈列柜4.jpg', 'jpg', '335139', '1422774572');
INSERT INTO `dux_file` VALUES ('137', '/Uploads/2015-02-01/54cdd14499026.jpg', '/Uploads/2015-02-01/54cdd14499026.jpg', '陈列柜3.jpg', 'jpg', '161126', '1422774596');
INSERT INTO `dux_file` VALUES ('138', '/Uploads/2015-02-01/54cdd15a4145c.jpg', '/Uploads/2015-02-01/54cdd15a4145c.jpg', '多层置物架.jpg', 'jpg', '161442', '1422774618');
INSERT INTO `dux_file` VALUES ('139', '/Uploads/2015-02-01/54cdd187953de.jpg', '/Uploads/2015-02-01/54cdd187953de.jpg', '创意置物架.jpg', 'jpg', '279798', '1422774663');
INSERT INTO `dux_file` VALUES ('140', '/Uploads/2015-02-01/54cdd1b9ddbfb.jpg', '/Uploads/2015-02-01/54cdd1b9ddbfb.jpg', '陈列柜1.jpg', 'jpg', '178924', '1422774713');
INSERT INTO `dux_file` VALUES ('141', '/Uploads/2015-02-01/54cdd1db22da9.jpg', '/Uploads/2015-02-01/54cdd1db22da9.jpg', '展架3.jpg', 'jpg', '266734', '1422774747');
INSERT INTO `dux_file` VALUES ('142', '/Uploads/2015-02-01/54cdd1f5d9f59.jpg', '/Uploads/2015-02-01/54cdd1f5d9f59.jpg', '展架2.jpg', 'jpg', '260597', '1422774773');
INSERT INTO `dux_file` VALUES ('143', '/Uploads/2015-02-01/54cdd211a85e4.jpg', '/Uploads/2015-02-01/54cdd211a85e4.jpg', '展架1.jpg', 'jpg', '148549', '1422774801');
INSERT INTO `dux_file` VALUES ('144', '/Uploads/2015-02-01/54cdd22fe93e3.jpg', '/Uploads/2015-02-01/54cdd22fe93e3.jpg', '创意展架——第十届文博会2.jpg', 'jpg', '406154', '1422774831');
INSERT INTO `dux_file` VALUES ('145', '/Uploads/2015-02-01/54cdd24d678b1.jpg', '/Uploads/2015-02-01/54cdd24d678b1.jpg', '创意展架——第十届文博会1.jpg', 'jpg', '410770', '1422774861');
INSERT INTO `dux_file` VALUES ('146', '/Uploads/2015-02-01/54cdd26239c7d.jpg', '/Uploads/2015-02-01/54cdd26239c7d.jpg', '创意展架——第十届文博会4.jpg', 'jpg', '257473', '1422774882');
INSERT INTO `dux_file` VALUES ('147', '/Uploads/2015-02-01/54cdd28fe944a.jpg', '/Uploads/2015-02-01/54cdd28fe944a.jpg', '创意展架——第十届文博会5.jpg', 'jpg', '492862', '1422774927');
INSERT INTO `dux_file` VALUES ('148', '/Uploads/2015-02-01/54cdd308ed220.jpg', '/Uploads/2015-02-01/54cdd308ed220.jpg', '酒店装修3.jpg', 'jpg', '294847', '1422775048');
INSERT INTO `dux_file` VALUES ('149', '/Uploads/2015-02-01/54cdd36d91948.jpg', '/Uploads/2015-02-01/54cdd36d91948.jpg', '酒店装修3.jpg', 'jpg', '294847', '1422775149');
INSERT INTO `dux_file` VALUES ('150', '/Uploads/2015-02-01/54cdd37dbb8ab.jpg', '/Uploads/2015-02-01/54cdd37dbb8ab.jpg', '酒店装修2.jpg', 'jpg', '269563', '1422775165');
INSERT INTO `dux_file` VALUES ('151', '/Uploads/2015-02-01/54cdd38d1f23a.jpg', '/Uploads/2015-02-01/54cdd38d1f23a.jpg', '酒店装修1.jpg', 'jpg', '332737', '1422775181');
INSERT INTO `dux_file` VALUES ('152', '/Uploads/2015-02-01/54cdd3a0009f2.jpg', '/Uploads/2015-02-01/54cdd3a0009f2.jpg', '特装展1.jpg', 'jpg', '337507', '1422775200');
INSERT INTO `dux_file` VALUES ('153', '/Uploads/2015-02-01/54cdd4897ab12.jpg', '/Uploads/2015-02-01/54cdd4897ab12.jpg', '便携方凳1.jpg', 'jpg', '336981', '1422775433');
INSERT INTO `dux_file` VALUES ('154', '/Uploads/2015-02-01/54cdd4b7d63ea.jpg', '/Uploads/2015-02-01/54cdd4b7d63ea.jpg', '便携方凳2.jpg', 'jpg', '312937', '1422775479');
INSERT INTO `dux_file` VALUES ('155', '/Uploads/2015-02-01/54cdd4c76b6ee.jpg', '/Uploads/2015-02-01/54cdd4c76b6ee.jpg', '便携方凳3.jpg', 'jpg', '299529', '1422775495');
INSERT INTO `dux_file` VALUES ('156', '/Uploads/2015-02-01/54cdd4d9bb8ab.jpg', '/Uploads/2015-02-01/54cdd4d9bb8ab.jpg', '桌子1.jpg', 'jpg', '192682', '1422775513');
INSERT INTO `dux_file` VALUES ('157', '/Uploads/2015-02-01/54cdd583ac487.jpg', '/Uploads/2015-02-01/54cdd583ac487.jpg', '衣柜龙骨架1.jpg', 'jpg', '346622', '1422775683');
INSERT INTO `dux_file` VALUES ('158', '/Uploads/2015-02-01/54cdd59a63cdc.jpg', '/Uploads/2015-02-01/54cdd59a63cdc.jpg', '衣柜龙骨架2.jpg', 'jpg', '366528', '1422775706');
INSERT INTO `dux_file` VALUES ('159', '/Uploads/2015-02-01/54cdd5b626c4c.jpg', '/Uploads/2015-02-01/54cdd5b626c4c.jpg', '家居1.jpg', 'jpg', '386150', '1422775734');
INSERT INTO `dux_file` VALUES ('160', '/Uploads/2015-02-01/54cdd5d95c2ca.jpg', '/Uploads/2015-02-01/54cdd5d95c2ca.jpg', '衣柜.jpg', 'jpg', '402962', '1422775769');
INSERT INTO `dux_file` VALUES ('161', '/Uploads/2015-02-01/54cdd613b0190.jpg', '/Uploads/2015-02-01/54cdd613b0190.jpg', '桌子.jpg', 'jpg', '365467', '1422775827');
INSERT INTO `dux_file` VALUES ('162', '/Uploads/2015-02-01/54cdd633ed220.jpg', '/Uploads/2015-02-01/54cdd633ed220.jpg', '小柜1.jpg', 'jpg', '304368', '1422775859');
INSERT INTO `dux_file` VALUES ('163', '/Uploads/2015-02-01/54cdd666da0f3.jpg', '/Uploads/2015-02-01/54cdd666da0f3.jpg', '儿童柜子1.jpg', 'jpg', '277314', '1422775910');
INSERT INTO `dux_file` VALUES ('164', '/Uploads/2015-02-01/54cdd67c63cdc.jpg', '/Uploads/2015-02-01/54cdd67c63cdc.jpg', '儿童柜子.jpg', 'jpg', '320903', '1422775932');
INSERT INTO `dux_file` VALUES ('165', '/Uploads/2015-02-01/54cdd6d1dddfc.jpg', '/Uploads/2015-02-01/54cdd6d1dddfc.jpg', '魔方组合柜3.jpg', 'jpg', '194179', '1422776017');
INSERT INTO `dux_file` VALUES ('166', '/Uploads/2015-02-01/54cdd70339d79.jpg', '/Uploads/2015-02-01/54cdd70339d79.jpg', '魔方组合柜2.jpg', 'jpg', '230345', '1422776067');
INSERT INTO `dux_file` VALUES ('167', '/Uploads/2015-02-01/54cdd7149935a.jpg', '/Uploads/2015-02-01/54cdd7149935a.jpg', '魔方组合柜1.jpg', 'jpg', '245434', '1422776084');
INSERT INTO `dux_file` VALUES ('168', '/Uploads/2015-02-01/54cdd730da0f3.jpg', '/Uploads/2015-02-01/54cdd730da0f3.jpg', '古典桌子、置物架.jpg', 'jpg', '161917', '1422776112');
INSERT INTO `dux_file` VALUES ('169', '/Uploads/2015-02-01/54cdd75650baf.jpg', '/Uploads/2015-02-01/54cdd75650baf.jpg', '创意沙发.jpg', 'jpg', '213842', '1422776150');
INSERT INTO `dux_file` VALUES ('170', '/Uploads/2015-02-01/54cdd7670fe16.jpg', '/Uploads/2015-02-01/54cdd7670fe16.jpg', '创意茶几.jpg', 'jpg', '198596', '1422776167');
INSERT INTO `dux_file` VALUES ('171', '/Uploads/2015-02-01/54cdd77dcaccf.jpg', '/Uploads/2015-02-01/54cdd77dcaccf.jpg', '创意大床.jpg', 'jpg', '225540', '1422776189');
INSERT INTO `dux_file` VALUES ('172', '/Uploads/2015-02-01/54cdd790ce9d8.jpg', '/Uploads/2015-02-01/54cdd790ce9d8.jpg', '古典大床.jpg', 'jpg', '292594', '1422776208');
INSERT INTO `dux_file` VALUES ('173', '/Uploads/2015-02-01/54cdd7b236070.jpg', '/Uploads/2015-02-01/54cdd7b236070.jpg', '方凳1.jpg', 'jpg', '287323', '1422776242');
INSERT INTO `dux_file` VALUES ('174', '/Uploads/2015-02-01/54cdd7c6a0d6c.jpg', '/Uploads/2015-02-01/54cdd7c6a0d6c.jpg', '方凳2.jpg', 'jpg', '265022', '1422776262');
INSERT INTO `dux_file` VALUES ('175', '/Uploads/2015-02-01/54cdd7dbed220.jpg', '/Uploads/2015-02-01/54cdd7dbed220.jpg', '古典沙发茶几组合.jpg', 'jpg', '384190', '1422776283');
INSERT INTO `dux_file` VALUES ('176', '/Uploads/2015-02-01/54cdd84f91948.jpg', '/Uploads/2015-02-01/54cdd84f91948.jpg', '临时安置隔断2.jpg', 'jpg', '287126', '1422776399');
INSERT INTO `dux_file` VALUES ('177', '/Uploads/2015-02-01/54cdd8636f3f7.jpg', '/Uploads/2015-02-01/54cdd8636f3f7.jpg', '临时安置隔断1.jpg', 'jpg', '226077', '1422776419');
INSERT INTO `dux_file` VALUES ('178', '/Uploads/2015-02-01/54cdd8a5e580e.jpg', '/Uploads/2015-02-01/54cdd8a5e580e.jpg', '房舍2.jpg', 'jpg', '243862', '1422776485');
INSERT INTO `dux_file` VALUES ('179', '/Uploads/2015-02-01/54cdd8d40fe16.jpg', '/Uploads/2015-02-01/54cdd8d40fe16.jpg', '房舍1.jpg', 'jpg', '319308', '1422776532');
INSERT INTO `dux_file` VALUES ('180', '/Uploads/2015-02-01/54cddc5408404.jpg', '/Uploads/2015-02-01/54cddc5408404.jpg', '亭子2.jpg', 'jpg', '395131', '1422777428');
INSERT INTO `dux_file` VALUES ('181', '/Uploads/2015-02-01/54cddc6ada0f3.jpg', '/Uploads/2015-02-01/54cddc6ada0f3.jpg', '亭子1.jpg', 'jpg', '321149', '1422777450');
INSERT INTO `dux_file` VALUES ('182', '/Uploads/2015-02-01/54cde569a877e.jpg', '/Uploads/2015-02-01/54cde569a877e.jpg', '组合柜3.jpg', 'jpg', '207707', '1422779753');
INSERT INTO `dux_file` VALUES ('183', '/Uploads/2015-02-01/54cde57b50baf.jpg', '/Uploads/2015-02-01/54cde57b50baf.jpg', '组合柜2.jpg', 'jpg', '164540', '1422779771');
INSERT INTO `dux_file` VALUES ('184', '/Uploads/2015-02-01/54cde58b6f3f7.jpg', '/Uploads/2015-02-01/54cde58b6f3f7.jpg', '组合柜1.jpg', 'jpg', '224173', '1422779787');
INSERT INTO `dux_file` VALUES ('185', '/Uploads/2015-02-01/54cde5b017828.jpg', '/Uploads/2015-02-01/54cde5b017828.jpg', '组合柜.jpg', 'jpg', '217942', '1422779824');
INSERT INTO `dux_file` VALUES ('186', '/Uploads/2015-02-01/54cde5d4b7ba2.jpg', '/Uploads/2015-02-01/54cde5d4b7ba2.jpg', '折叠架2.jpg', 'jpg', '184448', '1422779860');
INSERT INTO `dux_file` VALUES ('187', '/Uploads/2015-02-01/54cde5ec0fe16.jpg', '/Uploads/2015-02-01/54cde5ec0fe16.jpg', '折叠架1.jpg', 'jpg', '255429', '1422779884');
INSERT INTO `dux_file` VALUES ('188', '/Uploads/2015-02-01/54cde5fbb0190.jpg', '/Uploads/2015-02-01/54cde5fbb0190.jpg', '折叠架.jpg', 'jpg', '226464', '1422779899');
INSERT INTO `dux_file` VALUES ('189', '/Uploads/2015-02-01/54cde7e8a877e.jpg', '/Uploads/2015-02-01/54cde7e8a877e.jpg', '详情页——1.jpg', 'jpg', '1581795', '1422780392');
INSERT INTO `dux_file` VALUES ('190', '/Uploads/2015-02-01/54cde8056f3f7.jpg', '/Uploads/2015-02-01/54cde8056f3f7.jpg', '详情页——托盘.jpg', 'jpg', '2104845', '1422780421');
INSERT INTO `dux_file` VALUES ('191', '/Uploads/2015-02-01/54cde8201b531.jpg', '/Uploads/2015-02-01/54cde8201b531.jpg', '详情页——包装箱.jpg', 'jpg', '2855229', '1422780448');
INSERT INTO `dux_file` VALUES ('192', '/Uploads/2015-02-01/54cde83950baf.jpg', '/Uploads/2015-02-01/54cde83950baf.jpg', '详情页——框架包装.jpg', 'jpg', '2813137', '1422780473');
INSERT INTO `dux_file` VALUES ('193', '/Uploads/2015-02-01/54cde8594178b.jpg', '/Uploads/2015-02-01/54cde8594178b.jpg', '详情页——内置外包装.jpg', 'jpg', '3719743', '1422780505');
INSERT INTO `dux_file` VALUES ('194', '/Uploads/2015-02-01/54cde876b0190.jpg', '/Uploads/2015-02-01/54cde876b0190.jpg', '详情页——展架、堆头架.jpg', 'jpg', '4563778', '1422780534');
INSERT INTO `dux_file` VALUES ('195', '/Uploads/2015-02-01/54cde89263cdc.jpg', '/Uploads/2015-02-01/54cde89263cdc.jpg', '详情页——商装、家装.jpg', 'jpg', '4356748', '1422780562');
INSERT INTO `dux_file` VALUES ('196', '/Uploads/2015-02-01/54cde8b6f0f29.jpg', '/Uploads/2015-02-01/54cde8b6f0f29.jpg', '详情页——家居办公.jpg', 'jpg', '4209029', '1422780598');
INSERT INTO `dux_file` VALUES ('197', '/Uploads/2015-02-01/54cde8df08404.jpg', '/Uploads/2015-02-01/54cde8df08404.jpg', '详情页——房屋临时安置.jpg', 'jpg', '4723200', '1422780639');
INSERT INTO `dux_file` VALUES ('198', '/Uploads/2015-02-01/54cde91e5ffd3.jpg', '/Uploads/2015-02-01/54cde91e5ffd3.jpg', '详情页——概念产品.jpg', 'jpg', '3322397', '1422780702');
INSERT INTO `dux_file` VALUES ('199', '/Uploads/2015-02-01/54cdefc61f2a0.jpg', '/Uploads/2015-02-01/54cdefc61f2a0.jpg', '形象墙+前台1.jpg', 'jpg', '241474', '1422782406');
INSERT INTO `dux_file` VALUES ('200', '/Uploads/2015-02-01/54cdf020454fa.jpg', '/Uploads/2015-02-01/54cdf020454fa.jpg', '形象墙+前台.jpg', 'jpg', '269649', '1422782496');
INSERT INTO `dux_file` VALUES ('201', '/Uploads/2015-02-01/54cdf042e1b6b.jpg', '/Uploads/2015-02-01/54cdf042e1b6b.jpg', '镂空隔断（灯光效果）.jpg', 'jpg', '226757', '1422782530');
INSERT INTO `dux_file` VALUES ('202', '/Uploads/2015-02-01/54cdf0765491e.jpg', '/Uploads/2015-02-01/54cdf0765491e.jpg', '镂空隔断.jpg', 'jpg', '198035', '1422782582');
INSERT INTO `dux_file` VALUES ('203', '/Uploads/2015-02-01/54cdf08fa87e4.jpg', '/Uploads/2015-02-01/54cdf08fa87e4.jpg', '隔断+储物架（箱）3.jpg', 'jpg', '214656', '1422782607');
INSERT INTO `dux_file` VALUES ('204', '/Uploads/2015-02-01/54cdf0c304761.jpg', '/Uploads/2015-02-01/54cdf0c304761.jpg', '隔断+储物架（箱）2.jpg', 'jpg', '238723', '1422782659');
INSERT INTO `dux_file` VALUES ('205', '/Uploads/2015-02-01/54cdf0d65c330.jpg', '/Uploads/2015-02-01/54cdf0d65c330.jpg', '隔断+储物架（箱）1.jpg', 'jpg', '256410', '1422782678');
INSERT INTO `dux_file` VALUES ('206', '/Uploads/2015-02-01/54cdf0f067a4b.jpg', '/Uploads/2015-02-01/54cdf0f067a4b.jpg', '隔断+储物架（箱）.jpg', 'jpg', '221403', '1422782704');
INSERT INTO `dux_file` VALUES ('207', '/Uploads/2015-02-01/54cdf8d96bb54.jpg', '/Uploads/2015-02-01/54cdf8d96bb54.jpg', '四面进叉拖托盘3.jpg', 'jpg', '245281', '1422784729');
INSERT INTO `dux_file` VALUES ('208', '/Uploads/2015-02-01/54cdf8fc04b61.jpg', '/Uploads/2015-02-01/54cdf8fc04b61.jpg', '四面进叉拖托盘2.jpg', 'jpg', '241278', '1422784764');
INSERT INTO `dux_file` VALUES ('209', '/Uploads/2015-02-01/54cdf90c8e0a5.jpg', '/Uploads/2015-02-01/54cdf90c8e0a5.jpg', '四面进叉拖托盘1.jpg', 'jpg', '220158', '1422784780');
INSERT INTO `dux_file` VALUES ('210', '/Uploads/2015-02-01/54cdf918233a9.jpg', '/Uploads/2015-02-01/54cdf918233a9.jpg', '四面进叉拖托盘.jpg', 'jpg', '229368', '1422784792');
INSERT INTO `dux_file` VALUES ('211', '/Uploads/2015-02-02/54cefbe3382d6.jpg', '/Uploads/2015-02-02/54cefbe3382d6.jpg', '包装箱4.jpg', 'jpg', '182262', '1422851043');
INSERT INTO `dux_file` VALUES ('212', '/Uploads/2015-02-02/54cefc332cbbb.jpg', '/Uploads/2015-02-02/54cefc332cbbb.jpg', '包装箱3.jpg', 'jpg', '208028', '1422851123');
INSERT INTO `dux_file` VALUES ('213', '/Uploads/2015-02-02/54cefc784b403.jpg', '/Uploads/2015-02-02/54cefc784b403.jpg', '包装箱14.jpg', 'jpg', '169935', '1422851192');
INSERT INTO `dux_file` VALUES ('214', '/Uploads/2015-02-02/54cefcac308c4.jpg', '/Uploads/2015-02-02/54cefcac308c4.jpg', '包装箱5.jpg', 'jpg', '208696', '1422851244');
INSERT INTO `dux_file` VALUES ('215', '/Uploads/2015-02-02/54cefcd093bae.jpg', '/Uploads/2015-02-02/54cefcd093bae.jpg', '包装箱6.jpg', 'jpg', '297431', '1422851280');
INSERT INTO `dux_file` VALUES ('216', '/Uploads/2015-02-02/54cefceb62239.jpg', '/Uploads/2015-02-02/54cefceb62239.jpg', '包装箱——河北激光研究所1.jpg', 'jpg', '317170', '1422851307');
INSERT INTO `dux_file` VALUES ('217', '/Uploads/2015-02-02/54cefe146d954.jpg', '/Uploads/2015-02-02/54cefe146d954.jpg', '包装箱——河北激光研究所4.jpg', 'jpg', '270460', '1422851604');
INSERT INTO `dux_file` VALUES ('218', '/Uploads/2015-02-02/54cefeac0e3d9.jpg', '/Uploads/2015-02-02/54cefeac0e3d9.jpg', '临时安置隔断2.jpg', 'jpg', '287126', '1422851756');
INSERT INTO `dux_file` VALUES ('219', '/Uploads/2015-02-02/54cefeff52e7b.jpg', '/Uploads/2015-02-02/54cefeff52e7b.jpg', '临时安置隔断1.jpg', 'jpg', '226077', '1422851839');
INSERT INTO `dux_file` VALUES ('220', '/Uploads/2015-02-02/54ceff0ac9292.jpg', '/Uploads/2015-02-02/54ceff0ac9292.jpg', '房舍2.jpg', 'jpg', '243862', '1422851850');
INSERT INTO `dux_file` VALUES ('221', '/Uploads/2015-02-02/54ceff59eb7e3.jpg', '/Uploads/2015-02-02/54ceff59eb7e3.jpg', '房舍1.jpg', 'jpg', '319308', '1422851929');
INSERT INTO `dux_file` VALUES ('222', '/Uploads/2015-02-02/54ceff743092a.jpg', '/Uploads/2015-02-02/54ceff743092a.jpg', '亭子2.jpg', 'jpg', '395131', '1422851956');
INSERT INTO `dux_file` VALUES ('223', '/Uploads/2015-02-02/54ceffb5884f9.jpg', '/Uploads/2015-02-02/54ceffb5884f9.jpg', '亭子1.jpg', 'jpg', '321149', '1422852021');
INSERT INTO `dux_file` VALUES ('224', '/Uploads/2015-02-02/54ceffd89b626.jpg', '/Uploads/2015-02-02/54ceffd89b626.jpg', '折叠架.jpg', 'jpg', '226464', '1422852056');
INSERT INTO `dux_file` VALUES ('225', '/Uploads/2015-02-02/54ceffebd86b6.jpg', '/Uploads/2015-02-02/54ceffebd86b6.jpg', '便携方凳1.jpg', 'jpg', '336981', '1422852075');
INSERT INTO `dux_file` VALUES ('226', '/Uploads/2015-02-02/54cf000302cbe.jpg', '/Uploads/2015-02-02/54cf000302cbe.jpg', '便携方凳1.jpg', 'jpg', '336981', '1422852099');
INSERT INTO `dux_file` VALUES ('227', '/Uploads/2015-02-02/54cf0017716c3.jpg', '/Uploads/2015-02-02/54cf0017716c3.jpg', '便携方凳2.jpg', 'jpg', '312937', '1422852119');
INSERT INTO `dux_file` VALUES ('228', '/Uploads/2015-02-02/54cf0035a6d41.jpg', '/Uploads/2015-02-02/54cf0035a6d41.jpg', '便携方凳3.jpg', 'jpg', '299529', '1422852149');
INSERT INTO `dux_file` VALUES ('229', '/Uploads/2015-02-02/54cf00553fd4e.jpg', '/Uploads/2015-02-02/54cf00553fd4e.jpg', '创意茶几.jpg', 'jpg', '198596', '1422852181');
INSERT INTO `dux_file` VALUES ('230', '/Uploads/2015-02-02/54cf007034633.jpg', '/Uploads/2015-02-02/54cf007034633.jpg', '创意大床.jpg', 'jpg', '225540', '1422852208');
INSERT INTO `dux_file` VALUES ('231', '/Uploads/2015-02-02/54cf0080b9e6e.jpg', '/Uploads/2015-02-02/54cf0080b9e6e.jpg', '创意沙发.jpg', 'jpg', '213842', '1422852224');
INSERT INTO `dux_file` VALUES ('232', '/Uploads/2015-02-02/54cf009a2520f.jpg', '/Uploads/2015-02-02/54cf009a2520f.jpg', '儿童柜子.jpg', 'jpg', '320903', '1422852250');
INSERT INTO `dux_file` VALUES ('233', '/Uploads/2015-02-02/54cf00a7884f9.jpg', '/Uploads/2015-02-02/54cf00a7884f9.jpg', '儿童柜子1.jpg', 'jpg', '277314', '1422852263');
INSERT INTO `dux_file` VALUES ('234', '/Uploads/2015-02-02/54cf00b9120e2.jpg', '/Uploads/2015-02-02/54cf00b9120e2.jpg', '方凳1.jpg', 'jpg', '287323', '1422852281');
INSERT INTO `dux_file` VALUES ('235', '/Uploads/2015-02-02/54cf00d03c045.jpg', '/Uploads/2015-02-02/54cf00d03c045.jpg', '方凳2.jpg', 'jpg', '265022', '1422852304');
INSERT INTO `dux_file` VALUES ('236', '/Uploads/2015-02-02/54cf00e6e7ada.jpg', '/Uploads/2015-02-02/54cf00e6e7ada.jpg', '古典大床.jpg', 'jpg', '292594', '1422852326');
INSERT INTO `dux_file` VALUES ('237', '/Uploads/2015-02-02/54cf00f8ae753.jpg', '/Uploads/2015-02-02/54cf00f8ae753.jpg', '古典沙发茶几组合.jpg', 'jpg', '384190', '1422852344');
INSERT INTO `dux_file` VALUES ('238', '/Uploads/2015-02-02/54cf011119af4.jpg', '/Uploads/2015-02-02/54cf011119af4.jpg', '古典桌子、置物架.jpg', 'jpg', '161917', '1422852369');
INSERT INTO `dux_file` VALUES ('239', '/Uploads/2015-02-02/54cf012d9f32f.jpg', '/Uploads/2015-02-02/54cf012d9f32f.jpg', '家居1.jpg', 'jpg', '386150', '1422852397');
INSERT INTO `dux_file` VALUES ('240', '/Uploads/2015-02-02/54cf0163e3dd1.jpg', '/Uploads/2015-02-02/54cf0163e3dd1.jpg', '魔方组合柜1.jpg', 'jpg', '245434', '1422852451');
INSERT INTO `dux_file` VALUES ('241', '/Uploads/2015-02-02/54cf017a753cc.jpg', '/Uploads/2015-02-02/54cf017a753cc.jpg', '魔方组合柜2.jpg', 'jpg', '230345', '1422852474');
INSERT INTO `dux_file` VALUES ('242', '/Uploads/2015-02-02/54cf018b9f32f.jpg', '/Uploads/2015-02-02/54cf018b9f32f.jpg', '魔方组合柜3.jpg', 'jpg', '194179', '1422852491');
INSERT INTO `dux_file` VALUES ('243', '/Uploads/2015-02-02/54cf0197b6165.jpg', '/Uploads/2015-02-02/54cf0197b6165.jpg', '小柜1.jpg', 'jpg', '304368', '1422852503');
INSERT INTO `dux_file` VALUES ('244', '/Uploads/2015-02-02/54cf01ab3092a.jpg', '/Uploads/2015-02-02/54cf01ab3092a.jpg', '桌子.jpg', 'jpg', '365467', '1422852523');
INSERT INTO `dux_file` VALUES ('245', '/Uploads/2015-02-02/54cf01d13c045.jpg', '/Uploads/2015-02-02/54cf01d13c045.jpg', '桌子1.jpg', 'jpg', '192682', '1422852561');
INSERT INTO `dux_file` VALUES ('246', '/Uploads/2015-02-02/54cf01e756b84.jpg', '/Uploads/2015-02-02/54cf01e756b84.jpg', 'H160电机框架包装.jpg', 'jpg', '329501', '1422852583');
INSERT INTO `dux_file` VALUES ('247', '/Uploads/2015-02-02/54cf02108c269.jpg', '/Uploads/2015-02-02/54cf02108c269.jpg', 'H160电机框架包装2.jpg', 'jpg', '320907', '1422852624');
INSERT INTO `dux_file` VALUES ('248', '/Uploads/2015-02-02/54cf02250a737.jpg', '/Uploads/2015-02-02/54cf02250a737.jpg', 'H160电机框架包装3.jpg', 'jpg', '345966', '1422852645');
INSERT INTO `dux_file` VALUES ('249', '/Uploads/2015-02-02/54cf023906a2e.jpg', '/Uploads/2015-02-02/54cf023906a2e.jpg', 'H200电机框架包装2.jpg', 'jpg', '351965', '1422852665');
INSERT INTO `dux_file` VALUES ('250', '/Uploads/2015-02-02/54cf024952ee2.jpg', '/Uploads/2015-02-02/54cf024952ee2.jpg', 'H200电机框架包装3.jpg', 'jpg', '390995', '1422852681');
INSERT INTO `dux_file` VALUES ('251', '/Uploads/2015-02-02/54cf0260477c7.jpg', '/Uploads/2015-02-02/54cf0260477c7.jpg', '玻璃框架包装1.jpg', 'jpg', '305091', '1422852704');
INSERT INTO `dux_file` VALUES ('252', '/Uploads/2015-02-02/54cf027880bae.jpg', '/Uploads/2015-02-02/54cf027880bae.jpg', '玻璃框架包装2.jpg', 'jpg', '409386', '1422852728');
INSERT INTO `dux_file` VALUES ('253', '/Uploads/2015-02-02/54cf0289c93c7.jpg', '/Uploads/2015-02-02/54cf0289c93c7.jpg', '玻璃框架包装4.jpg', 'jpg', '414038', '1422852745');
INSERT INTO `dux_file` VALUES ('254', '/Uploads/2015-02-02/54cf029e216a0.jpg', '/Uploads/2015-02-02/54cf029e216a0.jpg', '框架包装5.jpg', 'jpg', '293093', '1422852766');
INSERT INTO `dux_file` VALUES ('255', '/Uploads/2015-02-02/54cf0302c1a55.jpg', '/Uploads/2015-02-02/54cf0302c1a55.jpg', '框架包装4.jpg', 'jpg', '269045', '1422852866');
INSERT INTO `dux_file` VALUES ('256', '/Uploads/2015-02-02/54cf031080ce7.jpg', '/Uploads/2015-02-02/54cf031080ce7.jpg', '摩托车框架包装1.jpg', 'jpg', '288162', '1422852880');
INSERT INTO `dux_file` VALUES ('257', '/Uploads/2015-02-02/54cf032a5307b.jpg', '/Uploads/2015-02-02/54cf032a5307b.jpg', '摩托车框架包装.jpg', 'jpg', '237612', '1422852906');
INSERT INTO `dux_file` VALUES ('258', '/Uploads/2015-02-02/54cf0342f33f5.jpg', '/Uploads/2015-02-02/54cf0342f33f5.jpg', 'LED T5 T8灯管包装.jpg', 'jpg', '308393', '1422852930');
INSERT INTO `dux_file` VALUES ('259', '/Uploads/2015-02-02/54cf039e2ce3f.jpg', '/Uploads/2015-02-02/54cf039e2ce3f.jpg', 'LED T5 T8灯管包装1.jpg', 'jpg', '261678', '1422853022');
INSERT INTO `dux_file` VALUES ('260', '/Uploads/2015-02-02/54cf03c44b6cf.jpg', '/Uploads/2015-02-02/54cf03c44b6cf.jpg', 'LED灯管包装.jpg', 'jpg', '207401', '1422853060');
INSERT INTO `dux_file` VALUES ('261', '/Uploads/2015-02-02/54cf03e76dc20.jpg', '/Uploads/2015-02-02/54cf03e76dc20.jpg', '包装盒1.jpg', 'jpg', '193360', '1422853095');
INSERT INTO `dux_file` VALUES ('262', '/Uploads/2015-02-02/54cf03ffd891c.jpg', '/Uploads/2015-02-02/54cf03ffd891c.jpg', '包装盒2.jpg', 'jpg', '231262', '1422853119');
INSERT INTO `dux_file` VALUES ('263', '/Uploads/2015-02-02/54cf0409bdddd.jpg', '/Uploads/2015-02-02/54cf0409bdddd.jpg', '包装盒3.jpg', 'jpg', '253869', '1422853129');
INSERT INTO `dux_file` VALUES ('264', '/Uploads/2015-02-02/54cf0426b63cb.jpg', '/Uploads/2015-02-02/54cf0426b63cb.jpg', '包装盒4.jpg', 'jpg', '208163', '1422853158');
INSERT INTO `dux_file` VALUES ('265', '/Uploads/2015-02-02/54cf0434aacb0.jpg', '/Uploads/2015-02-02/54cf0434aacb0.jpg', '包装盒5.jpg', 'jpg', '243624', '1422853172');
INSERT INTO `dux_file` VALUES ('266', '/Uploads/2015-02-02/54cf04426620e.jpg', '/Uploads/2015-02-02/54cf04426620e.jpg', '包装盒6.jpg', 'jpg', '230235', '1422853186');
INSERT INTO `dux_file` VALUES ('267', '/Uploads/2015-02-02/54cf044fc1ae6.jpg', '/Uploads/2015-02-02/54cf044fc1ae6.jpg', '包装盒7.jpg', 'jpg', '236072', '1422853199');
INSERT INTO `dux_file` VALUES ('268', '/Uploads/2015-02-02/54cf0462ba0d4.jpg', '/Uploads/2015-02-02/54cf0462ba0d4.jpg', '电机FT90轴包装2.jpg', 'jpg', '249331', '1422853218');
INSERT INTO `dux_file` VALUES ('269', '/Uploads/2015-02-02/54cf048219d5a.jpg', '/Uploads/2015-02-02/54cf048219d5a.jpg', '电机FT90轴包装1.jpg', 'jpg', '349181', '1422853250');
INSERT INTO `dux_file` VALUES ('270', '/Uploads/2015-02-02/54cf0495d0f0a.jpg', '/Uploads/2015-02-02/54cf0495d0f0a.jpg', '圆纸管滚轴.jpg', 'jpg', '358855', '1422853269');
INSERT INTO `dux_file` VALUES ('271', '/Uploads/2015-02-02/54cf0a4b56dea.jpg', '/Uploads/2015-02-02/54cf0a4b56dea.jpg', '形象墙+前台1.jpg', 'jpg', '241474', '1422854731');
INSERT INTO `dux_file` VALUES ('272', '/Uploads/2015-02-02/54cf0a5875632.jpg', '/Uploads/2015-02-02/54cf0a5875632.jpg', '形象墙+前台.jpg', 'jpg', '269649', '1422854744');
INSERT INTO `dux_file` VALUES ('273', '/Uploads/2015-02-02/54cf0aaa8875f.jpg', '/Uploads/2015-02-02/54cf0aaa8875f.jpg', '特装展1.jpg', 'jpg', '337507', '1422854826');
INSERT INTO `dux_file` VALUES ('274', '/Uploads/2015-02-02/54cf0acb43cbd.jpg', '/Uploads/2015-02-02/54cf0acb43cbd.jpg', '镂空隔断（灯光效果）.jpg', 'jpg', '226757', '1422854859');
INSERT INTO `dux_file` VALUES ('275', '/Uploads/2015-02-02/54cf0ae1c1ae6.jpg', '/Uploads/2015-02-02/54cf0ae1c1ae6.jpg', '镂空隔断.jpg', 'jpg', '198035', '1422854881');
INSERT INTO `dux_file` VALUES ('276', '/Uploads/2015-02-02/54cf0aee2ce87.jpg', '/Uploads/2015-02-02/54cf0aee2ce87.jpg', '酒店装修3.jpg', 'jpg', '294847', '1422854894');
INSERT INTO `dux_file` VALUES ('277', '/Uploads/2015-02-02/54cf0b2fe032e.jpg', '/Uploads/2015-02-02/54cf0b2fe032e.jpg', '酒店装修2.jpg', 'jpg', '269563', '1422854959');
INSERT INTO `dux_file` VALUES ('278', '/Uploads/2015-02-02/54cf0b5dc1ae6.jpg', '/Uploads/2015-02-02/54cf0b5dc1ae6.jpg', '酒店装修1.jpg', 'jpg', '332737', '1422855005');
INSERT INTO `dux_file` VALUES ('279', '/Uploads/2015-02-02/54cf0b8669f17.jpg', '/Uploads/2015-02-02/54cf0b8669f17.jpg', '镂空隔断.jpg', 'jpg', '198035', '1422855046');
INSERT INTO `dux_file` VALUES ('280', '/Uploads/2015-02-02/54cf0bb38c468.jpg', '/Uploads/2015-02-02/54cf0bb38c468.jpg', '隔断+储物架（箱）3.jpg', 'jpg', '214656', '1422855091');
INSERT INTO `dux_file` VALUES ('281', '/Uploads/2015-02-02/54cf0bc2c94f8.jpg', '/Uploads/2015-02-02/54cf0bc2c94f8.jpg', '隔断+储物架（箱）2.jpg', 'jpg', '238723', '1422855106');
INSERT INTO `dux_file` VALUES ('282', '/Uploads/2015-02-02/54cf0bd0530e1.jpg', '/Uploads/2015-02-02/54cf0bd0530e1.jpg', '隔断+储物架（箱）1.jpg', 'jpg', '256410', '1422855120');
INSERT INTO `dux_file` VALUES ('283', '/Uploads/2015-02-02/54cf0bde90171.jpg', '/Uploads/2015-02-02/54cf0bde90171.jpg', '隔断+储物架（箱）.jpg', 'jpg', '221403', '1422855134');
INSERT INTO `dux_file` VALUES ('284', '/Uploads/2015-02-02/54cf0bfdae9b9.jpg', '/Uploads/2015-02-02/54cf0bfdae9b9.jpg', '超强型纸管托盘——河北电机1.jpg', 'jpg', '368559', '1422855165');
INSERT INTO `dux_file` VALUES ('285', '/Uploads/2015-02-02/54cf0c27aacb0.jpg', '/Uploads/2015-02-02/54cf0c27aacb0.jpg', '超强型纸管托盘——河北电机3.jpg', 'jpg', '380286', '1422855207');
INSERT INTO `dux_file` VALUES ('286', '/Uploads/2015-02-02/54cf0c40bdddd.jpg', '/Uploads/2015-02-02/54cf0c40bdddd.jpg', '超强型纸管托盘——河北电机5.jpg', 'jpg', '354252', '1422855232');
INSERT INTO `dux_file` VALUES ('287', '/Uploads/2015-02-02/54cf0c6f0a936.jpg', '/Uploads/2015-02-02/54cf0c6f0a936.jpg', '方形纸管蜂窝托盘——四面进叉1.jpg', 'jpg', '212293', '1422855279');
INSERT INTO `dux_file` VALUES ('288', '/Uploads/2015-02-02/54cf0c85c1ae6.jpg', '/Uploads/2015-02-02/54cf0c85c1ae6.jpg', '方形纸管蜂窝托盘——四面进叉2.jpg', 'jpg', '254063', '1422855301');
INSERT INTO `dux_file` VALUES ('289', '/Uploads/2015-02-02/54cf0c99c57ef.jpg', '/Uploads/2015-02-02/54cf0c99c57ef.jpg', '方形纸管托盘——两面进叉2.jpg', 'jpg', '330780', '1422855321');
INSERT INTO `dux_file` VALUES ('290', '/Uploads/2015-02-02/54cf0cb7e7d40.jpg', '/Uploads/2015-02-02/54cf0cb7e7d40.jpg', '方形纸管托盘——两面进叉1.jpg', 'jpg', '202933', '1422855351');
INSERT INTO `dux_file` VALUES ('291', '/Uploads/2015-02-02/54cf0cd1d891c.jpg', '/Uploads/2015-02-02/54cf0cd1d891c.jpg', '方形纸管托盘——四面进叉1.jpg', 'jpg', '263780', '1422855377');
INSERT INTO `dux_file` VALUES ('292', '/Uploads/2015-02-02/54cf0cebd891c.jpg', '/Uploads/2015-02-02/54cf0cebd891c.jpg', '四面进叉拖托盘.jpg', 'jpg', '229368', '1422855403');
INSERT INTO `dux_file` VALUES ('293', '/Uploads/2015-02-02/54cf0cff30b90.jpg', '/Uploads/2015-02-02/54cf0cff30b90.jpg', '四面进叉拖托盘1.jpg', 'jpg', '220158', '1422855423');
INSERT INTO `dux_file` VALUES ('294', '/Uploads/2015-02-02/54cf0d2aa6fa7.jpg', '/Uploads/2015-02-02/54cf0d2aa6fa7.jpg', '包装展展架.jpg', 'jpg', '447226', '1422855466');
INSERT INTO `dux_file` VALUES ('295', '/Uploads/2015-02-02/54cf0d47dc625.jpg', '/Uploads/2015-02-02/54cf0d47dc625.jpg', '变形展架1.jpg', 'jpg', '241007', '1422855495');
INSERT INTO `dux_file` VALUES ('296', '/Uploads/2015-02-02/54cf0d59e4037.jpg', '/Uploads/2015-02-02/54cf0d59e4037.jpg', '变形展架2.jpg', 'jpg', '222959', '1422855513');
INSERT INTO `dux_file` VALUES ('297', '/Uploads/2015-02-02/54cf0d6f62505.jpg', '/Uploads/2015-02-02/54cf0d6f62505.jpg', '变形展架3.jpg', 'jpg', '231263', '1422855535');
INSERT INTO `dux_file` VALUES ('298', '/Uploads/2015-02-02/54cf0d8116051.jpg', '/Uploads/2015-02-02/54cf0d8116051.jpg', '变形展架4.jpg', 'jpg', '357248', '1422855553');
INSERT INTO `dux_file` VALUES ('299', '/Uploads/2015-02-02/54cf0d9516051.jpg', '/Uploads/2015-02-02/54cf0d9516051.jpg', '标准展架.jpg', 'jpg', '180023', '1422855573');
INSERT INTO `dux_file` VALUES ('300', '/Uploads/2015-02-02/54cf0db706c2d.jpg', '/Uploads/2015-02-02/54cf0db706c2d.jpg', '标准展架1.jpg', 'jpg', '219612', '1422855607');
INSERT INTO `dux_file` VALUES ('301', '/Uploads/2015-02-02/54cf0dd29f595.jpg', '/Uploads/2015-02-02/54cf0dd29f595.jpg', '陈列柜2.jpg', 'jpg', '398305', '1422855634');
INSERT INTO `dux_file` VALUES ('302', '/Uploads/2015-02-02/54cf0de702f24.jpg', '/Uploads/2015-02-02/54cf0de702f24.jpg', '陈列柜3.jpg', 'jpg', '161126', '1422855655');
INSERT INTO `dux_file` VALUES ('303', '/Uploads/2015-02-02/54cf0dfbeba49.jpg', '/Uploads/2015-02-02/54cf0dfbeba49.jpg', '陈列柜4.jpg', 'jpg', '335139', '1422855675');
INSERT INTO `dux_file` VALUES ('304', '/Uploads/2015-02-02/54cf0e0f12348.jpg', '/Uploads/2015-02-02/54cf0e0f12348.jpg', '创意展架——第十届文博会1.jpg', 'jpg', '410770', '1422855695');
INSERT INTO `dux_file` VALUES ('305', '/Uploads/2015-02-02/54cf0e2f2176c.jpg', '/Uploads/2015-02-02/54cf0e2f2176c.jpg', '创意展架——第十届文博会2.jpg', 'jpg', '406154', '1422855727');
INSERT INTO `dux_file` VALUES ('306', '/Uploads/2015-02-02/54cf0e6bef752.jpg', '/Uploads/2015-02-02/54cf0e6bef752.jpg', '陈列柜4.jpg', 'jpg', '335139', '1422855787');
INSERT INTO `dux_file` VALUES ('307', '/Uploads/2015-02-02/54cf0e879f595.jpg', '/Uploads/2015-02-02/54cf0e879f595.jpg', '创意展架——第十届文博会3.jpg', 'jpg', '423585', '1422855815');
INSERT INTO `dux_file` VALUES ('308', '/Uploads/2015-02-02/54cf0e98b63cb.jpg', '/Uploads/2015-02-02/54cf0e98b63cb.jpg', '创意展架——第十届文博会4.jpg', 'jpg', '257473', '1422855832');
INSERT INTO `dux_file` VALUES ('309', '/Uploads/2015-02-02/54cf0ebda6fa7.jpg', '/Uploads/2015-02-02/54cf0ebda6fa7.jpg', '创意展架——第十届文博会5.jpg', 'jpg', '492862', '1422855869');
INSERT INTO `dux_file` VALUES ('310', '/Uploads/2015-02-02/54cf0ed6aacb0.jpg', '/Uploads/2015-02-02/54cf0ed6aacb0.jpg', '创意置物架.jpg', 'jpg', '279798', '1422855894');
INSERT INTO `dux_file` VALUES ('311', '/Uploads/2015-02-02/54cf0efe62505.jpg', '/Uploads/2015-02-02/54cf0efe62505.jpg', '堆头架.jpg', 'jpg', '279678', '1422855934');
INSERT INTO `dux_file` VALUES ('312', '/Uploads/2015-02-02/54cf0f1719d5a.jpg', '/Uploads/2015-02-02/54cf0f1719d5a.jpg', '多层置物架.jpg', 'jpg', '161442', '1422855959');
INSERT INTO `dux_file` VALUES ('313', '/Uploads/2015-02-02/54cf0f32cd201.jpg', '/Uploads/2015-02-02/54cf0f32cd201.jpg', '广交会现场展架搭建.jpg', 'jpg', '636021', '1422855986');
INSERT INTO `dux_file` VALUES ('314', '/Uploads/2015-02-02/54cf0f4c93e7a.jpg', '/Uploads/2015-02-02/54cf0f4c93e7a.jpg', '国际珠宝展展架.jpg', 'jpg', '335860', '1422856012');
INSERT INTO `dux_file` VALUES ('315', '/Uploads/2015-02-02/54cf0f6c8875f.jpg', '/Uploads/2015-02-02/54cf0f6c8875f.jpg', '商超堆头1.jpg', 'jpg', '305750', '1422856044');
INSERT INTO `dux_file` VALUES ('316', '/Uploads/2015-02-02/54cf0f9e479c6.jpg', '/Uploads/2015-02-02/54cf0f9e479c6.jpg', '商超堆头架1.jpg', 'jpg', '325667', '1422856094');
INSERT INTO `dux_file` VALUES ('317', '/Uploads/2015-02-02/54cf0faf3ffb4.jpg', '/Uploads/2015-02-02/54cf0faf3ffb4.jpg', '商超堆头架2.jpg', 'jpg', '438855', '1422856111');
INSERT INTO `dux_file` VALUES ('318', '/Uploads/2015-02-02/54cf0fc4385a2.jpg', '/Uploads/2015-02-02/54cf0fc4385a2.jpg', '商超堆头——内部结构.jpg', 'jpg', '316857', '1422856132');
INSERT INTO `dux_file` VALUES ('319', '/Uploads/2015-02-02/54cf0fd98875f.jpg', '/Uploads/2015-02-02/54cf0fd98875f.jpg', '商超堆头——侧面.jpg', 'jpg', '325835', '1422856153');
INSERT INTO `dux_file` VALUES ('320', '/Uploads/2015-02-02/54cf103f6dc20.jpg', '/Uploads/2015-02-02/54cf103f6dc20.jpg', '陶瓷展展架.jpg', 'jpg', '551620', '1422856255');
INSERT INTO `dux_file` VALUES ('321', '/Uploads/2015-02-02/54cf105490171.jpg', '/Uploads/2015-02-02/54cf105490171.jpg', '香港钟表展展架.jpg', 'jpg', '302266', '1422856276');
INSERT INTO `dux_file` VALUES ('322', '/Uploads/2015-02-02/54cf10771da63.jpg', '/Uploads/2015-02-02/54cf10771da63.jpg', '置物架.jpg', 'jpg', '383049', '1422856311');
INSERT INTO `dux_file` VALUES ('323', '/Uploads/2015-02-02/54cf19b669f17.jpg', '/Uploads/2015-02-02/54cf19b669f17.jpg', '方形纸管机专利证书.jpg', 'jpg', '44813', '1422858678');
INSERT INTO `dux_file` VALUES ('324', '/Uploads/2015-02-02/54cf1a402917e.jpg', '/Uploads/2015-02-02/54cf1a402917e.jpg', '新型方形纸管机专利证书.jpg', 'jpg', '45640', '1422858816');
INSERT INTO `dux_file` VALUES ('325', '/Uploads/2015-02-02/54cf1c6a530e1.jpg', '/Uploads/2015-02-02/54cf1c6a530e1.jpg', '方形纸管框架包装连接结构专利证书.jpg', 'jpg', '47068', '1422859370');
INSERT INTO `dux_file` VALUES ('326', '/Uploads/2015-02-02/54cf1ce030b90.jpg', '/Uploads/2015-02-02/54cf1ce030b90.jpg', '方形纸管连接件专利证书.jpg', 'jpg', '45924', '1422859488');
INSERT INTO `dux_file` VALUES ('327', '/Uploads/2015-02-02/54cf1d166dc20.jpg', '/Uploads/2015-02-02/54cf1d166dc20.jpg', '优质供应商证书.jpg', 'jpg', '68307', '1422859542');
INSERT INTO `dux_file` VALUES ('328', '/Uploads/2015-02-02/54cf1fb953148.jpg', '/Uploads/2015-02-02/54cf1fb953148.jpg', '海方团队.jpg', 'jpg', '403754', '1422860217');
INSERT INTO `dux_file` VALUES ('329', '/Uploads/2015-02-02/54cf2039aad17.jpg', '/Uploads/2015-02-02/54cf2039aad17.jpg', '海方团队.jpg', 'jpg', '403754', '1422860345');
INSERT INTO `dux_file` VALUES ('330', '/Uploads/2015-02-02/54cf20d0aea20.jpg', '/Uploads/2015-02-02/54cf20d0aea20.jpg', '海方架构.jpg', 'jpg', '210374', '1422860496');
INSERT INTO `dux_file` VALUES ('331', '/Uploads/2015-02-02/54cf210baea20.jpg', '/Uploads/2015-02-02/54cf210baea20.jpg', '海方架构.jpg', 'jpg', '210374', '1422860555');
INSERT INTO `dux_file` VALUES ('332', '/Uploads/2015-02-02/54cf21540e6a6.jpg', '/Uploads/2015-02-02/54cf21540e6a6.jpg', '海方架构.jpg', 'jpg', '210374', '1422860628');
INSERT INTO `dux_file` VALUES ('333', '/Uploads/2015-02-02/54cf48600381b.jpg', '/Uploads/2015-02-02/54cf48600381b.jpg', '文博会.jpg', 'jpg', '84882', '1422870624');
INSERT INTO `dux_file` VALUES ('334', '/Uploads/2015-02-02/54cf48a6be710.jpg', '/Uploads/2015-02-02/54cf48a6be710.jpg', '托盘最大压力.jpg', 'jpg', '77136', '1422870694');
INSERT INTO `dux_file` VALUES ('335', '/Uploads/2015-02-02/54cf48c689092.jpg', '/Uploads/2015-02-02/54cf48c689092.jpg', '角跌落.jpg', 'jpg', '81280', '1422870726');
INSERT INTO `dux_file` VALUES ('336', '/Uploads/2015-02-02/54cf48f3e0c61.jpg', '/Uploads/2015-02-02/54cf48f3e0c61.jpg', '方凳.jpg', 'jpg', '73808', '1422870771');
INSERT INTO `dux_file` VALUES ('337', '/Uploads/2015-02-02/54cf491dd183d.jpg', '/Uploads/2015-02-02/54cf491dd183d.jpg', '跌落.jpg', 'jpg', '100245', '1422870813');
INSERT INTO `dux_file` VALUES ('338', '/Uploads/2015-02-02/54cf493baf2ec.jpg', '/Uploads/2015-02-02/54cf493baf2ec.jpg', '推移.jpg', 'jpg', '87294', '1422870843');
INSERT INTO `dux_file` VALUES ('339', '/Uploads/2015-02-02/54cf4cdd9c1bf.jpg', '/Uploads/2015-02-02/54cf4cdd9c1bf.jpg', '淋水.jpg', 'jpg', '90351', '1422871773');
INSERT INTO `dux_file` VALUES ('340', '/Uploads/2015-02-02/54cf4d031a68d.jpg', '/Uploads/2015-02-02/54cf4d031a68d.jpg', '棱跌落.jpg', 'jpg', '84090', '1422871811');
INSERT INTO `dux_file` VALUES ('341', '/Uploads/2015-02-02/54cf4d1d12c7b.jpg', '/Uploads/2015-02-02/54cf4d1d12c7b.jpg', '撞击.jpg', 'jpg', '92308', '1422871837');
INSERT INTO `dux_file` VALUES ('342', '/Uploads/2015-02-02/54cf4d4138ed5.jpg', '/Uploads/2015-02-02/54cf4d4138ed5.jpg', '动载.jpg', 'jpg', '88465', '1422871873');
INSERT INTO `dux_file` VALUES ('343', '/Uploads/2015-02-02/54cf4d57ec37c.jpg', '/Uploads/2015-02-02/54cf4d57ec37c.jpg', '剪切.jpg', 'jpg', '69770', '1422871895');
INSERT INTO `dux_file` VALUES ('344', '/Uploads/2015-02-02/54cf696ccde68.jpg', '/Uploads/2015-02-02/54cf696ccde68.jpg', '海方架构.jpg', 'jpg', '210374', '1422879084');
INSERT INTO `dux_file` VALUES ('345', '/Uploads/2015-02-02/54cf6c1766f41.PDF', '/Uploads/2015-02-02/54cf6c1766f41.PDF', '2013年方管SGS报告.PDF', 'pdf', '389136', '1422879767');
INSERT INTO `dux_file` VALUES ('346', '/Uploads/2015-02-02/54cf6cc9318c3.jpg', '/Uploads/2015-02-02/54cf6cc9318c3.jpg', 'QQ图片20150202202710.jpg', 'jpg', '2213', '1422879945');
INSERT INTO `dux_file` VALUES ('347', '/Uploads/2015-02-02/54cf6ef96e953.pdf', '/Uploads/2015-02-02/54cf6ef96e953.pdf', 'TTS报告（WTP1565 海方 最大压力 动载 剪切 跌落  C 报告）.pdf', 'pdf', '2824170', '1422880505');
INSERT INTO `dux_file` VALUES ('348', '/Uploads/2015-02-03/54d03a5e3e8ab.jpg', '/Uploads/2015-02-03/54d03a5e3e8ab.jpg', '详情页——1_C.jpg', 'jpg', '209806', '1422932574');
INSERT INTO `dux_file` VALUES ('349', '/Uploads/2015-02-03/54d03a8a1c35a.jpg', '/Uploads/2015-02-03/54d03a8a1c35a.jpg', '详情页——托盘_C.jpg', 'jpg', '267702', '1422932618');
INSERT INTO `dux_file` VALUES ('350', '/Uploads/2015-02-03/54d03ab66c517.jpg', '/Uploads/2015-02-03/54d03ab66c517.jpg', '详情页——包装箱_C.jpg', 'jpg', '354339', '1422932662');
INSERT INTO `dux_file` VALUES ('351', '/Uploads/2015-02-03/54d03ad110c3f.jpg', '/Uploads/2015-02-03/54d03ad110c3f.jpg', '详情页——框架包装_C.jpg', 'jpg', '331460', '1422932689');
INSERT INTO `dux_file` VALUES ('352', '/Uploads/2015-02-03/54d03ae423d6c.jpg', '/Uploads/2015-02-03/54d03ae423d6c.jpg', '详情页——内置外包装_C.jpg', 'jpg', '365555', '1422932708');
INSERT INTO `dux_file` VALUES ('353', '/Uploads/2015-02-03/54d03af84dccf.jpg', '/Uploads/2015-02-03/54d03af84dccf.jpg', '详情页——展架、堆头架_C.jpg', 'jpg', '487928', '1422932728');
INSERT INTO `dux_file` VALUES ('354', '/Uploads/2015-02-03/54d03b107b93b.jpg', '/Uploads/2015-02-03/54d03b107b93b.jpg', '详情页——商装、家装_C.jpg', 'jpg', '804015', '1422932752');
INSERT INTO `dux_file` VALUES ('355', '/Uploads/2015-02-03/54d03b262f487.jpg', '/Uploads/2015-02-03/54d03b262f487.jpg', '详情页——家居办公_C.jpg', 'jpg', '685034', '1422932774');
INSERT INTO `dux_file` VALUES ('356', '/Uploads/2015-02-03/54d03b3e87056.jpg', '/Uploads/2015-02-03/54d03b3e87056.jpg', '详情页——房屋临时安置_C.jpg', 'jpg', '825439', '1422932798');
INSERT INTO `dux_file` VALUES ('357', '/Uploads/2015-02-03/54d03b528ea68.jpg', '/Uploads/2015-02-03/54d03b528ea68.jpg', '详情页——概念产品_C.jpg', 'jpg', '364988', '1422932818');
INSERT INTO `dux_file` VALUES ('358', '/Uploads/2015-02-03/54d03c5987056.jpg', '/Uploads/2015-02-03/54d03c5987056.jpg', '海方架构.jpg', 'jpg', '210374', '1422933081');
INSERT INTO `dux_file` VALUES ('359', '/Uploads/2015-02-03/54d03c7c49fc6.jpg', '/Uploads/2015-02-03/54d03c7c49fc6.jpg', '海方团队.jpg', 'jpg', '403754', '1422933116');
INSERT INTO `dux_file` VALUES ('360', '/Uploads/2015-02-03/54d0402dea340.ppt', '/Uploads/2015-02-03/54d0402dea340.ppt', '新型托盘、承重外包装、展架——河北海方.ppt', 'ppt', '19273216', '1422934061');
INSERT INTO `dux_file` VALUES ('361', '/Uploads/2015-02-05/54d2e715c3db1.jpg', '/Uploads/2015-02-05/54d2e715c3db1.jpg', '红酒架3.jpg', 'jpg', '446992', '1423107861');
INSERT INTO `dux_file` VALUES ('362', '/Uploads/2015-02-05/54d2e75783018.jpg', '/Uploads/2015-02-05/54d2e75783018.jpg', '红酒架3.jpg', 'jpg', '446992', '1423107927');
INSERT INTO `dux_file` VALUES ('363', '/Uploads/2015-02-05/54d2e764e6302.jpg', '/Uploads/2015-02-05/54d2e764e6302.jpg', '红酒架2.jpg', 'jpg', '418233', '1423107940');
INSERT INTO `dux_file` VALUES ('364', '/Uploads/2015-02-05/54d2e785b0c84.jpg', '/Uploads/2015-02-05/54d2e785b0c84.jpg', '红酒架1.jpg', 'jpg', '374502', '1423107973');
INSERT INTO `dux_file` VALUES ('365', '/Uploads/2015-02-06/54d45758d9dab.jpg', '/Uploads/2015-02-06/54d45758d9dab.jpg', '红酒架3.jpg', 'jpg', '446992', '1423202136');
INSERT INTO `dux_file` VALUES ('366', '/Uploads/2015-02-06/54d45785f0be1.jpg', '/Uploads/2015-02-06/54d45785f0be1.jpg', '红酒架2.jpg', 'jpg', '418233', '1423202182');
INSERT INTO `dux_file` VALUES ('367', '/Uploads/2015-02-06/54d4579e5bf82.jpg', '/Uploads/2015-02-06/54d4579e5bf82.jpg', '红酒架1.jpg', 'jpg', '374502', '1423202206');
INSERT INTO `dux_file` VALUES ('368', '/Uploads/2015-02-06/54d4581b1eef2.jpg', '/Uploads/2015-02-06/54d4581b1eef2.jpg', '方形纸管特装4.jpg', 'jpg', '242447', '1423202331');
INSERT INTO `dux_file` VALUES ('369', '/Uploads/2015-02-06/54d458472a60d.jpg', '/Uploads/2015-02-06/54d458472a60d.jpg', '方形纸管特装3.jpg', 'jpg', '342644', '1423202375');
INSERT INTO `dux_file` VALUES ('370', '/Uploads/2015-02-06/54d4586f95309.jpg', '/Uploads/2015-02-06/54d4586f95309.jpg', '方形纸管特装2.jpg', 'jpg', '306265', '1423202415');
INSERT INTO `dux_file` VALUES ('371', '/Uploads/2015-02-06/54d45881a0a24.jpg', '/Uploads/2015-02-06/54d45881a0a24.jpg', '方形纸管特装1.jpg', 'jpg', '352043', '1423202433');
INSERT INTO `dux_file` VALUES ('372', '/Uploads/2015-02-06/54d4589e2e316.jpg', '/Uploads/2015-02-06/54d4589e2e316.jpg', '方形纸管特装1.jpg', 'jpg', '352043', '1423202462');
INSERT INTO `dux_file` VALUES ('373', '/Uploads/2015-02-06/54d458b2e54c6.jpg', '/Uploads/2015-02-06/54d458b2e54c6.jpg', '方形纸管特装.jpg', 'jpg', '268450', '1423202482');
INSERT INTO `dux_file` VALUES ('374', '/Uploads/2015-02-06/54d45cda2e316.jpg', '/Uploads/2015-02-06/54d45cda2e316.jpg', '方形纸管特装4.jpg', 'jpg', '242447', '1423203546');
INSERT INTO `dux_file` VALUES ('375', '/Uploads/2015-02-06/54d45cf863994.jpg', '/Uploads/2015-02-06/54d45cf863994.jpg', '方形纸管特装3.jpg', 'jpg', '342644', '1423203576');
INSERT INTO `dux_file` VALUES ('376', '/Uploads/2015-02-06/54d45d090bdc5.jpg', '/Uploads/2015-02-06/54d45d090bdc5.jpg', '方形纸管特装2.jpg', 'jpg', '306265', '1423203593');
INSERT INTO `dux_file` VALUES ('377', '/Uploads/2015-02-06/54d45d18a0a24.jpg', '/Uploads/2015-02-06/54d45d18a0a24.jpg', '方形纸管特装1.jpg', 'jpg', '352043', '1423203608');
INSERT INTO `dux_file` VALUES ('378', '/Uploads/2015-02-06/54d45d26e17bd.jpg', '/Uploads/2015-02-06/54d45d26e17bd.jpg', '方形纸管特装.jpg', 'jpg', '268450', '1423203622');
INSERT INTO `dux_file` VALUES ('379', '/Uploads/2015-02-06/54d48fb92eaaf.jpg', '/Uploads/2015-02-06/54d48fb92eaaf.jpg', '方形纸管特装.jpg', 'jpg', '268450', '1423216569');
INSERT INTO `dux_file` VALUES ('380', '/Uploads/2015-02-06/54d4902f2ada6.jpg', '/Uploads/2015-02-06/54d4902f2ada6.jpg', '茶室隔断+文件架1.jpg', 'jpg', '2173272', '1423216687');
INSERT INTO `dux_file` VALUES ('381', '/Uploads/2015-02-06/54d49085495ee.jpg', '/Uploads/2015-02-06/54d49085495ee.jpg', '茶室隔断+文件架1.jpg', 'jpg', '297186', '1423216773');
INSERT INTO `dux_file` VALUES ('382', '/Uploads/2015-02-06/54d490bdb05e1.jpg', '/Uploads/2015-02-06/54d490bdb05e1.jpg', '茶室隔断+文件架.jpg', 'jpg', '337281', '1423216829');
INSERT INTO `dux_file` VALUES ('383', '/Uploads/2015-02-06/54d49166f137a.jpg', '/Uploads/2015-02-06/54d49166f137a.jpg', '隔断+储物架（箱）2.jpg', 'jpg', '238723', '1423216998');
INSERT INTO `dux_file` VALUES ('384', '/Uploads/2015-02-06/54d492205c71b.jpg', '/Uploads/2015-02-06/54d492205c71b.jpg', '隔断+储物架（箱）2.jpg', 'jpg', '238723', '1423217184');
INSERT INTO `dux_file` VALUES ('385', '/Uploads/2015-02-06/54d4926d00e43.jpg', '/Uploads/2015-02-06/54d4926d00e43.jpg', '茶室隔断+文件架1.jpg', 'jpg', '297186', '1423217261');
INSERT INTO `dux_file` VALUES ('386', '/Uploads/2015-02-06/54d4928460424.jpg', '/Uploads/2015-02-06/54d4928460424.jpg', '茶室隔断+文件架.jpg', 'jpg', '337281', '1423217284');
INSERT INTO `dux_file` VALUES ('387', '/Uploads/2015-02-07/54d5990493e00.jpg', '/Uploads/2015-02-07/54d5990493e00.jpg', '茶室隔断+造型墙.jpg', 'jpg', '311103', '1423284484');
INSERT INTO `dux_file` VALUES ('388', '/Uploads/2015-02-07/54d5994d93e00.jpg', '/Uploads/2015-02-07/54d5994d93e00.jpg', '茶室隔断+造型墙.jpg', 'jpg', '311103', '1423284557');
INSERT INTO `dux_file` VALUES ('389', '/Uploads/2015-02-07/54d5e9a65ef82.jpg', '/Uploads/2015-02-07/54d5e9a65ef82.jpg', '背景桁架1.jpg', 'jpg', '260768', '1423305126');
INSERT INTO `dux_file` VALUES ('390', '/Uploads/2015-02-07/54d5e9e357570.jpg', '/Uploads/2015-02-07/54d5e9e357570.jpg', '展览特装（简）1.jpg', 'jpg', '442768', '1423305187');
INSERT INTO `dux_file` VALUES ('391', '/Uploads/2015-02-07/54d5ea4a29904.jpg', '/Uploads/2015-02-07/54d5ea4a29904.jpg', '展览特装（简）.jpg', 'jpg', '337726', '1423305290');
INSERT INTO `dux_file` VALUES ('392', '/Uploads/2015-02-07/54d5ea68814d3.jpg', '/Uploads/2015-02-07/54d5ea68814d3.jpg', '环保桁架1.jpg', 'jpg', '254636', '1423305320');
INSERT INTO `dux_file` VALUES ('393', '/Uploads/2015-02-07/54d5ea977d7ca.jpg', '/Uploads/2015-02-07/54d5ea977d7ca.jpg', '展览特装（简）1.jpg', 'jpg', '442768', '1423305367');
INSERT INTO `dux_file` VALUES ('394', '/Uploads/2015-02-07/54d5eab99c012.jpg', '/Uploads/2015-02-07/54d5eab99c012.jpg', '展览特装（简）.jpg', 'jpg', '337726', '1423305401');
INSERT INTO `dux_file` VALUES ('395', '/Uploads/2016-01-16/5699b98708aef.jpg', '/Uploads/2016-01-16/5699b98708aef.jpg', 'QQ图片20151222142010.jpg', 'jpg', '209178', '1452915079');
INSERT INTO `dux_file` VALUES ('396', '/Uploads/2016-01-16/5699bad47ef06.jpg', '/Uploads/2016-01-16/5699bad47ef06.jpg', 'QQ图片20151222142027.jpg', 'jpg', '182000', '1452915412');
INSERT INTO `dux_file` VALUES ('397', '/Uploads/2016-01-16/5699bb4f58cac.jpg', '/Uploads/2016-01-16/5699bb4f58cac.jpg', 'QQ图片20151222142010.jpg', 'jpg', '209178', '1452915535');
INSERT INTO `dux_file` VALUES ('398', '/Uploads/2016-01-16/5699f1b3acb72.jpg', '/Uploads/2016-01-16/5699f1b3acb72.jpg', 'QQ图片20151222142010.jpg', 'jpg', '209178', '1452929459');
INSERT INTO `dux_file` VALUES ('399', '/Uploads/2016-01-16/5699f27ebfc9f.jpg', '/Uploads/2016-01-16/5699f27ebfc9f.jpg', 'QQ图片20151222142010_副本.jpg', 'jpg', '134094', '1452929662');
INSERT INTO `dux_file` VALUES ('400', '/Uploads/2016-01-16/5699f3eea5160.jpg', '/Uploads/2016-01-16/5699f3eea5160.jpg', 'QQ图片20151222142010_副本_副本.jpg', 'jpg', '282869', '1452930030');
INSERT INTO `dux_file` VALUES ('401', '/Uploads/2016-01-16/5699f4aba1457.jpg', '/Uploads/2016-01-16/5699f4aba1457.jpg', '1.jpg', 'jpg', '20305', '1452930219');
INSERT INTO `dux_file` VALUES ('402', '/Uploads/2016-01-16/5699f579737eb.jpg', '/Uploads/2016-01-16/5699f579737eb.jpg', 'QQ截图20160116154728.jpg', 'jpg', '13749', '1452930425');
INSERT INTO `dux_file` VALUES ('403', '/Uploads/2016-01-16/5699f669a8e69.jpg', '/Uploads/2016-01-16/5699f669a8e69.jpg', 'QQ截图20160116155110.jpg', 'jpg', '21091', '1452930665');
INSERT INTO `dux_file` VALUES ('404', '/Uploads/2016-01-16/5699f7026bdd9.jpg', '/Uploads/2016-01-16/5699f7026bdd9.jpg', 'QQ截图20160116155424.jpg', 'jpg', '13066', '1452930818');
INSERT INTO `dux_file` VALUES ('405', '/Uploads/2016-01-16/5699fc4e6fb48.jpg', '/Uploads/2016-01-16/5699fc4e6fb48.jpg', 'QQ截图20160116155842.jpg', 'jpg', '15306', '1452932174');
INSERT INTO `dux_file` VALUES ('406', '/Uploads/2016-01-16/5699fd7e45be5.jpg', '/Uploads/2016-01-16/5699fd7e45be5.jpg', 'QQ截图20160116162151.jpg', 'jpg', '18167', '1452932478');
INSERT INTO `dux_file` VALUES ('407', '/Uploads/2016-01-16/5699fe7704e4c.jpg', '/Uploads/2016-01-16/5699fe7704e4c.jpg', 'QQ截图20160116162352.jpg', 'jpg', '15050', '1452932727');
INSERT INTO `dux_file` VALUES ('408', '/Uploads/2016-01-16/5699fef0e9c68.jpg', '/Uploads/2016-01-16/5699fef0e9c68.jpg', 'QQ截图20160116162745.jpg', 'jpg', '26079', '1452932848');
INSERT INTO `dux_file` VALUES ('409', '/Uploads/2016-01-25/56a5c1bf696cb.jpg', '/Uploads/2016-01-25/56a5c1bf696cb.jpg', '2694588299_1362436526.jpg', 'jpg', '154290', '1453703615');
INSERT INTO `dux_file` VALUES ('410', '/Uploads/2016-01-25/56a5c6f90eb59.jpg', '/Uploads/2016-01-25/56a5c6f90eb59.jpg', '2694588299_1362436526.jpg', 'jpg', '154290', '1453704953');
INSERT INTO `dux_file` VALUES ('411', '/Uploads/2016-01-25/56a5c8e76e37f.jpg', '/Uploads/2016-01-25/56a5c8e76e37f.jpg', '2694588299_1362436526.jpg', 'jpg', '154290', '1453705447');
INSERT INTO `dux_file` VALUES ('412', '/Uploads/2016-01-25/56a5c939dca30.jpg', '/Uploads/2016-01-25/56a5c939dca30.jpg', '2345截图20160125150409.jpg', 'jpg', '66653', '1453705529');
INSERT INTO `dux_file` VALUES ('413', '/Uploads/2016-01-25/56a5ca62c3347.jpg', '/Uploads/2016-01-25/56a5ca62c3347.jpg', '2691424323_1362436526.jpg', 'jpg', '151762', '1453705826');
INSERT INTO `dux_file` VALUES ('414', '/Uploads/2016-01-25/56a5cad964e4c.jpg', '/Uploads/2016-01-25/56a5cad964e4c.jpg', '2345截图20160125151154.jpg', 'jpg', '111206', '1453705945');
INSERT INTO `dux_file` VALUES ('415', '/Uploads/2016-01-25/56a5cba3aa0c0.jpg', '/Uploads/2016-01-25/56a5cba3aa0c0.jpg', '2693003602_1362436526.jpg', 'jpg', '246685', '1453706147');
INSERT INTO `dux_file` VALUES ('416', '/Uploads/2016-01-25/56a5dafc7d521.jpg', '/Uploads/2016-01-25/56a5dafc7d521.jpg', '图片1.jpg', 'jpg', '22480', '1453710076');
INSERT INTO `dux_file` VALUES ('417', '/Uploads/2016-01-25/56a5e2722cfec.png', '/Uploads/2016-01-25/56a5e2722cfec.png', 'QQ截图20160125154139.png', 'png', '159339', '1453711986');
INSERT INTO `dux_file` VALUES ('418', '/Uploads/2016-01-26/56a710f21417c.png', '/Uploads/2016-01-26/56a710f21417c.png', 'QQ截图20160125172656.png', 'png', '192537', '1453789426');
INSERT INTO `dux_file` VALUES ('419', '/Uploads/2016-04-06/57047840138a3.png', '/Uploads/2016-04-06/57047840138a3.png', 'A-1.png', 'png', '268415', '1459910720');
INSERT INTO `dux_file` VALUES ('420', '/Uploads/2016-04-06/570479c839afd.png', '/Uploads/2016-04-06/570479c839afd.png', 'A-1_副本.png', 'png', '136554', '1459911112');
INSERT INTO `dux_file` VALUES ('421', '/Uploads/2016-04-06/57047a5050933.png', '/Uploads/2016-04-06/57047a5050933.png', 'A-1_副本.png', 'png', '136554', '1459911248');
INSERT INTO `dux_file` VALUES ('422', '/Uploads/2016-04-06/57047af7e5592.png', '/Uploads/2016-04-06/57047af7e5592.png', 'A-1_副本.png', 'png', '136554', '1459911415');
INSERT INTO `dux_file` VALUES ('423', '/Uploads/2016-04-06/57047bd208188.png', '/Uploads/2016-04-06/57047bd208188.png', '1.png', 'png', '110053', '1459911634');
INSERT INTO `dux_file` VALUES ('424', '/Uploads/2016-04-06/57047c526b472.png', '/Uploads/2016-04-06/57047c526b472.png', '12_副本.png', 'png', '137876', '1459911762');
INSERT INTO `dux_file` VALUES ('425', '/Uploads/2016-04-06/570482bf22cc7.png', '/Uploads/2016-04-06/570482bf22cc7.png', 'QQ截图20160406112354_副本.png', 'png', '150182', '1459913407');
INSERT INTO `dux_file` VALUES ('426', '/Uploads/2016-04-06/570483c022cc7.png', '/Uploads/2016-04-06/570483c022cc7.png', 'QQ截图20160406113116_副本.png', 'png', '178956', '1459913664');
INSERT INTO `dux_file` VALUES ('427', '/Uploads/2016-04-06/57048530bf338.png', '/Uploads/2016-04-06/57048530bf338.png', 'QQ截图20160406113751_副本.png', 'png', '169803', '1459914032');
INSERT INTO `dux_file` VALUES ('428', '/Uploads/2016-05-04/5729ae9e235a1.png', '/Uploads/2016-05-04/5729ae9e235a1.png', 'QQ截图20160504161027_副本.png', 'png', '300802', '1462349470');
INSERT INTO `dux_file` VALUES ('429', '/Uploads/2016-05-04/5729b21fc1d5c.png', '/Uploads/2016-05-04/5729b21fc1d5c.png', '1.png', 'png', '183835', '1462350367');
INSERT INTO `dux_file` VALUES ('430', '/Uploads/2016-05-04/5729b29514c93.png', '/Uploads/2016-05-04/5729b29514c93.png', '2.png', 'png', '240121', '1462350485');

-- -----------------------------
-- Table structure for `dux_fragment`
-- -----------------------------
DROP TABLE IF EXISTS `dux_fragment`;
CREATE TABLE `dux_fragment` (
  `fragment_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文章id',
  `label` varchar(250) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`fragment_id`),
  KEY `label` (`label`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COMMENT='网站碎片';

-- -----------------------------
-- Records of `dux_fragment`
-- -----------------------------
INSERT INTO `dux_fragment` VALUES ('2', 'gzcompany', '广州公司', '&amp;lt;li&amp;gt;\r\n	&amp;lt;p class=&amp;quot;title&amp;quot;&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;广州海方科技股份有限公司&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n	&amp;lt;p&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;咨询：王小姐&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:16px;&amp;quot;&amp;gt; \r\n	&amp;lt;p&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;固话：&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt;&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;020-&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt;&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;39122816&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n	&amp;lt;p&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;手机：&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt;&amp;lt;strong&amp;gt;&amp;lt;span style=&amp;quot;font-size:14px;&amp;quot;&amp;gt;13922332665 18929569968&amp;lt;/span&amp;gt;&amp;lt;/strong&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n&amp;lt;/span&amp;gt;\r\n&amp;lt;/li&amp;gt;');
INSERT INTO `dux_fragment` VALUES ('3', 'sdcompany', '山东公司', '&amp;lt;li&amp;gt;\r\n	&amp;lt;p class=&amp;quot;title&amp;quot;&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;山东海方科技股份有限公司&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n	&amp;lt;p&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;咨询：曹先生&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n	&amp;lt;p&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;&amp;lt;span style=&amp;quot;font-size:14px;&amp;quot;&amp;gt;固话：0534-8107769&amp;lt;/span&amp;gt;&amp;lt;/strong&amp;gt; &amp;lt;/span&amp;gt;\r\n	&amp;lt;/p&amp;gt;\r\n	&amp;lt;p&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;手机：18953478900&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n&amp;lt;/li&amp;gt;');
INSERT INTO `dux_fragment` VALUES ('4', 'hbcompany', '河北公司', '&amp;lt;li class=&amp;quot;last&amp;quot;&amp;gt;\r\n	&amp;lt;p class=&amp;quot;title&amp;quot;&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;河北海方科技股份有限公司&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n	&amp;lt;p&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;咨询：胡先生&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n	&amp;lt;p&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;固话：0311-68031426&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n	&amp;lt;p&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;手机：13930422987&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n&amp;lt;/li&amp;gt;');
INSERT INTO `dux_fragment` VALUES ('5', 'rongyu', '首页荣誉', '&amp;lt;span style=&amp;quot;line-height:150%;font-family:黑体;&amp;quot;&amp;gt;&amp;lt;span style=&amp;quot;font-size:16px;&amp;quot;&amp;gt;&amp;lt;/span&amp;gt;&amp;lt;span&amp;gt;&amp;lt;/span&amp;gt;&amp;lt;/span&amp;gt;&amp;lt;img src=&amp;quot;/Uploads/2015-01-31/54cc9b554a50c.jpg&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt;');
INSERT INTO `dux_fragment` VALUES ('6', 'anli', '首页案例文字', '&amp;lt;p&amp;gt;\r\n	&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:16px;&amp;quot;&amp;gt;&amp;lt;span style=&amp;quot;font-family:SimHei;&amp;quot;&amp;gt;&amp;lt;span style=&amp;quot;color:#000000;font-size:14px;&amp;quot;&amp;gt;&amp;amp;nbsp;&amp;lt;/span&amp;gt;&amp;lt;span style=&amp;quot;font-family:Microsoft YaHei;color:#000000;font-size:14px;&amp;quot;&amp;gt;&amp;amp;nbsp;&amp;lt;/span&amp;gt;&amp;lt;/span&amp;gt;&amp;lt;span style=&amp;quot;font-family:SimHei;color:#ffffff;font-size:14px;&amp;quot;&amp;gt;海方「方形纸管」在工业包装、物流运输、展览展示、建材装饰、商装家装、办公家居、救援等行业应用中，其“代木、代塑、代金属”的产品特性，为我国纸制品行业发展拓宽了适用领域，同时更环保、更便捷、综合使用成本更低。&amp;lt;/span&amp;gt;&amp;lt;/span&amp;gt; \r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p&amp;gt;\r\n	&amp;lt;span style=&amp;quot;font-family:SimHei;color:#ffffff;font-size:14px;&amp;quot;&amp;gt;&amp;amp;nbsp;&amp;amp;nbsp;&amp;lt;/span&amp;gt;&amp;lt;span style=&amp;quot;font-family:SimHei;color:#ffffff;font-size:14px;&amp;quot;&amp;gt;海方「方形纸管」填补了国内技术和产品空白，是我国纸制品行业的一次技术革命，更是传统行业的一次技术革新。&amp;lt;/span&amp;gt; \r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p&amp;gt;\r\n	&amp;lt;span style=&amp;quot;font-family:SimHei;color:#ffffff;font-size:14px;&amp;quot;&amp;gt;&amp;amp;nbsp; &amp;lt;/span&amp;gt;&amp;lt;span style=&amp;quot;font-family:SimHei;color:#ffffff;font-size:14px;&amp;quot;&amp;gt;做为企业公民，海方将持续研发制造更具科技含量的节能环保新材料、新产品服务社会！&amp;lt;/span&amp;gt; \r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p&amp;gt;\r\n	&amp;lt;!--\r\n	&amp;lt;div class=&amp;quot;main-title&amp;quot;&amp;gt;\r\n		&amp;lt;h4&amp;gt;\r\n			&amp;lt;img src=&amp;quot;/Themes/default/images/advantage_font.gif&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt; \r\n		&amp;lt;/h4&amp;gt;\r\n	&amp;lt;/div&amp;gt;\r\n	&amp;lt;div class=&amp;quot;advantage oh&amp;quot;&amp;gt;\r\n	&amp;lt;/div&amp;gt;\r\n--&amp;gt;\r\n&amp;lt;/p&amp;gt;');
INSERT INTO `dux_fragment` VALUES ('7', 'fangxing', '方形纸管', '&amp;lt;img src=&amp;quot;/Uploads/2015-02-03/54d03a5e3e8ab.jpg&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt;&amp;lt;br /&amp;gt;');
INSERT INTO `dux_fragment` VALUES ('8', 'wuliu', '物流托盘', '&amp;lt;img src=&amp;quot;/Uploads/2015-02-03/54d03a8a1c35a.jpg&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt;&amp;lt;br /&amp;gt;');
INSERT INTO `dux_fragment` VALUES ('9', 'baozhuang', '包装箱', '&amp;lt;img src=&amp;quot;/Uploads/2015-02-03/54d03ab66c517.jpg&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt;&amp;lt;br /&amp;gt;');
INSERT INTO `dux_fragment` VALUES ('10', 'kuangjia', '框架包装', '&amp;lt;img src=&amp;quot;/Uploads/2015-02-03/54d03ad110c3f.jpg&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt;&amp;lt;br /&amp;gt;');
INSERT INTO `dux_fragment` VALUES ('11', 'neizhiwai', '内置外包装', '&amp;lt;img src=&amp;quot;/Uploads/2015-02-03/54d03ae423d6c.jpg&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt;&amp;lt;br /&amp;gt;');
INSERT INTO `dux_fragment` VALUES ('12', 'zhanshi', '展示架堆头架', '&amp;lt;img src=&amp;quot;/Uploads/2015-02-03/54d03af84dccf.jpg&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt;&amp;lt;br /&amp;gt;');
INSERT INTO `dux_fragment` VALUES ('13', 'shangzhuang', '商装家装', '&amp;lt;img src=&amp;quot;/Uploads/2015-02-03/54d03b107b93b.jpg&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt;&amp;lt;br /&amp;gt;');
INSERT INTO `dux_fragment` VALUES ('14', 'jiaju', '家具办公', '&amp;lt;img src=&amp;quot;/Uploads/2015-02-03/54d03b262f487.jpg&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt;&amp;lt;br /&amp;gt;');
INSERT INTO `dux_fragment` VALUES ('15', 'fangwu', '房屋临时安置', '&amp;lt;img src=&amp;quot;/Uploads/2015-02-03/54d03b3e87056.jpg&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt;&amp;lt;br /&amp;gt;');
INSERT INTO `dux_fragment` VALUES ('16', 'gainian', '概念产品', '&amp;lt;img src=&amp;quot;/Uploads/2015-02-03/54d03b528ea68.jpg&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt;&amp;lt;br /&amp;gt;');
INSERT INTO `dux_fragment` VALUES ('17', 'guangzhou', '联系我们广州', '&amp;lt;div class=&amp;quot;contact fl&amp;quot;&amp;gt;\r\n	&amp;lt;p class=&amp;quot;company&amp;quot;&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;广州海方科技股份有限公司&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n	&amp;lt;p class=&amp;quot;address&amp;quot;&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;地址：广州番禺大道北555号天安节能科技园发展大厦817&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n	&amp;lt;p class=&amp;quot;phone&amp;quot;&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;咨询：王小姐&amp;amp;nbsp;13922332665&amp;lt;/span&amp;gt;&amp;lt;span style=&amp;quot;font-size:14px;&amp;quot;&amp;gt;&amp;amp;nbsp;/ &amp;lt;/span&amp;gt;&amp;lt;span style=&amp;quot;font-size:14px;&amp;quot;&amp;gt;18929569968&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n	&amp;lt;p class=&amp;quot;qq&amp;quot;&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-size:16px;&amp;quot;&amp;gt;&amp;lt;/span&amp;gt;&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;Q&amp;amp;nbsp; Q：2850182910&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n&amp;lt;/div&amp;gt;');
INSERT INTO `dux_fragment` VALUES ('18', 'sjz', '联系我们石家庄', '&amp;lt;div class=&amp;quot;contact fl&amp;quot;&amp;gt;\r\n	&amp;lt;p class=&amp;quot;company&amp;quot;&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;河北海方科技股份有限公司&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n	&amp;lt;p class=&amp;quot;address&amp;quot;&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;地址：河北省石家庄市长安区跃进路171号&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n	&amp;lt;p class=&amp;quot;phone&amp;quot;&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;咨询：胡先生&amp;amp;nbsp;13930422987&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n	&amp;lt;p class=&amp;quot;qq&amp;quot;&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:16px;&amp;quot;&amp;gt;&amp;lt;span style=&amp;quot;font-size:14px;&amp;quot;&amp;gt;Q&amp;amp;nbsp; &amp;lt;/span&amp;gt;&amp;lt;span style=&amp;quot;font-size:14px;&amp;quot;&amp;gt;Q： 2850182919&amp;amp;nbsp;&amp;amp;nbsp; 3020023218&amp;lt;/span&amp;gt;&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n&amp;lt;/div&amp;gt;');
INSERT INTO `dux_fragment` VALUES ('19', 'shandong', '联系我们山东', '&amp;lt;div class=&amp;quot;contact fl&amp;quot;&amp;gt;\r\n	&amp;lt;p class=&amp;quot;company&amp;quot;&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;山东海方科技股份有限公司&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n	&amp;lt;p class=&amp;quot;address&amp;quot;&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:16px;&amp;quot;&amp;gt;&amp;lt;span style=&amp;quot;font-size:14px;&amp;quot;&amp;gt;地址：山东省德州市平原县东开发区&amp;lt;/span&amp;gt;&amp;lt;br /&amp;gt;\r\n&amp;lt;/span&amp;gt;\r\n	&amp;lt;/p&amp;gt;\r\n	&amp;lt;p class=&amp;quot;phone&amp;quot;&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;咨询：曹先生 18953478900&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n	&amp;lt;p class=&amp;quot;qq&amp;quot;&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;Q&amp;amp;nbsp; Q:&amp;amp;nbsp;496973150&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n&amp;lt;/div&amp;gt;');
INSERT INTO `dux_fragment` VALUES ('20', 'zjcompany', '浙江公司 ', '&amp;lt;p&amp;gt;\r\n	&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;·浙江海方科技股份有限公司&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt; \r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p&amp;gt;\r\n	&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;咨询：王小姐&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt; \r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p&amp;gt;\r\n	&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;&amp;lt;span style=&amp;quot;font-size:14px;&amp;quot;&amp;gt;固话：0574-88932660&amp;lt;/span&amp;gt;&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt; \r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p&amp;gt;\r\n	&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;&amp;lt;span style=&amp;quot;font-size:14px;&amp;quot;&amp;gt;&amp;lt;/span&amp;gt;&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt;&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;手机：13922332665&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt; \r\n&amp;lt;/p&amp;gt;');
INSERT INTO `dux_fragment` VALUES ('21', 'zhejiang', '联系我们浙江', '&amp;lt;div class=&amp;quot;contact fl&amp;quot;&amp;gt;\r\n	&amp;lt;p class=&amp;quot;company&amp;quot;&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;&amp;lt;strong&amp;gt;浙江海方科技股份有限公司&amp;lt;/strong&amp;gt;&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n	&amp;lt;p class=&amp;quot;address&amp;quot;&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:16px;&amp;quot;&amp;gt;&amp;lt;span style=&amp;quot;font-size:14px;&amp;quot;&amp;gt;地址：浙江省奉化江口街道渡路郭范村（四明粉末厂内）&amp;lt;/span&amp;gt;&amp;lt;/span&amp;gt;\r\n	&amp;lt;/p&amp;gt;\r\n	&amp;lt;p class=&amp;quot;address&amp;quot;&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:16px;&amp;quot;&amp;gt;&amp;lt;span style=&amp;quot;font-size:14px;&amp;quot;&amp;gt;&amp;lt;/span&amp;gt;&amp;lt;/span&amp;gt;&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;咨询：王小姐&amp;amp;nbsp;13922332665&amp;lt;/span&amp;gt; \r\n	&amp;lt;/p&amp;gt;\r\n	&amp;lt;p class=&amp;quot;qq&amp;quot;&amp;gt;\r\n		&amp;lt;span style=&amp;quot;font-family:SimHei;font-size:14px;&amp;quot;&amp;gt;Q&amp;amp;nbsp; Q:&amp;amp;nbsp;2850182911&amp;lt;/span&amp;gt;&amp;lt;strong&amp;gt;&amp;lt;span style=&amp;quot;background-color:#fbfcfc;color:#007ad8;&amp;quot;&amp;gt;&amp;lt;/span&amp;gt;&amp;lt;/strong&amp;gt;\r\n	&amp;lt;/p&amp;gt;\r\n&amp;lt;/div&amp;gt;');

-- -----------------------------
-- Table structure for `dux_position`
-- -----------------------------
DROP TABLE IF EXISTS `dux_position`;
CREATE TABLE `dux_position` (
  `position_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `sequence` int(10) DEFAULT '0',
  PRIMARY KEY (`position_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='推荐位';

-- -----------------------------
-- Records of `dux_position`
-- -----------------------------
INSERT INTO `dux_position` VALUES ('1', '首页推荐', '0');
INSERT INTO `dux_position` VALUES ('2', '首页产品推荐', '1');

-- -----------------------------
-- Table structure for `dux_tags`
-- -----------------------------
DROP TABLE IF EXISTS `dux_tags`;
CREATE TABLE `dux_tags` (
  `tag_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `click` int(10) DEFAULT '1',
  `quote` int(10) DEFAULT '1',
  PRIMARY KEY (`tag_id`),
  KEY `quote` (`quote`),
  KEY `click` (`click`),
  KEY `name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='TAG标签';

-- -----------------------------
-- Records of `dux_tags`
-- -----------------------------
INSERT INTO `dux_tags` VALUES ('1', '房舍', '14', '1');

-- -----------------------------
-- Table structure for `dux_tags_has`
-- -----------------------------
DROP TABLE IF EXISTS `dux_tags_has`;
CREATE TABLE `dux_tags_has` (
  `content_id` int(10) DEFAULT NULL,
  `tag_id` int(10) DEFAULT NULL,
  KEY `aid` (`content_id`),
  KEY `tid` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='TAG关系';

-- -----------------------------
-- Records of `dux_tags_has`
-- -----------------------------
INSERT INTO `dux_tags_has` VALUES ('164', '1');

-- -----------------------------
-- Table structure for `dux_total_spider`
-- -----------------------------
DROP TABLE IF EXISTS `dux_total_spider`;
CREATE TABLE `dux_total_spider` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `time` int(10) DEFAULT NULL,
  `baidu` int(10) DEFAULT '0',
  `google` int(10) DEFAULT '0',
  `soso` int(10) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='蜘蛛统计';


-- -----------------------------
-- Table structure for `dux_total_visitor`
-- -----------------------------
DROP TABLE IF EXISTS `dux_total_visitor`;
CREATE TABLE `dux_total_visitor` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `time` int(10) DEFAULT NULL,
  `count` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=457 DEFAULT CHARSET=utf8 COMMENT='访客统计';

-- -----------------------------
-- Records of `dux_total_visitor`
-- -----------------------------
INSERT INTO `dux_total_visitor` VALUES ('1', '1420732800', '15');
INSERT INTO `dux_total_visitor` VALUES ('2', '1420819200', '49');
INSERT INTO `dux_total_visitor` VALUES ('3', '1420992000', '57');
INSERT INTO `dux_total_visitor` VALUES ('4', '1421078400', '21');
INSERT INTO `dux_total_visitor` VALUES ('5', '1421164800', '187');
INSERT INTO `dux_total_visitor` VALUES ('6', '1421251200', '23');
INSERT INTO `dux_total_visitor` VALUES ('7', '1421337600', '71');
INSERT INTO `dux_total_visitor` VALUES ('8', '1421424000', '107');
INSERT INTO `dux_total_visitor` VALUES ('9', '1421510400', '210');
INSERT INTO `dux_total_visitor` VALUES ('10', '1421596800', '37');
INSERT INTO `dux_total_visitor` VALUES ('11', '1421683200', '39');
INSERT INTO `dux_total_visitor` VALUES ('12', '1421769600', '4');
INSERT INTO `dux_total_visitor` VALUES ('13', '1421856000', '2');
INSERT INTO `dux_total_visitor` VALUES ('14', '1421942400', '2');
INSERT INTO `dux_total_visitor` VALUES ('15', '1422028800', '20');
INSERT INTO `dux_total_visitor` VALUES ('16', '1422115200', '49');
INSERT INTO `dux_total_visitor` VALUES ('17', '1422201600', '11');
INSERT INTO `dux_total_visitor` VALUES ('18', '1422288000', '5');
INSERT INTO `dux_total_visitor` VALUES ('19', '1422374400', '7');
INSERT INTO `dux_total_visitor` VALUES ('20', '1422460800', '2');
INSERT INTO `dux_total_visitor` VALUES ('21', '1422547200', '5');
INSERT INTO `dux_total_visitor` VALUES ('22', '1422633600', '684');
INSERT INTO `dux_total_visitor` VALUES ('23', '1422720000', '3769');
INSERT INTO `dux_total_visitor` VALUES ('24', '1422806400', '4596');
INSERT INTO `dux_total_visitor` VALUES ('25', '1422892800', '3011');
INSERT INTO `dux_total_visitor` VALUES ('26', '1422979200', '3971');
INSERT INTO `dux_total_visitor` VALUES ('27', '1423065600', '3948');
INSERT INTO `dux_total_visitor` VALUES ('28', '1423152000', '3853');
INSERT INTO `dux_total_visitor` VALUES ('29', '1423238400', '3021');
INSERT INTO `dux_total_visitor` VALUES ('30', '1423324800', '3856');
INSERT INTO `dux_total_visitor` VALUES ('31', '1423411200', '4783');
INSERT INTO `dux_total_visitor` VALUES ('32', '1423497600', '3956');
INSERT INTO `dux_total_visitor` VALUES ('33', '1423584000', '3852');
INSERT INTO `dux_total_visitor` VALUES ('34', '1423670400', '3929');
INSERT INTO `dux_total_visitor` VALUES ('35', '1423756800', '4172');
INSERT INTO `dux_total_visitor` VALUES ('36', '1423843200', '2936');
INSERT INTO `dux_total_visitor` VALUES ('37', '1423929600', '3710');
INSERT INTO `dux_total_visitor` VALUES ('38', '1424016000', '2892');
INSERT INTO `dux_total_visitor` VALUES ('39', '1424102400', '2930');
INSERT INTO `dux_total_visitor` VALUES ('40', '1424188800', '4222');
INSERT INTO `dux_total_visitor` VALUES ('41', '1424275200', '449');
INSERT INTO `dux_total_visitor` VALUES ('42', '1424966400', '3857');
INSERT INTO `dux_total_visitor` VALUES ('43', '1425052800', '4123');
INSERT INTO `dux_total_visitor` VALUES ('44', '1425052800', '1');
INSERT INTO `dux_total_visitor` VALUES ('45', '1425139200', '2953');
INSERT INTO `dux_total_visitor` VALUES ('46', '1425139200', '1');
INSERT INTO `dux_total_visitor` VALUES ('47', '1425225600', '3089');
INSERT INTO `dux_total_visitor` VALUES ('48', '1425312000', '4116');
INSERT INTO `dux_total_visitor` VALUES ('49', '1425398400', '2996');
INSERT INTO `dux_total_visitor` VALUES ('50', '1425484800', '2920');
INSERT INTO `dux_total_visitor` VALUES ('51', '1425571200', '2878');
INSERT INTO `dux_total_visitor` VALUES ('52', '1425571200', '1');
INSERT INTO `dux_total_visitor` VALUES ('53', '1425657600', '7086');
INSERT INTO `dux_total_visitor` VALUES ('54', '1425744000', '1256');
INSERT INTO `dux_total_visitor` VALUES ('55', '1425830400', '4602');
INSERT INTO `dux_total_visitor` VALUES ('56', '1425916800', '4755');
INSERT INTO `dux_total_visitor` VALUES ('57', '1426003200', '7050');
INSERT INTO `dux_total_visitor` VALUES ('58', '1426089600', '17270');
INSERT INTO `dux_total_visitor` VALUES ('59', '1426176000', '4792');
INSERT INTO `dux_total_visitor` VALUES ('60', '1426262400', '4555');
INSERT INTO `dux_total_visitor` VALUES ('61', '1426348800', '1165');
INSERT INTO `dux_total_visitor` VALUES ('62', '1426435200', '6445');
INSERT INTO `dux_total_visitor` VALUES ('63', '1426521600', '4623');
INSERT INTO `dux_total_visitor` VALUES ('64', '1426521600', '1');
INSERT INTO `dux_total_visitor` VALUES ('65', '1426608000', '4566');
INSERT INTO `dux_total_visitor` VALUES ('66', '1426694400', '1242');
INSERT INTO `dux_total_visitor` VALUES ('67', '1426780800', '3793');
INSERT INTO `dux_total_visitor` VALUES ('68', '1426867200', '4519');
INSERT INTO `dux_total_visitor` VALUES ('69', '1426953600', '1220');
INSERT INTO `dux_total_visitor` VALUES ('70', '1427040000', '1142');
INSERT INTO `dux_total_visitor` VALUES ('71', '1427126400', '6059');
INSERT INTO `dux_total_visitor` VALUES ('72', '1427126400', '1');
INSERT INTO `dux_total_visitor` VALUES ('73', '1427212800', '4260');
INSERT INTO `dux_total_visitor` VALUES ('74', '1427299200', '1170');
INSERT INTO `dux_total_visitor` VALUES ('75', '1427385600', '4091');
INSERT INTO `dux_total_visitor` VALUES ('76', '1427472000', '1094');
INSERT INTO `dux_total_visitor` VALUES ('77', '1427558400', '353');
INSERT INTO `dux_total_visitor` VALUES ('78', '1427644800', '419');
INSERT INTO `dux_total_visitor` VALUES ('79', '1427731200', '1243');
INSERT INTO `dux_total_visitor` VALUES ('80', '1427817600', '3397');
INSERT INTO `dux_total_visitor` VALUES ('81', '1427904000', '1467');
INSERT INTO `dux_total_visitor` VALUES ('82', '1427990400', '1574');
INSERT INTO `dux_total_visitor` VALUES ('83', '1428076800', '2922');
INSERT INTO `dux_total_visitor` VALUES ('84', '1428076800', '1');
INSERT INTO `dux_total_visitor` VALUES ('85', '1428163200', '3371');
INSERT INTO `dux_total_visitor` VALUES ('86', '1428249600', '3768');
INSERT INTO `dux_total_visitor` VALUES ('87', '1428336000', '3913');
INSERT INTO `dux_total_visitor` VALUES ('88', '1428422400', '4235');
INSERT INTO `dux_total_visitor` VALUES ('89', '1428508800', '5711');
INSERT INTO `dux_total_visitor` VALUES ('90', '1428595200', '5588');
INSERT INTO `dux_total_visitor` VALUES ('91', '1428681600', '5380');
INSERT INTO `dux_total_visitor` VALUES ('92', '1428768000', '4648');
INSERT INTO `dux_total_visitor` VALUES ('93', '1428768000', '1');
INSERT INTO `dux_total_visitor` VALUES ('94', '1428854400', '4894');
INSERT INTO `dux_total_visitor` VALUES ('95', '1428940800', '5779');
INSERT INTO `dux_total_visitor` VALUES ('96', '1429027200', '6255');
INSERT INTO `dux_total_visitor` VALUES ('97', '1429113600', '5936');
INSERT INTO `dux_total_visitor` VALUES ('98', '1429200000', '5626');
INSERT INTO `dux_total_visitor` VALUES ('99', '1429286400', '5696');
INSERT INTO `dux_total_visitor` VALUES ('100', '1429372800', '5626');
INSERT INTO `dux_total_visitor` VALUES ('101', '1429459200', '753');
INSERT INTO `dux_total_visitor` VALUES ('102', '1430409600', '3591');
INSERT INTO `dux_total_visitor` VALUES ('103', '1430409600', '1');
INSERT INTO `dux_total_visitor` VALUES ('104', '1430409600', '1');
INSERT INTO `dux_total_visitor` VALUES ('105', '1430409600', '1');
INSERT INTO `dux_total_visitor` VALUES ('106', '1430496000', '4714');
INSERT INTO `dux_total_visitor` VALUES ('107', '1430582400', '4117');
INSERT INTO `dux_total_visitor` VALUES ('108', '1430668800', '4775');
INSERT INTO `dux_total_visitor` VALUES ('109', '1430755200', '465');
INSERT INTO `dux_total_visitor` VALUES ('110', '1430841600', '5368');
INSERT INTO `dux_total_visitor` VALUES ('111', '1430928000', '2470');
INSERT INTO `dux_total_visitor` VALUES ('112', '1431014400', '3918');
INSERT INTO `dux_total_visitor` VALUES ('113', '1431100800', '4262');
INSERT INTO `dux_total_visitor` VALUES ('114', '1431187200', '4103');
INSERT INTO `dux_total_visitor` VALUES ('115', '1431273600', '3990');
INSERT INTO `dux_total_visitor` VALUES ('116', '1431360000', '4683');
INSERT INTO `dux_total_visitor` VALUES ('117', '1431446400', '3309');
INSERT INTO `dux_total_visitor` VALUES ('118', '1431532800', '2665');
INSERT INTO `dux_total_visitor` VALUES ('119', '1431619200', '3368');
INSERT INTO `dux_total_visitor` VALUES ('120', '1431705600', '1497');
INSERT INTO `dux_total_visitor` VALUES ('121', '1431792000', '1629');
INSERT INTO `dux_total_visitor` VALUES ('122', '1431878400', '1632');
INSERT INTO `dux_total_visitor` VALUES ('123', '1431964800', '2963');
INSERT INTO `dux_total_visitor` VALUES ('124', '1432051200', '736');
INSERT INTO `dux_total_visitor` VALUES ('125', '1433088000', '4216');
INSERT INTO `dux_total_visitor` VALUES ('126', '1433088000', '1');
INSERT INTO `dux_total_visitor` VALUES ('127', '1433088000', '1');
INSERT INTO `dux_total_visitor` VALUES ('128', '1433088000', '1');
INSERT INTO `dux_total_visitor` VALUES ('129', '1433174400', '2841');
INSERT INTO `dux_total_visitor` VALUES ('130', '1433260800', '4401');
INSERT INTO `dux_total_visitor` VALUES ('131', '1433347200', '5965');
INSERT INTO `dux_total_visitor` VALUES ('132', '1433433600', '5980');
INSERT INTO `dux_total_visitor` VALUES ('133', '1433520000', '5403');
INSERT INTO `dux_total_visitor` VALUES ('134', '1433606400', '4568');
INSERT INTO `dux_total_visitor` VALUES ('135', '1433692800', '6289');
INSERT INTO `dux_total_visitor` VALUES ('136', '1433779200', '7229');
INSERT INTO `dux_total_visitor` VALUES ('137', '1433865600', '6204');
INSERT INTO `dux_total_visitor` VALUES ('138', '1433952000', '5176');
INSERT INTO `dux_total_visitor` VALUES ('139', '1434038400', '2300');
INSERT INTO `dux_total_visitor` VALUES ('140', '1434124800', '2479');
INSERT INTO `dux_total_visitor` VALUES ('141', '1434211200', '2664');
INSERT INTO `dux_total_visitor` VALUES ('142', '1434297600', '4445');
INSERT INTO `dux_total_visitor` VALUES ('143', '1434384000', '4902');
INSERT INTO `dux_total_visitor` VALUES ('144', '1434470400', '5842');
INSERT INTO `dux_total_visitor` VALUES ('145', '1434556800', '1365');
INSERT INTO `dux_total_visitor` VALUES ('146', '1435248000', '483');
INSERT INTO `dux_total_visitor` VALUES ('147', '1435334400', '4355');
INSERT INTO `dux_total_visitor` VALUES ('148', '1435420800', '2847');
INSERT INTO `dux_total_visitor` VALUES ('149', '1435507200', '367');
INSERT INTO `dux_total_visitor` VALUES ('150', '1435593600', '4054');
INSERT INTO `dux_total_visitor` VALUES ('151', '1435680000', '4605');
INSERT INTO `dux_total_visitor` VALUES ('152', '1435766400', '4531');
INSERT INTO `dux_total_visitor` VALUES ('153', '1435852800', '3963');
INSERT INTO `dux_total_visitor` VALUES ('154', '1435939200', '4601');
INSERT INTO `dux_total_visitor` VALUES ('155', '1436025600', '4316');
INSERT INTO `dux_total_visitor` VALUES ('156', '1436112000', '4409');
INSERT INTO `dux_total_visitor` VALUES ('157', '1436198400', '3788');
INSERT INTO `dux_total_visitor` VALUES ('158', '1436284800', '3971');
INSERT INTO `dux_total_visitor` VALUES ('159', '1436371200', '4447');
INSERT INTO `dux_total_visitor` VALUES ('160', '1436457600', '3914');
INSERT INTO `dux_total_visitor` VALUES ('161', '1436544000', '3845');
INSERT INTO `dux_total_visitor` VALUES ('162', '1436630400', '4634');
INSERT INTO `dux_total_visitor` VALUES ('163', '1436716800', '4633');
INSERT INTO `dux_total_visitor` VALUES ('164', '1436803200', '4219');
INSERT INTO `dux_total_visitor` VALUES ('165', '1436889600', '3653');
INSERT INTO `dux_total_visitor` VALUES ('166', '1436976000', '2754');
INSERT INTO `dux_total_visitor` VALUES ('167', '1437062400', '1055');
INSERT INTO `dux_total_visitor` VALUES ('168', '1437148800', '1188');
INSERT INTO `dux_total_visitor` VALUES ('169', '1438358400', '1959');
INSERT INTO `dux_total_visitor` VALUES ('170', '1438444800', '1501');
INSERT INTO `dux_total_visitor` VALUES ('171', '1438531200', '1560');
INSERT INTO `dux_total_visitor` VALUES ('172', '1438617600', '1670');
INSERT INTO `dux_total_visitor` VALUES ('173', '1438704000', '2775');
INSERT INTO `dux_total_visitor` VALUES ('174', '1438790400', '3065');
INSERT INTO `dux_total_visitor` VALUES ('175', '1438876800', '3914');
INSERT INTO `dux_total_visitor` VALUES ('176', '1438963200', '3075');
INSERT INTO `dux_total_visitor` VALUES ('177', '1439049600', '3029');
INSERT INTO `dux_total_visitor` VALUES ('178', '1439136000', '3709');
INSERT INTO `dux_total_visitor` VALUES ('179', '1439222400', '2814');
INSERT INTO `dux_total_visitor` VALUES ('180', '1439308800', '2614');
INSERT INTO `dux_total_visitor` VALUES ('181', '1439395200', '2850');
INSERT INTO `dux_total_visitor` VALUES ('182', '1439481600', '3173');
INSERT INTO `dux_total_visitor` VALUES ('183', '1439568000', '1726');
INSERT INTO `dux_total_visitor` VALUES ('184', '1439654400', '1683');
INSERT INTO `dux_total_visitor` VALUES ('185', '1439740800', '2348');
INSERT INTO `dux_total_visitor` VALUES ('186', '1439827200', '503');
INSERT INTO `dux_total_visitor` VALUES ('187', '1440086400', '711');
INSERT INTO `dux_total_visitor` VALUES ('188', '1440172800', '3976');
INSERT INTO `dux_total_visitor` VALUES ('189', '1440259200', '3734');
INSERT INTO `dux_total_visitor` VALUES ('190', '1440345600', '1761');
INSERT INTO `dux_total_visitor` VALUES ('191', '1440432000', '2756');
INSERT INTO `dux_total_visitor` VALUES ('192', '1440518400', '1576');
INSERT INTO `dux_total_visitor` VALUES ('193', '1440604800', '3377');
INSERT INTO `dux_total_visitor` VALUES ('194', '1440691200', '2770');
INSERT INTO `dux_total_visitor` VALUES ('195', '1440777600', '2899');
INSERT INTO `dux_total_visitor` VALUES ('196', '1440864000', '1658');
INSERT INTO `dux_total_visitor` VALUES ('197', '1440950400', '4663');
INSERT INTO `dux_total_visitor` VALUES ('198', '1441036800', '3654');
INSERT INTO `dux_total_visitor` VALUES ('199', '1441123200', '4538');
INSERT INTO `dux_total_visitor` VALUES ('200', '1441209600', '3182');
INSERT INTO `dux_total_visitor` VALUES ('201', '1441296000', '4443');
INSERT INTO `dux_total_visitor` VALUES ('202', '1441382400', '4223');
INSERT INTO `dux_total_visitor` VALUES ('203', '1441468800', '4002');
INSERT INTO `dux_total_visitor` VALUES ('204', '1441555200', '4821');
INSERT INTO `dux_total_visitor` VALUES ('205', '1441641600', '3632');
INSERT INTO `dux_total_visitor` VALUES ('206', '1441728000', '5048');
INSERT INTO `dux_total_visitor` VALUES ('207', '1441814400', '3420');
INSERT INTO `dux_total_visitor` VALUES ('208', '1441900800', '5157');
INSERT INTO `dux_total_visitor` VALUES ('209', '1441987200', '5110');
INSERT INTO `dux_total_visitor` VALUES ('210', '1442073600', '5238');
INSERT INTO `dux_total_visitor` VALUES ('211', '1442160000', '1623');
INSERT INTO `dux_total_visitor` VALUES ('212', '1442246400', '4799');
INSERT INTO `dux_total_visitor` VALUES ('213', '1442332800', '4572');
INSERT INTO `dux_total_visitor` VALUES ('214', '1442419200', '1614');
INSERT INTO `dux_total_visitor` VALUES ('215', '1442505600', '3618');
INSERT INTO `dux_total_visitor` VALUES ('216', '1442592000', '1546');
INSERT INTO `dux_total_visitor` VALUES ('217', '1442678400', '4272');
INSERT INTO `dux_total_visitor` VALUES ('218', '1442764800', '4672');
INSERT INTO `dux_total_visitor` VALUES ('219', '1442851200', '5009');
INSERT INTO `dux_total_visitor` VALUES ('220', '1442937600', '4940');
INSERT INTO `dux_total_visitor` VALUES ('221', '1443024000', '3808');
INSERT INTO `dux_total_visitor` VALUES ('222', '1443110400', '5610');
INSERT INTO `dux_total_visitor` VALUES ('223', '1443196800', '492');
INSERT INTO `dux_total_visitor` VALUES ('224', '1443369600', '3755');
INSERT INTO `dux_total_visitor` VALUES ('225', '1443456000', '1979');
INSERT INTO `dux_total_visitor` VALUES ('226', '1443542400', '4917');
INSERT INTO `dux_total_visitor` VALUES ('227', '1443628800', '3936');
INSERT INTO `dux_total_visitor` VALUES ('228', '1443715200', '3282');
INSERT INTO `dux_total_visitor` VALUES ('229', '1443801600', '3860');
INSERT INTO `dux_total_visitor` VALUES ('230', '1443888000', '4556');
INSERT INTO `dux_total_visitor` VALUES ('231', '1443974400', '3566');
INSERT INTO `dux_total_visitor` VALUES ('232', '1444060800', '1230');
INSERT INTO `dux_total_visitor` VALUES ('233', '1444147200', '4040');
INSERT INTO `dux_total_visitor` VALUES ('234', '1444233600', '1687');
INSERT INTO `dux_total_visitor` VALUES ('235', '1444320000', '1882');
INSERT INTO `dux_total_visitor` VALUES ('236', '1444406400', '4056');
INSERT INTO `dux_total_visitor` VALUES ('237', '1444492800', '4835');
INSERT INTO `dux_total_visitor` VALUES ('238', '1444579200', '4828');
INSERT INTO `dux_total_visitor` VALUES ('239', '1444665600', '3908');
INSERT INTO `dux_total_visitor` VALUES ('240', '1444752000', '3004');
INSERT INTO `dux_total_visitor` VALUES ('241', '1444838400', '4013');
INSERT INTO `dux_total_visitor` VALUES ('242', '1444924800', '4313');
INSERT INTO `dux_total_visitor` VALUES ('243', '1445011200', '4042');
INSERT INTO `dux_total_visitor` VALUES ('244', '1445097600', '4019');
INSERT INTO `dux_total_visitor` VALUES ('245', '1445184000', '368');
INSERT INTO `dux_total_visitor` VALUES ('246', '1445443200', '394');
INSERT INTO `dux_total_visitor` VALUES ('247', '1445529600', '1692');
INSERT INTO `dux_total_visitor` VALUES ('248', '1445616000', '4847');
INSERT INTO `dux_total_visitor` VALUES ('249', '1445702400', '374');
INSERT INTO `dux_total_visitor` VALUES ('250', '1445875200', '4295');
INSERT INTO `dux_total_visitor` VALUES ('251', '1445961600', '7183');
INSERT INTO `dux_total_visitor` VALUES ('252', '1446048000', '4301');
INSERT INTO `dux_total_visitor` VALUES ('253', '1446134400', '4395');
INSERT INTO `dux_total_visitor` VALUES ('254', '1446220800', '4609');
INSERT INTO `dux_total_visitor` VALUES ('255', '1446307200', '4761');
INSERT INTO `dux_total_visitor` VALUES ('256', '1446393600', '4574');
INSERT INTO `dux_total_visitor` VALUES ('257', '1446480000', '4078');
INSERT INTO `dux_total_visitor` VALUES ('258', '1446566400', '10422');
INSERT INTO `dux_total_visitor` VALUES ('259', '1446652800', '2519');
INSERT INTO `dux_total_visitor` VALUES ('260', '1446739200', '4447');
INSERT INTO `dux_total_visitor` VALUES ('261', '1446825600', '4400');
INSERT INTO `dux_total_visitor` VALUES ('262', '1446912000', '4294');
INSERT INTO `dux_total_visitor` VALUES ('263', '1446998400', '4036');
INSERT INTO `dux_total_visitor` VALUES ('264', '1447084800', '4147');
INSERT INTO `dux_total_visitor` VALUES ('265', '1447171200', '4792');
INSERT INTO `dux_total_visitor` VALUES ('266', '1447257600', '1256');
INSERT INTO `dux_total_visitor` VALUES ('267', '1447344000', '4844');
INSERT INTO `dux_total_visitor` VALUES ('268', '1447430400', '379');
INSERT INTO `dux_total_visitor` VALUES ('269', '1447948800', '293');
INSERT INTO `dux_total_visitor` VALUES ('270', '1448035200', '4441');
INSERT INTO `dux_total_visitor` VALUES ('271', '1448121600', '4588');
INSERT INTO `dux_total_visitor` VALUES ('272', '1448208000', '4380');
INSERT INTO `dux_total_visitor` VALUES ('273', '1448294400', '4004');
INSERT INTO `dux_total_visitor` VALUES ('274', '1448380800', '314');
INSERT INTO `dux_total_visitor` VALUES ('275', '1448899200', '4023');
INSERT INTO `dux_total_visitor` VALUES ('276', '1448985600', '4357');
INSERT INTO `dux_total_visitor` VALUES ('277', '1449072000', '829');
INSERT INTO `dux_total_visitor` VALUES ('278', '1449158400', '3475');
INSERT INTO `dux_total_visitor` VALUES ('279', '1449244800', '4500');
INSERT INTO `dux_total_visitor` VALUES ('280', '1449331200', '4300');
INSERT INTO `dux_total_visitor` VALUES ('281', '1449417600', '4223');
INSERT INTO `dux_total_visitor` VALUES ('282', '1449504000', '4091');
INSERT INTO `dux_total_visitor` VALUES ('283', '1449590400', '742');
INSERT INTO `dux_total_visitor` VALUES ('284', '1449676800', '680');
INSERT INTO `dux_total_visitor` VALUES ('285', '1449763200', '261');
INSERT INTO `dux_total_visitor` VALUES ('286', '1451577600', '4777');
INSERT INTO `dux_total_visitor` VALUES ('287', '1451664000', '877');
INSERT INTO `dux_total_visitor` VALUES ('288', '1451750400', '5054');
INSERT INTO `dux_total_visitor` VALUES ('289', '1451836800', '5064');
INSERT INTO `dux_total_visitor` VALUES ('290', '1451923200', '5024');
INSERT INTO `dux_total_visitor` VALUES ('291', '1452009600', '5021');
INSERT INTO `dux_total_visitor` VALUES ('292', '1452096000', '4283');
INSERT INTO `dux_total_visitor` VALUES ('293', '1452182400', '5113');
INSERT INTO `dux_total_visitor` VALUES ('294', '1452268800', '4932');
INSERT INTO `dux_total_visitor` VALUES ('295', '1452441600', '298');
INSERT INTO `dux_total_visitor` VALUES ('296', '1452528000', '825');
INSERT INTO `dux_total_visitor` VALUES ('297', '1452614400', '4945');
INSERT INTO `dux_total_visitor` VALUES ('298', '1452700800', '793');
INSERT INTO `dux_total_visitor` VALUES ('299', '1452787200', '844');
INSERT INTO `dux_total_visitor` VALUES ('300', '1452873600', '1107');
INSERT INTO `dux_total_visitor` VALUES ('301', '1452960000', '5071');
INSERT INTO `dux_total_visitor` VALUES ('302', '1453046400', '4971');
INSERT INTO `dux_total_visitor` VALUES ('303', '1453132800', '4011');
INSERT INTO `dux_total_visitor` VALUES ('304', '1453219200', '3069');
INSERT INTO `dux_total_visitor` VALUES ('305', '1453305600', '1621');
INSERT INTO `dux_total_visitor` VALUES ('306', '1453392000', '1000');
INSERT INTO `dux_total_visitor` VALUES ('307', '1453478400', '3490');
INSERT INTO `dux_total_visitor` VALUES ('308', '1453564800', '4206');
INSERT INTO `dux_total_visitor` VALUES ('309', '1453651200', '2209');
INSERT INTO `dux_total_visitor` VALUES ('310', '1453737600', '2136');
INSERT INTO `dux_total_visitor` VALUES ('311', '1453824000', '1617');
INSERT INTO `dux_total_visitor` VALUES ('312', '1453910400', '926');
INSERT INTO `dux_total_visitor` VALUES ('313', '1453996800', '982');
INSERT INTO `dux_total_visitor` VALUES ('314', '1454083200', '1002');
INSERT INTO `dux_total_visitor` VALUES ('315', '1454169600', '3383');
INSERT INTO `dux_total_visitor` VALUES ('316', '1454256000', '2711');
INSERT INTO `dux_total_visitor` VALUES ('317', '1454342400', '1078');
INSERT INTO `dux_total_visitor` VALUES ('318', '1454428800', '1149');
INSERT INTO `dux_total_visitor` VALUES ('319', '1454515200', '1644');
INSERT INTO `dux_total_visitor` VALUES ('320', '1454601600', '1101');
INSERT INTO `dux_total_visitor` VALUES ('321', '1454688000', '1082');
INSERT INTO `dux_total_visitor` VALUES ('322', '1454774400', '1119');
INSERT INTO `dux_total_visitor` VALUES ('323', '1454860800', '2590');
INSERT INTO `dux_total_visitor` VALUES ('324', '1454947200', '1069');
INSERT INTO `dux_total_visitor` VALUES ('325', '1455033600', '1085');
INSERT INTO `dux_total_visitor` VALUES ('326', '1455120000', '1113');
INSERT INTO `dux_total_visitor` VALUES ('327', '1455206400', '2247');
INSERT INTO `dux_total_visitor` VALUES ('328', '1455292800', '1052');
INSERT INTO `dux_total_visitor` VALUES ('329', '1455379200', '1061');
INSERT INTO `dux_total_visitor` VALUES ('330', '1455465600', '2588');
INSERT INTO `dux_total_visitor` VALUES ('331', '1455552000', '1038');
INSERT INTO `dux_total_visitor` VALUES ('332', '1455638400', '1109');
INSERT INTO `dux_total_visitor` VALUES ('333', '1455724800', '1058');
INSERT INTO `dux_total_visitor` VALUES ('334', '1455811200', '1094');
INSERT INTO `dux_total_visitor` VALUES ('335', '1455897600', '1065');
INSERT INTO `dux_total_visitor` VALUES ('336', '1455984000', '1016');
INSERT INTO `dux_total_visitor` VALUES ('337', '1456070400', '997');
INSERT INTO `dux_total_visitor` VALUES ('338', '1456156800', '1060');
INSERT INTO `dux_total_visitor` VALUES ('339', '1456243200', '959');
INSERT INTO `dux_total_visitor` VALUES ('340', '1456329600', '1316');
INSERT INTO `dux_total_visitor` VALUES ('341', '1456416000', '995');
INSERT INTO `dux_total_visitor` VALUES ('342', '1456502400', '2777');
INSERT INTO `dux_total_visitor` VALUES ('343', '1456588800', '1053');
INSERT INTO `dux_total_visitor` VALUES ('344', '1456675200', '1034');
INSERT INTO `dux_total_visitor` VALUES ('345', '1456761600', '1000');
INSERT INTO `dux_total_visitor` VALUES ('346', '1456848000', '4668');
INSERT INTO `dux_total_visitor` VALUES ('347', '1456934400', '4999');
INSERT INTO `dux_total_visitor` VALUES ('348', '1457020800', '2380');
INSERT INTO `dux_total_visitor` VALUES ('349', '1457107200', '5023');
INSERT INTO `dux_total_visitor` VALUES ('350', '1457193600', '4577');
INSERT INTO `dux_total_visitor` VALUES ('351', '1457280000', '5033');
INSERT INTO `dux_total_visitor` VALUES ('352', '1457366400', '1129');
INSERT INTO `dux_total_visitor` VALUES ('353', '1457452800', '2170');
INSERT INTO `dux_total_visitor` VALUES ('354', '1457539200', '3977');
INSERT INTO `dux_total_visitor` VALUES ('355', '1457625600', '3836');
INSERT INTO `dux_total_visitor` VALUES ('356', '1457712000', '3053');
INSERT INTO `dux_total_visitor` VALUES ('357', '1457798400', '5762');
INSERT INTO `dux_total_visitor` VALUES ('358', '1457884800', '4226');
INSERT INTO `dux_total_visitor` VALUES ('359', '1457971200', '4115');
INSERT INTO `dux_total_visitor` VALUES ('360', '1458057600', '4264');
INSERT INTO `dux_total_visitor` VALUES ('361', '1458144000', '884');
INSERT INTO `dux_total_visitor` VALUES ('362', '1458230400', '853');
INSERT INTO `dux_total_visitor` VALUES ('363', '1458316800', '4753');
INSERT INTO `dux_total_visitor` VALUES ('364', '1458403200', '5166');
INSERT INTO `dux_total_visitor` VALUES ('365', '1458489600', '6321');
INSERT INTO `dux_total_visitor` VALUES ('366', '1458576000', '922');
INSERT INTO `dux_total_visitor` VALUES ('367', '1458662400', '5193');
INSERT INTO `dux_total_visitor` VALUES ('368', '1458748800', '9202');
INSERT INTO `dux_total_visitor` VALUES ('369', '1458835200', '4921');
INSERT INTO `dux_total_visitor` VALUES ('370', '1458921600', '8435');
INSERT INTO `dux_total_visitor` VALUES ('371', '1459008000', '4884');
INSERT INTO `dux_total_visitor` VALUES ('372', '1459094400', '1144');
INSERT INTO `dux_total_visitor` VALUES ('373', '1459180800', '5182');
INSERT INTO `dux_total_visitor` VALUES ('374', '1459267200', '4894');
INSERT INTO `dux_total_visitor` VALUES ('375', '1459353600', '6809');
INSERT INTO `dux_total_visitor` VALUES ('376', '1459440000', '8659');
INSERT INTO `dux_total_visitor` VALUES ('377', '1459526400', '4898');
INSERT INTO `dux_total_visitor` VALUES ('378', '1459612800', '4570');
INSERT INTO `dux_total_visitor` VALUES ('379', '1459699200', '4921');
INSERT INTO `dux_total_visitor` VALUES ('380', '1459785600', '4876');
INSERT INTO `dux_total_visitor` VALUES ('381', '1459872000', '4916');
INSERT INTO `dux_total_visitor` VALUES ('382', '1459958400', '4894');
INSERT INTO `dux_total_visitor` VALUES ('383', '1460044800', '4929');
INSERT INTO `dux_total_visitor` VALUES ('384', '1460131200', '937');
INSERT INTO `dux_total_visitor` VALUES ('385', '1460217600', '4884');
INSERT INTO `dux_total_visitor` VALUES ('386', '1460304000', '8391');
INSERT INTO `dux_total_visitor` VALUES ('387', '1460390400', '4859');
INSERT INTO `dux_total_visitor` VALUES ('388', '1460476800', '4835');
INSERT INTO `dux_total_visitor` VALUES ('389', '1460563200', '6229');
INSERT INTO `dux_total_visitor` VALUES ('390', '1460649600', '5026');
INSERT INTO `dux_total_visitor` VALUES ('391', '1460736000', '4474');
INSERT INTO `dux_total_visitor` VALUES ('392', '1460822400', '4772');
INSERT INTO `dux_total_visitor` VALUES ('393', '1460908800', '4819');
INSERT INTO `dux_total_visitor` VALUES ('394', '1460995200', '843');
INSERT INTO `dux_total_visitor` VALUES ('395', '1461081600', '4544');
INSERT INTO `dux_total_visitor` VALUES ('396', '1461168000', '4814');
INSERT INTO `dux_total_visitor` VALUES ('397', '1461254400', '4914');
INSERT INTO `dux_total_visitor` VALUES ('398', '1461340800', '4314');
INSERT INTO `dux_total_visitor` VALUES ('399', '1461427200', '260');
INSERT INTO `dux_total_visitor` VALUES ('400', '1461513600', '4846');
INSERT INTO `dux_total_visitor` VALUES ('401', '1461600000', '906');
INSERT INTO `dux_total_visitor` VALUES ('402', '1461686400', '4883');
INSERT INTO `dux_total_visitor` VALUES ('403', '1461772800', '4876');
INSERT INTO `dux_total_visitor` VALUES ('404', '1461859200', '4778');
INSERT INTO `dux_total_visitor` VALUES ('405', '1461945600', '292');
INSERT INTO `dux_total_visitor` VALUES ('406', '1462032000', '2094');
INSERT INTO `dux_total_visitor` VALUES ('407', '1462118400', '850');
INSERT INTO `dux_total_visitor` VALUES ('408', '1462204800', '2365');
INSERT INTO `dux_total_visitor` VALUES ('409', '1462291200', '787');
INSERT INTO `dux_total_visitor` VALUES ('410', '1462377600', '3688');
INSERT INTO `dux_total_visitor` VALUES ('411', '1462464000', '2005');
INSERT INTO `dux_total_visitor` VALUES ('412', '1462550400', '2186');
INSERT INTO `dux_total_visitor` VALUES ('413', '1462636800', '632');
INSERT INTO `dux_total_visitor` VALUES ('414', '1462723200', '680');
INSERT INTO `dux_total_visitor` VALUES ('415', '1462809600', '2070');
INSERT INTO `dux_total_visitor` VALUES ('416', '1462896000', '2156');
INSERT INTO `dux_total_visitor` VALUES ('417', '1462982400', '2264');
INSERT INTO `dux_total_visitor` VALUES ('418', '1463068800', '2262');
INSERT INTO `dux_total_visitor` VALUES ('419', '1463155200', '2276');
INSERT INTO `dux_total_visitor` VALUES ('420', '1463241600', '2348');
INSERT INTO `dux_total_visitor` VALUES ('421', '1463328000', '1916');
INSERT INTO `dux_total_visitor` VALUES ('422', '1463414400', '2274');
INSERT INTO `dux_total_visitor` VALUES ('423', '1463500800', '1229');
INSERT INTO `dux_total_visitor` VALUES ('424', '1463587200', '3734');
INSERT INTO `dux_total_visitor` VALUES ('425', '1463673600', '1851');
INSERT INTO `dux_total_visitor` VALUES ('426', '1463760000', '3606');
INSERT INTO `dux_total_visitor` VALUES ('427', '1463846400', '782');
INSERT INTO `dux_total_visitor` VALUES ('428', '1463932800', '814');
INSERT INTO `dux_total_visitor` VALUES ('429', '1464019200', '1829');
INSERT INTO `dux_total_visitor` VALUES ('430', '1464105600', '982');
INSERT INTO `dux_total_visitor` VALUES ('431', '1464192000', '2212');
INSERT INTO `dux_total_visitor` VALUES ('432', '1464278400', '2183');
INSERT INTO `dux_total_visitor` VALUES ('433', '1464364800', '743');
INSERT INTO `dux_total_visitor` VALUES ('434', '1464451200', '2242');
INSERT INTO `dux_total_visitor` VALUES ('435', '1464537600', '790');
INSERT INTO `dux_total_visitor` VALUES ('436', '1464624000', '2085');
INSERT INTO `dux_total_visitor` VALUES ('437', '1464710400', '2165');
INSERT INTO `dux_total_visitor` VALUES ('438', '1464796800', '2203');
INSERT INTO `dux_total_visitor` VALUES ('439', '1464883200', '2190');
INSERT INTO `dux_total_visitor` VALUES ('440', '1464969600', '2035');
INSERT INTO `dux_total_visitor` VALUES ('441', '1465056000', '2116');
INSERT INTO `dux_total_visitor` VALUES ('442', '1465142400', '2171');
INSERT INTO `dux_total_visitor` VALUES ('443', '1465228800', '847');
INSERT INTO `dux_total_visitor` VALUES ('444', '1465315200', '2131');
INSERT INTO `dux_total_visitor` VALUES ('445', '1465401600', '2135');
INSERT INTO `dux_total_visitor` VALUES ('446', '1465488000', '2098');
INSERT INTO `dux_total_visitor` VALUES ('447', '1465574400', '2161');
INSERT INTO `dux_total_visitor` VALUES ('448', '1465660800', '1988');
INSERT INTO `dux_total_visitor` VALUES ('449', '1465747200', '1919');
INSERT INTO `dux_total_visitor` VALUES ('450', '1465833600', '1980');
INSERT INTO `dux_total_visitor` VALUES ('451', '1465920000', '4080');
INSERT INTO `dux_total_visitor` VALUES ('452', '1466006400', '1514');
INSERT INTO `dux_total_visitor` VALUES ('453', '1466092800', '1469');
INSERT INTO `dux_total_visitor` VALUES ('454', '1466179200', '2173');
INSERT INTO `dux_total_visitor` VALUES ('455', '1466265600', '2112');
INSERT INTO `dux_total_visitor` VALUES ('456', '1466352000', '290');
